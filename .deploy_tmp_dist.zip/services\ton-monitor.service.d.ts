/**
 * TON monitor — polls the platform vault for incoming transactions relevant
 * to the App Store and dispatches them to the right service.
 *
 * Comment formats (text comments in TON transfers + jetton transfer
 * forward_payloads):
 *
 *   "publish:<listingId>"   — V1/V2 publishing fee (still supported)
 *   "lp_init:<listingId>"   — initial liquidity at publish (TON + Jetton legs)
 *   "lp_add:<listingId>"    — additional liquidity (TON + Jetton legs)
 *   "buy:<tradeId>"          — TON paid for a buy
 *   "sell:<tradeId>"         — accompanies the user's outgoing jetton transfer
 *
 * For LP events we need to pair two legs (TON + Jetton) sent in the same
 * batch by TonConnect. We buffer one leg in `pendingLegs` until its sibling
 * arrives, then commit the position atomically.
 *
 * The monitor is intentionally polling-based to match billing.service.ts
 * style (no websocket dependency, plays nicely with pm2 restarts).
 */
declare class TonMonitorService {
    private timer;
    private running;
    start(): void;
    stop(): void;
    /** Run one matching pass — exposed so tests / admin can invoke on demand. */
    tick(): Promise<void>;
    private handleIncoming;
    private handlePublishFee;
    private handleLpLeg;
    private commitLpDeposit;
    private handleBuy;
    private handleSell;
}
export declare const tonMonitorService: TonMonitorService;
export {};
//# sourceMappingURL=ton-monitor.service.d.ts.map