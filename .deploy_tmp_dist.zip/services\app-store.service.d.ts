/**
 * App Store service — listing CRUD, screenshot management, validation,
 * publication workflow.
 *
 *   draft                — owner editing fields
 *   ready                — all required data filled (frontend gate, not strict)
 *   submitting           — user clicked Submit; awaiting publish-fee TON tx
 *   pending              — fee received, in admin review queue
 *   approved             — admin approved; user signs Jetton master deploy
 *   deployed_pending_lp  — Jetton master deployed by user; awaiting LP-init
 *   published            — listing live + LP pool funded
 *   rejected             — admin rejected; owner can edit + resubmit
 */
export type ListingStatus = "draft" | "ready" | "submitting" | "pending" | "approved" | "deployed_pending_lp" | "published" | "rejected";
export interface ListingDraftInput {
    /** Display name shown on the listing (App Store card title). */
    appName?: string;
    shortDescription?: string;
    longDescription?: string;
    socials?: {
        telegram?: string;
        twitter?: string;
        website?: string;
        other?: string;
    };
    category?: string;
    /** 0–10 short tags shown on the App Store card. Empty array clears them. */
    tags?: string[];
    /** Bucket filename for the App Store hero/banner image. */
    bannerFilename?: string;
    tokenName?: string;
    tokenSymbol?: string;
    /** Optional Jetton metadata description. Empty string clears the field. */
    tokenDescription?: string;
    tokenLogoFilename?: string;
    initialLiquidityTon?: number;
    initialLiquidityTokenShare?: number;
    /** Internal liquidity amount in TON (stored, not on-chain). */
    liquidityTon?: number;
    /** Per-language overrides (stored as JSON on the listing). */
    translations?: Record<string, {
        name?: string;
        short?: string;
        long?: string;
    }>;
}
declare class AppStoreService {
    /** Get-or-create the listing draft for a project. */
    getOrCreateDraft(projectId: string): Promise<({
        project: {
            name: string;
            botUsername: string | null;
            userId: number;
        };
        token: {
            symbol: string;
            projectId: string;
            id: string;
            name: string;
            createdAt: Date;
            status: string;
            updatedAt: Date;
            ownerWalletAddress: string | null;
            listingId: string;
            jettonMasterAddress: string | null;
            metadataDescription: string | null;
            logoFilename: string;
            deployTxHash: string | null;
            totalSupply: bigint;
            curveSupplyCap: bigint;
            virtualTonReserve: bigint;
            virtualTokenReserve: bigint;
            realTonReserve: bigint;
            realTokenReserve: bigint;
            lpTotalShares: bigint;
            soldSupply: bigint;
            feeBalanceNanoTon: bigint;
            creatorFeeBalanceNanoTon: bigint;
        } | null;
    } & {
        projectId: string;
        id: string;
        category: string | null;
        createdAt: Date;
        status: string;
        updatedAt: Date;
        tags: import("@prisma/client/runtime/library").JsonValue | null;
        shortDescription: string | null;
        longDescription: string | null;
        socials: import("@prisma/client/runtime/library").JsonValue | null;
        bannerFilename: string | null;
        screenshots: import("@prisma/client/runtime/library").JsonValue | null;
        publishFeeTxHash: string | null;
        submittedAt: Date | null;
        approvedAt: Date | null;
        approvedBy: number | null;
        rejectedReason: string | null;
        publishedAt: Date | null;
        hidden: boolean;
        volume24hNanoTon: bigint;
        marketCapNanoTon: bigint;
    }) | null>;
    getListing(listingId: string): Promise<({
        project: {
            id: string;
            name: string;
            botUsername: string | null;
            userId: number;
        };
        token: {
            symbol: string;
            projectId: string;
            id: string;
            name: string;
            createdAt: Date;
            status: string;
            updatedAt: Date;
            ownerWalletAddress: string | null;
            listingId: string;
            jettonMasterAddress: string | null;
            metadataDescription: string | null;
            logoFilename: string;
            deployTxHash: string | null;
            totalSupply: bigint;
            curveSupplyCap: bigint;
            virtualTonReserve: bigint;
            virtualTokenReserve: bigint;
            realTonReserve: bigint;
            realTokenReserve: bigint;
            lpTotalShares: bigint;
            soldSupply: bigint;
            feeBalanceNanoTon: bigint;
            creatorFeeBalanceNanoTon: bigint;
        } | null;
    } & {
        projectId: string;
        id: string;
        category: string | null;
        createdAt: Date;
        status: string;
        updatedAt: Date;
        tags: import("@prisma/client/runtime/library").JsonValue | null;
        shortDescription: string | null;
        longDescription: string | null;
        socials: import("@prisma/client/runtime/library").JsonValue | null;
        bannerFilename: string | null;
        screenshots: import("@prisma/client/runtime/library").JsonValue | null;
        publishFeeTxHash: string | null;
        submittedAt: Date | null;
        approvedAt: Date | null;
        approvedBy: number | null;
        rejectedReason: string | null;
        publishedAt: Date | null;
        hidden: boolean;
        volume24hNanoTon: bigint;
        marketCapNanoTon: bigint;
    }) | null>;
    /** Public listing fetch by project id (used for share links). */
    getListingByProject(projectId: string): Promise<({
        project: {
            id: string;
            name: string;
            botUsername: string | null;
            userId: number;
        };
        token: {
            symbol: string;
            projectId: string;
            id: string;
            name: string;
            createdAt: Date;
            status: string;
            updatedAt: Date;
            ownerWalletAddress: string | null;
            listingId: string;
            jettonMasterAddress: string | null;
            metadataDescription: string | null;
            logoFilename: string;
            deployTxHash: string | null;
            totalSupply: bigint;
            curveSupplyCap: bigint;
            virtualTonReserve: bigint;
            virtualTokenReserve: bigint;
            realTonReserve: bigint;
            realTokenReserve: bigint;
            lpTotalShares: bigint;
            soldSupply: bigint;
            feeBalanceNanoTon: bigint;
            creatorFeeBalanceNanoTon: bigint;
        } | null;
    } & {
        projectId: string;
        id: string;
        category: string | null;
        createdAt: Date;
        status: string;
        updatedAt: Date;
        tags: import("@prisma/client/runtime/library").JsonValue | null;
        shortDescription: string | null;
        longDescription: string | null;
        socials: import("@prisma/client/runtime/library").JsonValue | null;
        bannerFilename: string | null;
        screenshots: import("@prisma/client/runtime/library").JsonValue | null;
        publishFeeTxHash: string | null;
        submittedAt: Date | null;
        approvedAt: Date | null;
        approvedBy: number | null;
        rejectedReason: string | null;
        publishedAt: Date | null;
        hidden: boolean;
        volume24hNanoTon: bigint;
        marketCapNanoTon: bigint;
    }) | null>;
    updateDraft(listingId: string, input: ListingDraftInput): Promise<({
        project: {
            id: string;
            name: string;
            botUsername: string | null;
            userId: number;
        };
        token: {
            symbol: string;
            projectId: string;
            id: string;
            name: string;
            createdAt: Date;
            status: string;
            updatedAt: Date;
            ownerWalletAddress: string | null;
            listingId: string;
            jettonMasterAddress: string | null;
            metadataDescription: string | null;
            logoFilename: string;
            deployTxHash: string | null;
            totalSupply: bigint;
            curveSupplyCap: bigint;
            virtualTonReserve: bigint;
            virtualTokenReserve: bigint;
            realTonReserve: bigint;
            realTokenReserve: bigint;
            lpTotalShares: bigint;
            soldSupply: bigint;
            feeBalanceNanoTon: bigint;
            creatorFeeBalanceNanoTon: bigint;
        } | null;
    } & {
        projectId: string;
        id: string;
        category: string | null;
        createdAt: Date;
        status: string;
        updatedAt: Date;
        tags: import("@prisma/client/runtime/library").JsonValue | null;
        shortDescription: string | null;
        longDescription: string | null;
        socials: import("@prisma/client/runtime/library").JsonValue | null;
        bannerFilename: string | null;
        screenshots: import("@prisma/client/runtime/library").JsonValue | null;
        publishFeeTxHash: string | null;
        submittedAt: Date | null;
        approvedAt: Date | null;
        approvedBy: number | null;
        rejectedReason: string | null;
        publishedAt: Date | null;
        hidden: boolean;
        volume24hNanoTon: bigint;
        marketCapNanoTon: bigint;
    }) | null>;
    /**
     * Lazily create the AppToken row. Reserves and supply are zero — they are
     * populated only after the user signs the on-chain LP-init transfer (the
     * V2 flow). `totalSupply` is set from runtime config so the metadata.json
     * we serve to wallets is correct.
     */
    private _ensureTokenRow;
    addScreenshot(listingId: string, projectId: string, buf: Buffer, ext: string): Promise<string>;
    removeScreenshot(listingId: string, projectId: string, filename: string): Promise<void>;
    setTokenLogo(listingId: string, projectId: string, buf: Buffer, ext: string): Promise<string>;
    /**
     * Save a hero/banner image for the App Store detail page. Replaces any
     * previous banner file for the same listing (one-banner-per-listing rule).
     */
    setBanner(listingId: string, projectId: string, buf: Buffer, ext: string): Promise<string>;
    removeBanner(listingId: string, projectId: string): Promise<void>;
    /**
     * Compute the 7-step publish readiness for a project. The frontend renders
     * this as a progress panel (stepper) on the App Settings page.
     *
     * Steps:
     *   1. created           — project row exists (always true once fetched)
     *   2. botConnected      — project.botUsername is set
     *   3. appInfo           — name + description + avatar present on the project
     *   4. pageInfo          — listing.category, ≥3 tags, banner, ≥4 screenshots
     *   5. tokenInfo         — token has name + symbol + logo + ticker accepted
     *   6. review            — listing.status in pending/approved/deployed_pending_lp
     *   7. published         — listing.status === "published" AND token live
     */
    getReadiness(projectId: string): Promise<{
        steps: Array<{
            id: number;
            key: string;
            title: string;
            done: boolean;
            missing: string[];
        }>;
        currentStep: number;
        listingId: string | null;
        /** Status of the listing as a single string for the panel header. */
        summary: string;
        status: string;
    }>;
    submit(listingId: string): Promise<{
        ok: boolean;
    }>;
    platformWalletAddress(): string;
    /**
     * Step A — return a TonConnect message that, when signed by the user,
     * deploys their Jetton master (admin = user) and pre-mints the full
     * supply to their wallet. Status flips approved → awaiting on-chain
     * confirmation. The TON monitor advances the listing once the master
     * is confirmed.
     *
     * If the production Jetton BoCs are not present (`isJettonInfraReady()`
     * returns false), this method falls back to immediately marking the
     * deploy as completed with a SIM_ address, so the rest of the flow keeps
     * working in development.
     */
    preparePublishDeploy(listingId: string, opts: {
        userWalletAddress: string;
    }): Promise<{
        ok: boolean;
        simulated: boolean;
        jettonMasterAddress: string;
        validUntil: number;
        messages: import("./jetton-tx-builder.service").TonConnectMessage[];
        pollEndpoint: string;
    }>;
    /**
     * Step B — return a TonConnect tx (multi-message) that the user signs to
     * fund the initial liquidity. Two legs:
     *   1. Jetton transfer from user's jetton wallet → vault's jetton wallet
     *   2. Plain TON transfer from user → vault
     * Both carry comment `lp_init:<listingId>`.
     *
     * `tonAmount` and `tokenShare` are sent by the publisher in the body and
     * validated against runtime min/max bounds.
     */
    preparePublishLpInit(listingId: string, opts: {
        userWalletAddress: string;
        tonAmount: number;
        tokenShare: number;
    }): Promise<{
        ok: boolean;
        simulated: boolean;
        messages: import("./jetton-tx-builder.service").TonConnectMessage[];
        validUntil: number;
        tonAmount: number;
        tokensLocked: string;
        tokenShare: number;
        vaultAddress: string;
        userJettonWalletAddress: string;
    }>;
    /** Public config snapshot used by the publish form. */
    publishConfigSnapshot(): {
        publishFeeTon: number;
        initialLiquidityTon: number;
        initialLiquidityTokenShare: number;
        minInitialLiquidityTon: number;
        minInitialLiquidityTokenShare: number;
        tokenTotalSupply: number;
        vaultAddress: string;
        infraReady: boolean;
        tokenPreset: {
            decimals: number;
            defaultSupply: number;
            defaultDescription: string;
            mintMode: string;
            adminAddress: string;
            contractRepo: string;
            contractTemplate: string;
            deployGasTon: string;
            metadataMode: string;
        };
    };
    /** Returns liquidity infrastructure readiness flag for UI hints. */
    isJettonInfraReady(): boolean;
    /**
     * Build the TonConnect tx for a follow-up liquidity ADD. Caller specifies
     * the TON amount they want to add; the matching token amount is computed
     * from current pool ratios.
     */
    prepareLpAdd(listingId: string, opts: {
        userWalletAddress: string;
        tonAmount: number;
    }): Promise<{
        ok: boolean;
        messages: import("./jetton-tx-builder.service").TonConnectMessage[];
        validUntil: number;
        tonAmount: number;
        tokensRequired: string;
        vaultAddress: string;
    }>;
    /**
     * Initiate a liquidity REMOVE. Custodial: user signs an off-chain request
     * (validated by Telegram init data), backend's hot wallet then dispatches
     * the proportional TON + Jetton payouts. Returns the quote synchronously
     * so the UI shows what the user will receive.
     */
    previewLpRemove(listingId: string, opts: {
        userWalletAddress: string;
        sharesToBurn?: bigint;
        fraction?: number;
    }): Promise<{
        ok: boolean;
        sharesToBurn: string;
        tonOutNano: string;
        tokenOut: string;
        yourShares: string;
        totalShares: string;
    }>;
    listForReview(status?: string): Promise<({
        project: {
            id: string;
            name: string;
            user: {
                id: number;
                telegramId: bigint;
                username: string | null;
                firstName: string | null;
            };
            botUsername: string | null;
            userId: number;
        };
        token: {
            symbol: string;
            projectId: string;
            id: string;
            name: string;
            createdAt: Date;
            status: string;
            updatedAt: Date;
            ownerWalletAddress: string | null;
            listingId: string;
            jettonMasterAddress: string | null;
            metadataDescription: string | null;
            logoFilename: string;
            deployTxHash: string | null;
            totalSupply: bigint;
            curveSupplyCap: bigint;
            virtualTonReserve: bigint;
            virtualTokenReserve: bigint;
            realTonReserve: bigint;
            realTokenReserve: bigint;
            lpTotalShares: bigint;
            soldSupply: bigint;
            feeBalanceNanoTon: bigint;
            creatorFeeBalanceNanoTon: bigint;
        } | null;
    } & {
        projectId: string;
        id: string;
        category: string | null;
        createdAt: Date;
        status: string;
        updatedAt: Date;
        tags: import("@prisma/client/runtime/library").JsonValue | null;
        shortDescription: string | null;
        longDescription: string | null;
        socials: import("@prisma/client/runtime/library").JsonValue | null;
        bannerFilename: string | null;
        screenshots: import("@prisma/client/runtime/library").JsonValue | null;
        publishFeeTxHash: string | null;
        submittedAt: Date | null;
        approvedAt: Date | null;
        approvedBy: number | null;
        rejectedReason: string | null;
        publishedAt: Date | null;
        hidden: boolean;
        volume24hNanoTon: bigint;
        marketCapNanoTon: bigint;
    })[]>;
    approve(listingId: string, adminUserId: number): Promise<{
        ok: boolean;
    }>;
    reject(listingId: string, reason: string): Promise<{
        ok: boolean;
    }>;
    setHidden(listingId: string, hidden: boolean): Promise<{
        ok: boolean;
    }>;
    listPublished(opts: {
        tab?: "trending" | "new" | "top";
        limit?: number;
        offset?: number;
        q?: string;
    }): Promise<{
        items: {
            listingId: any;
            projectId: any;
            projectName: any;
            botUsername: any;
            shortDescription: any;
            category: any;
            tags: string[];
            bannerFilename: any;
            publishedAt: any;
            screenshots: string[];
            token: {
                id: any;
                name: any;
                symbol: any;
                logoFilename: any;
                priceTon: number;
                marketCapTon: number;
                volume24hTon: number;
                soldSupply: any;
                totalSupply: any;
                realTonReserve: any;
                realTokenReserve: any;
                lpTotalShares: any;
                ownerWalletAddress: any;
                jettonMasterAddress: any;
                change24h: number | null;
            } | null;
        }[];
        total: number;
        limit: number;
        offset: number;
    }>;
    toCardJson(row: any): {
        listingId: any;
        projectId: any;
        projectName: any;
        botUsername: any;
        shortDescription: any;
        category: any;
        tags: string[];
        bannerFilename: any;
        publishedAt: any;
        screenshots: string[];
        token: {
            id: any;
            name: any;
            symbol: any;
            logoFilename: any;
            priceTon: number;
            marketCapTon: number;
            volume24hTon: number;
            soldSupply: any;
            totalSupply: any;
            realTonReserve: any;
            realTokenReserve: any;
            lpTotalShares: any;
            ownerWalletAddress: any;
            jettonMasterAddress: any;
            change24h: number | null;
        } | null;
    };
    getTokenDetail(listingId: string): Promise<{
        longDescription: string | null;
        socials: import("@prisma/client/runtime/library").JsonValue;
        screenshots: string[];
        holdersCount: number;
        lpProvidersCount: number;
        lpPositions: {
            ownerWalletAddress: string;
            shares: string;
        }[];
        trades: {
            id: string;
            type: string;
            tonAmount: number;
            tokenAmount: number;
            priceTon: number;
            createdAt: Date;
        }[];
        listingId: any;
        projectId: any;
        projectName: any;
        botUsername: any;
        shortDescription: any;
        category: any;
        tags: string[];
        bannerFilename: any;
        publishedAt: any;
        token: {
            id: any;
            name: any;
            symbol: any;
            logoFilename: any;
            priceTon: number;
            marketCapTon: number;
            volume24hTon: number;
            soldSupply: any;
            totalSupply: any;
            realTonReserve: any;
            realTokenReserve: any;
            lpTotalShares: any;
            ownerWalletAddress: any;
            jettonMasterAddress: any;
            change24h: number | null;
        } | null;
    }>;
    /** Pool state + caller's LP position. Used by the Liquidity card. */
    getLiquidityForListing(listingId: string, opts: {
        userWalletAddress?: string;
    }): Promise<{
        tokenId: string;
        poolTonReserve: string;
        poolTokenReserve: string;
        lpTotalShares: string;
        ownerWalletAddress: string | null;
        yourShares: string;
        yourTonNano: string;
        yourTokens: string;
        yourSharePct: number;
    }>;
    getPortfolio(userId: number): Promise<{
        tokenId: string;
        listingId: string;
        projectId: string;
        projectName: string;
        symbol: string;
        name: string;
        logoFilename: string;
        balance: number;
        avgBuyTon: number;
        priceTon: number;
        valueTon: number;
        costTon: number;
        pnlTon: number;
    }[]>;
}
export declare const appStoreService: AppStoreService;
export {};
//# sourceMappingURL=app-store.service.d.ts.map