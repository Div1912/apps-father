"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProposeActionTool = exports.QuestionnaireTool = void 0;
exports.wrapAskTool = wrapAskTool;
var QuestionnaireTool_1 = require("./QuestionnaireTool");
Object.defineProperty(exports, "QuestionnaireTool", { enumerable: true, get: function () { return QuestionnaireTool_1.QuestionnaireTool; } });
var ProposeActionTool_1 = require("./ProposeActionTool");
Object.defineProperty(exports, "ProposeActionTool", { enumerable: true, get: function () { return ProposeActionTool_1.ProposeActionTool; } });
/**
 * Adapt an AskTool (which only needs the read-only AskContext) so the router
 * can use it. Avoids duplicating ReadFile / ListFiles / DbQuery / etc.
 *
 * RouterContext extends AskContext, so the AskTool's execute method receives
 * a structurally-compatible object — no actual delegation needed beyond the
 * type erasure here.
 */
function wrapAskTool(askTool) {
    return {
        name: askTool.name,
        definition: askTool.definition,
        execute(args, ctx) {
            return askTool.execute(args, ctx);
        },
    };
}
//# sourceMappingURL=index.js.map