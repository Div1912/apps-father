"use strict";
/**
 * Agent training knowledge — lessons (runtime rules) and code patches (manual IDE fixes).
 *
 * Two storage models share one import/export pipeline:
 *   - AgentLesson    — text rule injected into buildSystemPrompt() when enabled.
 *   - AgentCodePatch — text suggestion for editing agent.service.ts / agent_knowledge/*.md.
 *                      Never applied automatically; admin copies cursorPrompt to IDE.
 *
 * Per-env state (enabled flag, status transitions, timestamps, importedFrom, sourceCaseId,
 * appliedCommit) is preserved on the local environment and never overwritten by import.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.invalidateCache = invalidateCache;
exports.listLessons = listLessons;
exports.getLesson = getLesson;
exports.createLesson = createLesson;
exports.updateLesson = updateLesson;
exports.deleteLesson = deleteLesson;
exports.setLessonEnabled = setLessonEnabled;
exports.bulkSetLessonEnabled = bulkSetLessonEnabled;
exports.listPatches = listPatches;
exports.getPatch = getPatch;
exports.createPatch = createPatch;
exports.updatePatch = updatePatch;
exports.deletePatch = deletePatch;
exports.setPatchStatus = setPatchStatus;
exports.exportKnowledge = exportKnowledge;
exports.previewImport = previewImport;
exports.applyImport = applyImport;
exports.getEnabledLessonsBlock = getEnabledLessonsBlock;
const crypto_1 = __importDefault(require("crypto"));
const db_1 = require("../db");
// ──────────────────────────────────────────────────────────────────────────
// Cache for runtime injection — invalidated on every lesson mutation.
// ──────────────────────────────────────────────────────────────────────────
let cachedLessonsBlock = null;
function invalidateCache() {
    cachedLessonsBlock = null;
}
// ──────────────────────────────────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────────────────────────────────
function makeId(prefix) {
    // Compact, URL-safe stable id. Prisma's cuid would be fine too; rolling our
    // own keeps the prefix obvious in logs and JSON files.
    return `${prefix}_${crypto_1.default.randomBytes(9).toString("base64url")}`;
}
function normalizeTags(tags) {
    if (!Array.isArray(tags))
        return [];
    return Array.from(new Set(tags
        .map((t) => String(t || "").trim().toLowerCase())
        .filter(Boolean))).sort();
}
function normalizeFiles(files) {
    if (!Array.isArray(files))
        return [];
    return Array.from(new Set(files
        .map((f) => String(f || "").trim())
        .filter(Boolean))).sort();
}
function hashLesson(rule, context, tags) {
    const payload = JSON.stringify({
        rule: String(rule || "").trim(),
        context: String(context || "").trim(),
        tags: normalizeTags(tags),
    });
    return "sha256:" + crypto_1.default.createHash("sha256").update(payload).digest("hex");
}
function hashPatch(p) {
    const payload = JSON.stringify({
        title: String(p.title || "").trim(),
        problem: String(p.problem || "").trim(),
        targetFiles: normalizeFiles(p.targetFiles),
        suggestion: String(p.suggestion || "").trim(),
        cursorPrompt: String(p.cursorPrompt || "").trim(),
        tags: normalizeTags(p.tags),
    });
    return "sha256:" + crypto_1.default.createHash("sha256").update(payload).digest("hex");
}
function envName() {
    // Heuristic: the existing deploy script names PM2 processes "apps-father"
    // (prod) and "apps-father-dev" (dev). Allow override via env var.
    const explicit = process.env.AGENT_ENV_NAME;
    if (explicit)
        return explicit;
    if ((process.env.NODE_ENV || "").toLowerCase() === "development")
        return "dev";
    if (process.env.PM2_HOME && /dev/i.test(process.env.PM2_HOME))
        return "dev";
    return "prod";
}
// ──────────────────────────────────────────────────────────────────────────
// Lessons CRUD
// ──────────────────────────────────────────────────────────────────────────
async function listLessons(filter) {
    const where = {};
    if (typeof filter?.enabled === "boolean")
        where.enabled = filter.enabled;
    if (filter?.tag)
        where.tags = { has: filter.tag };
    if (filter?.q) {
        const q = filter.q;
        where.OR = [
            { rule: { contains: q, mode: "insensitive" } },
            { context: { contains: q, mode: "insensitive" } },
            { notes: { contains: q, mode: "insensitive" } },
        ];
    }
    return db_1.prisma.agentLesson.findMany({
        where,
        orderBy: [{ enabled: "desc" }, { updatedAt: "desc" }],
    });
}
async function getLesson(id) {
    return db_1.prisma.agentLesson.findUnique({ where: { id } });
}
async function createLesson(input) {
    const rule = String(input.rule || "").trim();
    if (!rule)
        throw Object.assign(new Error("rule is required"), { status: 400 });
    const context = input.context ? String(input.context).trim() || null : null;
    const tags = normalizeTags(input.tags);
    const notes = input.notes ? String(input.notes).trim() || null : null;
    const contentHash = hashLesson(rule, context, tags);
    const lesson = await db_1.prisma.agentLesson.create({
        data: {
            id: makeId("lsn"),
            rule,
            context,
            tags,
            notes,
            contentHash,
            enabled: false,
        },
    });
    invalidateCache();
    return lesson;
}
async function updateLesson(id, patch) {
    const existing = await db_1.prisma.agentLesson.findUnique({ where: { id } });
    if (!existing)
        throw Object.assign(new Error("Lesson not found"), { status: 404 });
    const next = {
        rule: patch.rule !== undefined
            ? String(patch.rule).trim()
            : existing.rule,
        context: patch.context !== undefined
            ? patch.context
                ? String(patch.context).trim() || null
                : null
            : existing.context,
        tags: patch.tags !== undefined ? normalizeTags(patch.tags) : existing.tags,
        notes: patch.notes !== undefined
            ? patch.notes
                ? String(patch.notes).trim() || null
                : null
            : existing.notes,
    };
    if (!next.rule)
        throw Object.assign(new Error("rule is required"), { status: 400 });
    const contentHash = hashLesson(next.rule, next.context, next.tags);
    const updated = await db_1.prisma.agentLesson.update({
        where: { id },
        data: { ...next, contentHash },
    });
    invalidateCache();
    return updated;
}
async function deleteLesson(id) {
    await db_1.prisma.agentLesson.delete({ where: { id } });
    invalidateCache();
}
async function setLessonEnabled(id, enabled) {
    const now = new Date();
    const updated = await db_1.prisma.agentLesson.update({
        where: { id },
        data: {
            enabled,
            enabledAt: enabled ? now : undefined,
            disabledAt: enabled ? undefined : now,
        },
    });
    invalidateCache();
    return updated;
}
async function bulkSetLessonEnabled(ids, enabled) {
    if (!Array.isArray(ids) || ids.length === 0)
        return { count: 0 };
    const now = new Date();
    const result = await db_1.prisma.agentLesson.updateMany({
        where: { id: { in: ids } },
        data: {
            enabled,
            enabledAt: enabled ? now : undefined,
            disabledAt: enabled ? undefined : now,
        },
    });
    invalidateCache();
    return result;
}
// ──────────────────────────────────────────────────────────────────────────
// Code Patches CRUD
// ──────────────────────────────────────────────────────────────────────────
async function listPatches(filter) {
    const where = {};
    if (filter?.status)
        where.status = filter.status;
    if (filter?.tag)
        where.tags = { has: filter.tag };
    if (filter?.q) {
        const q = filter.q;
        where.OR = [
            { title: { contains: q, mode: "insensitive" } },
            { problem: { contains: q, mode: "insensitive" } },
            { suggestion: { contains: q, mode: "insensitive" } },
            { cursorPrompt: { contains: q, mode: "insensitive" } },
            { notes: { contains: q, mode: "insensitive" } },
        ];
    }
    return db_1.prisma.agentCodePatch.findMany({
        where,
        orderBy: [{ status: "asc" }, { updatedAt: "desc" }],
    });
}
async function getPatch(id) {
    return db_1.prisma.agentCodePatch.findUnique({ where: { id } });
}
async function createPatch(input) {
    const title = String(input.title || "").trim();
    const problem = String(input.problem || "").trim();
    const suggestion = String(input.suggestion || "").trim();
    const cursorPrompt = String(input.cursorPrompt || "").trim();
    if (!title)
        throw Object.assign(new Error("title is required"), { status: 400 });
    if (!problem)
        throw Object.assign(new Error("problem is required"), { status: 400 });
    if (!suggestion)
        throw Object.assign(new Error("suggestion is required"), { status: 400 });
    if (!cursorPrompt)
        throw Object.assign(new Error("cursorPrompt is required"), { status: 400 });
    const targetFiles = normalizeFiles(input.targetFiles);
    const tags = normalizeTags(input.tags);
    const notes = input.notes ? String(input.notes).trim() || null : null;
    const contentHash = hashPatch({
        title,
        problem,
        targetFiles,
        suggestion,
        cursorPrompt,
        tags,
    });
    return db_1.prisma.agentCodePatch.create({
        data: {
            id: makeId("pat"),
            title,
            problem,
            targetFiles,
            suggestion,
            cursorPrompt,
            tags,
            notes,
            contentHash,
            status: "proposed",
        },
    });
}
async function updatePatch(id, patch) {
    const existing = await db_1.prisma.agentCodePatch.findUnique({ where: { id } });
    if (!existing)
        throw Object.assign(new Error("Patch not found"), { status: 404 });
    const next = {
        title: patch.title !== undefined ? String(patch.title).trim() : existing.title,
        problem: patch.problem !== undefined ? String(patch.problem).trim() : existing.problem,
        targetFiles: patch.targetFiles !== undefined
            ? normalizeFiles(patch.targetFiles)
            : existing.targetFiles,
        suggestion: patch.suggestion !== undefined ? String(patch.suggestion).trim() : existing.suggestion,
        cursorPrompt: patch.cursorPrompt !== undefined
            ? String(patch.cursorPrompt).trim()
            : existing.cursorPrompt,
        tags: patch.tags !== undefined ? normalizeTags(patch.tags) : existing.tags,
        notes: patch.notes !== undefined
            ? patch.notes
                ? String(patch.notes).trim() || null
                : null
            : existing.notes,
    };
    if (!next.title)
        throw Object.assign(new Error("title is required"), { status: 400 });
    if (!next.problem)
        throw Object.assign(new Error("problem is required"), { status: 400 });
    if (!next.suggestion)
        throw Object.assign(new Error("suggestion is required"), { status: 400 });
    if (!next.cursorPrompt)
        throw Object.assign(new Error("cursorPrompt is required"), { status: 400 });
    const contentHash = hashPatch(next);
    return db_1.prisma.agentCodePatch.update({
        where: { id },
        data: { ...next, contentHash },
    });
}
async function deletePatch(id) {
    await db_1.prisma.agentCodePatch.delete({ where: { id } });
}
async function setPatchStatus(id, status, opts) {
    if (!["proposed", "applied", "rejected"].includes(status)) {
        throw Object.assign(new Error("Invalid status"), { status: 400 });
    }
    const now = new Date();
    const data = {
        status,
        appliedAt: status === "applied" ? now : null,
        rejectedAt: status === "rejected" ? now : null,
    };
    if (status === "applied" && opts?.commit)
        data.appliedCommit = opts.commit.trim();
    if (status === "proposed")
        data.appliedCommit = null;
    return db_1.prisma.agentCodePatch.update({ where: { id }, data });
}
async function exportKnowledge(opts) {
    const include = opts?.include && opts.include.length > 0 ? opts.include : ["lessons", "patches"];
    const wantLessons = include.includes("lessons");
    const wantPatches = include.includes("patches");
    const [lessons, patches] = await Promise.all([
        wantLessons
            ? db_1.prisma.agentLesson.findMany({ orderBy: { id: "asc" } })
            : Promise.resolve([]),
        wantPatches
            ? db_1.prisma.agentCodePatch.findMany({ orderBy: { id: "asc" } })
            : Promise.resolve([]),
    ]);
    const file = {
        exportVersion: 1,
        exportedAt: new Date().toISOString(),
        exportedFrom: envName(),
        counts: { lessons: lessons.length, patches: patches.length },
        lessons: lessons.map((l) => ({
            id: l.id,
            rule: l.rule,
            context: l.context ?? null,
            tags: l.tags || [],
            notes: l.notes ?? null,
            contentHash: l.contentHash,
        })),
        patches: patches.map((p) => ({
            id: p.id,
            title: p.title,
            problem: p.problem,
            targetFiles: p.targetFiles || [],
            suggestion: p.suggestion,
            cursorPrompt: p.cursorPrompt,
            tags: p.tags || [],
            notes: p.notes ?? null,
            contentHash: p.contentHash,
        })),
    };
    // Pretty-print, no BOM. Stable key ordering thanks to ESM property iteration.
    const json = JSON.stringify(file, null, 2) + "\n";
    const date = new Date().toISOString().slice(0, 10);
    const filename = `agent-knowledge-${file.exportedFrom}-${date}.json`;
    return { json, filename };
}
// ──────────────────────────────────────────────────────────────────────────
// Import — preview + apply
// ──────────────────────────────────────────────────────────────────────────
function parseImportJson(raw) {
    let parsed;
    try {
        parsed = JSON.parse(raw);
    }
    catch (err) {
        throw Object.assign(new Error(`Invalid JSON: ${err.message}`), { status: 400 });
    }
    if (!parsed || typeof parsed !== "object") {
        throw Object.assign(new Error("Import file must be a JSON object"), { status: 400 });
    }
    if (parsed.exportVersion !== 1) {
        throw Object.assign(new Error(`Unsupported exportVersion: ${parsed.exportVersion}`), { status: 400 });
    }
    parsed.lessons = Array.isArray(parsed.lessons) ? parsed.lessons : [];
    parsed.patches = Array.isArray(parsed.patches) ? parsed.patches : [];
    parsed.exportedFrom = String(parsed.exportedFrom || "unknown");
    parsed.exportedAt = String(parsed.exportedAt || new Date().toISOString());
    return parsed;
}
function diffLessonFields(local, incoming) {
    const fields = [];
    if (String(local.rule || "") !== String(incoming.rule || ""))
        fields.push("rule");
    if (String(local.context || "") !== String(incoming.context || ""))
        fields.push("context");
    const localTags = JSON.stringify(normalizeTags(local.tags));
    const incomingTags = JSON.stringify(normalizeTags(incoming.tags));
    if (localTags !== incomingTags)
        fields.push("tags");
    if (String(local.notes || "") !== String(incoming.notes || ""))
        fields.push("notes");
    return fields;
}
function diffPatchFields(local, incoming) {
    const fields = [];
    if (String(local.title || "") !== String(incoming.title || ""))
        fields.push("title");
    if (String(local.problem || "") !== String(incoming.problem || ""))
        fields.push("problem");
    if (JSON.stringify(normalizeFiles(local.targetFiles)) !==
        JSON.stringify(normalizeFiles(incoming.targetFiles))) {
        fields.push("targetFiles");
    }
    if (String(local.suggestion || "") !== String(incoming.suggestion || "")) {
        fields.push("suggestion");
    }
    if (String(local.cursorPrompt || "") !== String(incoming.cursorPrompt || "")) {
        fields.push("cursorPrompt");
    }
    if (JSON.stringify(normalizeTags(local.tags)) !== JSON.stringify(normalizeTags(incoming.tags))) {
        fields.push("tags");
    }
    if (String(local.notes || "") !== String(incoming.notes || ""))
        fields.push("notes");
    return fields;
}
async function previewImport(rawJson) {
    const file = parseImportJson(rawJson);
    const [localLessons, localPatches] = await Promise.all([
        db_1.prisma.agentLesson.findMany(),
        db_1.prisma.agentCodePatch.findMany(),
    ]);
    const localLessonById = new Map(localLessons.map((l) => [l.id, l]));
    const localPatchById = new Map(localPatches.map((p) => [p.id, p]));
    const lessonsDiff = {
        new: [],
        updated: [],
        identical: [],
        localOnly: [],
    };
    const patchesDiff = {
        new: [],
        updated: [],
        identical: [],
        localOnly: [],
    };
    const incomingLessonIds = new Set();
    for (const inc of file.lessons) {
        incomingLessonIds.add(inc.id);
        const local = localLessonById.get(inc.id);
        if (!local) {
            lessonsDiff.new.push(inc);
        }
        else if (local.contentHash === inc.contentHash) {
            lessonsDiff.identical.push(inc);
        }
        else {
            lessonsDiff.updated.push({
                local,
                incoming: inc,
                fieldsChanged: diffLessonFields(local, inc),
            });
        }
    }
    for (const local of localLessons) {
        if (!incomingLessonIds.has(local.id))
            lessonsDiff.localOnly.push(local);
    }
    const incomingPatchIds = new Set();
    for (const inc of file.patches) {
        incomingPatchIds.add(inc.id);
        const local = localPatchById.get(inc.id);
        if (!local) {
            patchesDiff.new.push(inc);
        }
        else if (local.contentHash === inc.contentHash) {
            patchesDiff.identical.push(inc);
        }
        else {
            patchesDiff.updated.push({
                local,
                incoming: inc,
                fieldsChanged: diffPatchFields(local, inc),
            });
        }
    }
    for (const local of localPatches) {
        if (!incomingPatchIds.has(local.id))
            patchesDiff.localOnly.push(local);
    }
    return {
        exportedFrom: file.exportedFrom,
        exportedAt: file.exportedAt,
        lessons: lessonsDiff,
        patches: patchesDiff,
    };
}
async function applyImport(rawJson, options = {}) {
    const file = parseImportJson(rawJson);
    const enableNew = options.enableNewLessons === true;
    const lessonActions = options.lessonActions || {};
    const patchActions = options.patchActions || {};
    const sourceEnv = file.exportedFrom;
    const result = {
        lessons: { created: 0, updated: 0, skipped: 0 },
        patches: { created: 0, updated: 0, skipped: 0 },
    };
    const now = new Date();
    for (const inc of file.lessons) {
        const action = lessonActions[inc.id] || "skip";
        if (action === "skip") {
            result.lessons.skipped++;
            continue;
        }
        const local = await db_1.prisma.agentLesson.findUnique({ where: { id: inc.id } });
        const tags = normalizeTags(inc.tags);
        const contentHash = inc.contentHash || hashLesson(inc.rule, inc.context ?? null, tags);
        if (!local) {
            // New: create with enabled flag from option (default false)
            await db_1.prisma.agentLesson.create({
                data: {
                    id: inc.id,
                    rule: inc.rule,
                    context: inc.context ?? null,
                    tags,
                    notes: inc.notes ?? null,
                    contentHash,
                    enabled: enableNew,
                    enabledAt: enableNew ? now : null,
                    importedFrom: sourceEnv,
                },
            });
            result.lessons.created++;
        }
        else if (action === "update") {
            // Update content fields only — never touch enabled / enabledAt / disabledAt.
            await db_1.prisma.agentLesson.update({
                where: { id: inc.id },
                data: {
                    rule: inc.rule,
                    context: inc.context ?? null,
                    tags,
                    notes: inc.notes ?? null,
                    contentHash,
                    importedFrom: sourceEnv,
                },
            });
            result.lessons.updated++;
        }
        else {
            result.lessons.skipped++;
        }
    }
    for (const inc of file.patches) {
        const action = patchActions[inc.id] || "skip";
        if (action === "skip") {
            result.patches.skipped++;
            continue;
        }
        const local = await db_1.prisma.agentCodePatch.findUnique({ where: { id: inc.id } });
        const tags = normalizeTags(inc.tags);
        const targetFiles = normalizeFiles(inc.targetFiles);
        const contentHash = inc.contentHash ||
            hashPatch({
                title: inc.title,
                problem: inc.problem,
                targetFiles,
                suggestion: inc.suggestion,
                cursorPrompt: inc.cursorPrompt,
                tags,
            });
        if (!local) {
            // New patches always land as proposed — applying code is always a local decision.
            await db_1.prisma.agentCodePatch.create({
                data: {
                    id: inc.id,
                    title: inc.title,
                    problem: inc.problem,
                    targetFiles,
                    suggestion: inc.suggestion,
                    cursorPrompt: inc.cursorPrompt,
                    tags,
                    notes: inc.notes ?? null,
                    contentHash,
                    status: "proposed",
                    importedFrom: sourceEnv,
                },
            });
            result.patches.created++;
        }
        else if (action === "update") {
            // Update content; preserve local status / appliedAt / rejectedAt / appliedCommit.
            await db_1.prisma.agentCodePatch.update({
                where: { id: inc.id },
                data: {
                    title: inc.title,
                    problem: inc.problem,
                    targetFiles,
                    suggestion: inc.suggestion,
                    cursorPrompt: inc.cursorPrompt,
                    tags,
                    notes: inc.notes ?? null,
                    contentHash,
                    importedFrom: sourceEnv,
                },
            });
            result.patches.updated++;
        }
        else {
            result.patches.skipped++;
        }
    }
    invalidateCache();
    return result;
}
// ──────────────────────────────────────────────────────────────────────────
// Runtime injection
// ──────────────────────────────────────────────────────────────────────────
/**
 * Returns a formatted block for inclusion in the agent's system prompt.
 * Empty string when no lessons are enabled. Cached in memory until any
 * mutation calls invalidateCache().
 */
async function getEnabledLessonsBlock() {
    if (cachedLessonsBlock !== null)
        return cachedLessonsBlock;
    const lessons = await db_1.prisma.agentLesson.findMany({
        where: { enabled: true },
        orderBy: { enabledAt: "asc" },
    });
    if (lessons.length === 0) {
        cachedLessonsBlock = "";
        return cachedLessonsBlock;
    }
    const lines = [
        "=== LEARNED RULES (from past feedback) ===",
        "You have learned these rules from prior user feedback. Apply them strictly.",
        "",
    ];
    for (const l of lessons) {
        const tags = l.tags || [];
        const tagPrefix = tags.length > 0 ? `[${tags.join(", ")}] ` : "";
        lines.push(`${tagPrefix}${l.rule}`);
        if (l.context && l.context.trim()) {
            lines.push(`  Context: ${l.context.trim()}`);
        }
        lines.push("");
    }
    lines.push("==========================================");
    cachedLessonsBlock = lines.join("\n");
    return cachedLessonsBlock;
}
//# sourceMappingURL=agent-lessons.service.js.map