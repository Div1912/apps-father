export interface Plan {
    appName: string;
    tagline: string;
    category: string;
    audience: string;
    coreLoop: string;
    features: string[];
    screens: {
        name: string;
        purpose: string;
        actions: string[];
    }[];
    monetization: {
        model: "telegram_stars" | "ads" | "subscription" | "ton" | "none";
        details: string;
    };
    assumptions?: string[];
    outOfScope?: string[];
}
export interface PlanCritique {
    scores: {
        clarity: number;
        scope_fit: number;
        telegram_fit: number;
        mobile_ux: number;
        monetization_sense: number;
    };
    fixes: string[];
}
export interface PlanUsage {
    model: string;
    inputTokens: number;
    outputTokens: number;
    cacheReadTokens: number;
    cacheWriteTokens: number;
    phase: "draft" | "critique" | "fixup";
}
export interface GeneratePlanResult {
    /** Markdown rendered from the structured plan — what the user sees. */
    plan: string;
    /** Structured plan (kept in memory for downstream use; not yet persisted). */
    planJson: Plan;
    /** Critique result if the critique pass ran. */
    critique?: PlanCritique;
    /** Per-phase / per-model token usage for accurate billing. */
    usages: PlanUsage[];
    /** Aggregate input tokens across all phases (legacy convenience). */
    inputTokens: number;
    /** Aggregate output tokens across all phases (legacy convenience). */
    outputTokens: number;
}
export interface GeneratePlanOptions {
    description: string;
    assetPaths?: string[];
    lang?: string;
    /** Default true. Set false to disable critique + fixup pass (saves ~$0.001 + latency). */
    enableCritique?: boolean;
}
export declare function formatPlanMarkdown(p: Plan, lang?: string): string;
export declare class PlannerService {
    private client;
    constructor();
    generatePlan(opts: GeneratePlanOptions): Promise<GeneratePlanResult>;
    private runDraft;
    private runCritique;
    private runFixup;
}
export declare const plannerService: PlannerService;
//# sourceMappingURL=planner.service.d.ts.map