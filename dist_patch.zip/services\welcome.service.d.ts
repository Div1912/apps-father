import { Lang } from "../bot/i18n";
/**
 * Send the /start welcome message via the Bot HTTP API.
 *
 * Used when a NEW user opens the Mini App directly (e.g. via
 * `t.me/apps_father_bot/app?startapp=...`) instead of issuing /start in the
 * bot. This way the user still sees the welcome card + Open App button in
 * their bot chat the very first time they show up, regardless of entry point.
 *
 * If the user has not yet allowed PM (or the chat doesn't exist yet) the
 * Telegram API will respond with 403 — we just log and move on; the Mini App
 * itself is already open in front of them.
 */
export declare function sendBotWelcome(telegramId: number, lang?: Lang, startParam?: string | null): Promise<void>;
//# sourceMappingURL=welcome.service.d.ts.map