"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Agent = exports.AgentAbortedError = void 0;
exports.createAgent = createAgent;
/**
 * Low-level agent executor with a fluent builder interface.
 *
 * Responsibilities:
 *   - Read session config from runtimeConfig (model, tokens, iterations, thinking)
 *   - Accept system prompt, messages, tools, and optional RunContext
 *   - Route execution to the appropriate runner (AgentRunner / AskRunner / RouterRunner)
 *
 * Does NOT orchestrate sessions, build prompts, log to DB, or broadcast WebSocket events.
 * Use agent-session.service.ts for full session orchestration.
 */
const runtime_config_service_1 = require("./runtime-config.service");
const AgentRunner_1 = require("./agent/AgentRunner");
const AskRunner_1 = require("./agent/AskRunner");
const RouterRunner_1 = require("./agent/RouterRunner");
const crypto_1 = __importDefault(require("crypto"));
class AgentAbortedError extends Error {
    inputTokens;
    outputTokens;
    cacheWriteTokens;
    cacheReadTokens;
    model;
    constructor(model, inputTokens, outputTokens, cacheWriteTokens, cacheReadTokens) {
        super("ABORTED");
        this.model = model;
        this.inputTokens = inputTokens;
        this.outputTokens = outputTokens;
        this.cacheWriteTokens = cacheWriteTokens;
        this.cacheReadTokens = cacheReadTokens;
    }
}
exports.AgentAbortedError = AgentAbortedError;
// ── Fluent Agent class ────────────────────────────────────────────────────────
/**
 * Fluent builder for a single LLM agent invocation.
 *
 * Usage:
 *   const result = await new Agent("build")
 *     .setSystemPrompt(sp)
 *     .setMessages(msgs)
 *     .setTools(AGENT_TOOL_INSTANCES)
 *     .setRawTools(SERVER_TOOLS)
 *     .setContext(ctx)
 *     .executeAsAgent();
 */
class Agent {
    _sessionType;
    _cfg;
    _systemPrompt = "";
    _messages = [];
    _tools = [];
    _rawTools = [];
    _runContext;
    constructor(sessionType) {
        this._sessionType = sessionType;
        this._cfg = { ...runtime_config_service_1.runtimeConfig.getSessionConfig(sessionType) };
    }
    // ── Config overrides (override runtimeConfig defaults) ────────────────────
    setModel(model) {
        this._cfg = { ...this._cfg, model };
        return this;
    }
    setMaxTokens(n) {
        this._cfg = { ...this._cfg, max_tokens: n };
        return this;
    }
    setIterations(n) {
        this._cfg = { ...this._cfg, iterations: n };
        return this;
    }
    setThinking(budget) {
        this._cfg = { ...this._cfg, thinking: budget };
        return this;
    }
    // ── Run configuration ─────────────────────────────────────────────────────
    setSystemPrompt(sp) {
        this._systemPrompt = sp;
        return this;
    }
    setMessages(msgs) {
        this._messages = msgs;
        return this;
    }
    setTools(tools) {
        this._tools = tools;
        return this;
    }
    setRawTools(tools) {
        this._rawTools = tools;
        return this;
    }
    setContext(ctx) {
        this._runContext = ctx;
        return this;
    }
    // ── Execution modes ───────────────────────────────────────────────────────
    /**
     * Full agentic run with tool loop. Requires setContext() first.
     */
    async executeAsAgent() {
        if (!this._runContext) {
            throw new Error("[Agent] RunContext required — call setContext() before executeAsAgent()");
        }
        return new AgentRunner_1.AgentRunner()
            .setContext(this._runContext)
            .setSystemPrompt(this._systemPrompt)
            .setTools(this._tools)
            .setRawToolDefs(this._rawTools)
            .setMessages(this._messages)
            .run();
    }
    /**
     * Lightweight ask/answer run with streaming text output.
     */
    async executeAsAsker(opts) {
        return new AskRunner_1.AskRunner().run({
            modelCfg: this._buildModelCfg(),
            systemPrompt: this._systemPrompt,
            messages: this._messages,
            tools: this._tools,
            ctx: opts.ctx,
            onChunk: opts.onChunk,
            telegramId: opts.telegramId,
            sessionId: opts.sessionId ?? crypto_1.default.randomUUID(),
        });
    }
    /**
     * Router classification run. Returns proposal status and free-form text.
     */
    async executeAsRouter(ctx, opts) {
        return new RouterRunner_1.RouterRunner().run({
            modelCfg: this._buildModelCfg(),
            systemPrompt: this._systemPrompt,
            messages: this._messages,
            tools: this._tools,
            ctx,
            onToolCall: opts?.onToolCall,
            telegramId: opts?.telegramId,
            sessionId: opts?.sessionId ?? crypto_1.default.randomUUID(),
        });
    }
    // ── Helpers ───────────────────────────────────────────────────────────────
    _buildModelCfg() {
        return {
            modelId: this._cfg.model,
            provider: this._cfg.provider,
            maxTokens: this._cfg.max_tokens,
            maxIterations: this._cfg.iterations,
            thinkingBudget: this._cfg.thinking > 0 ? this._cfg.thinking : undefined,
            reasoningBudget: this._cfg.reasoning ? 8000 : undefined,
        };
    }
}
exports.Agent = Agent;
/** Convenience factory — mirrors `new Agent(sessionType)`. */
function createAgent(sessionType) {
    return new Agent(sessionType);
}
//# sourceMappingURL=agent.service.js.map