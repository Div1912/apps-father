"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SKILLS_DIR = exports.INSTRUCTIONS_DIR = exports.KNOWLEDGE_DIR = exports.PROJECTS_DIR = void 0;
const path_1 = __importDefault(require("path"));
exports.PROJECTS_DIR = path_1.default.join(process.cwd(), "projects");
exports.KNOWLEDGE_DIR = path_1.default.join(process.cwd(), "agent_knowledge");
exports.INSTRUCTIONS_DIR = path_1.default.join(exports.KNOWLEDGE_DIR, "instructions");
exports.SKILLS_DIR = path_1.default.join(exports.KNOWLEDGE_DIR, "skills");
//# sourceMappingURL=paths.js.map