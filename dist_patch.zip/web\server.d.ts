import http from "http";
import express from "express";
export declare function createWebServer(): import("express-serve-static-core").Express;
export declare function getExpressApp(): express.Application | null;
export declare function getHttpServer(): http.Server<typeof http.IncomingMessage, typeof http.ServerResponse> | null;
export declare function startWebServer(): Promise<void>;
//# sourceMappingURL=server.d.ts.map