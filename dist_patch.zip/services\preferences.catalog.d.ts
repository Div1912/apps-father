/**
 * Preferences catalog — single source of truth for the visual preferences
 * questionnaire shown after the user's first prompt.
 *
 * - This module owns the *catalog* (categories, options, preview specs, labels).
 * - The actual agent rules for each option live as markdown under
 *   `agent_knowledge/preferences/{category}/{option}.md` so writers can edit
 *   them like any other instruction file. They are loaded lazily and cached.
 *
 * Same definitions are consumed by:
 *   - the mini-app modal (renders `preview` into live cards)
 *   - the planner prompt (`buildPreferencesPrompt`)
 *   - the build agent's `buildApp` user prompt (same builder)
 */
/**
 * Sentinel value meaning "user delegated this category to the AI".
 * When stored under any preference key the rules markdown is NOT loaded
 * and that whole category is OMITTED from the preferences prompt block,
 * leaving the agent free to make its own judgment for that axis.
 */
export declare const AUTO_PREFERENCE = "__auto__";
export type PreferenceCategoryId = "kind" | "gameDimension" | "gameGenre" | "gameArtStyle" | "gameControls" | "botKeyboardStyle" | "style" | "theme" | "header" | "density" | "bottomMenu";
export interface StylePreviewSpec {
    kind: "style";
    bg: string;
    surface: string;
    text: string;
    textMuted: string;
    primary: string;
    primaryText: string;
    accent: string;
    border: string;
    displayFont: string;
    bodyFont: string;
    radius: number;
    shadow: string;
}
export interface ThemePreviewSpec {
    kind: "theme";
    mode: "light" | "dark" | "auto";
}
export interface HeaderPreviewSpec {
    kind: "header";
    layout: "minimal" | "branded" | "large_title";
}
export interface DensityPreviewSpec {
    kind: "density";
    rowHeight: number;
    gap: number;
}
export interface BottomMenuPreviewSpec {
    kind: "bottomMenu";
    layout: "tabbar" | "tabbar_pill" | "tabbar_glass" | "tabbar_fab" | "floating_cta" | "action_grid" | "none";
}
export interface KindPreviewSpec {
    kind: "kind";
    variant: "app" | "game" | "textBot";
}
export interface BotKeyboardStylePreviewSpec {
    kind: "botKeyboardStyle";
    scheme: "reply" | "inline" | "commands" | "mixed";
}
export interface GameDimensionPreviewSpec {
    kind: "gameDimension";
    dimension: "2d" | "3d";
}
export interface GameGenrePreviewSpec {
    kind: "gameGenre";
    genre: "arcade" | "runner" | "puzzle" | "shooter" | "platformer" | "sandbox";
}
export interface GameArtStylePreviewSpec {
    kind: "gameArtStyle";
    art: "voxel" | "low_poly" | "flat" | "pixel" | "wireframe";
}
export interface GameControlsPreviewSpec {
    kind: "gameControls";
    scheme: "touch" | "swipe" | "dpad" | "tilt";
}
export type PreviewSpec = StylePreviewSpec | ThemePreviewSpec | HeaderPreviewSpec | DensityPreviewSpec | BottomMenuPreviewSpec | KindPreviewSpec | GameDimensionPreviewSpec | GameGenrePreviewSpec | GameArtStylePreviewSpec | GameControlsPreviewSpec | BotKeyboardStylePreviewSpec;
export interface PreferenceOption {
    id: string;
    label: string;
    description: string;
    preview: PreviewSpec;
}
export interface PreferenceCategory {
    id: PreferenceCategoryId;
    label: string;
    prompt: string;
    options: PreferenceOption[];
    /**
     * Conditional gating. When set, this category is only shown in the modal
     * (and only contributes to the prompt) if every listed key in the
     * current selection matches one of the listed values. AUTO on a gating
     * category falls back to that category's default value.
     *
     * Example: `{ kind: ["app"] }` means "only relevant when the user picks
     * App (or leaves Kind on Auto, which defaults to App)".
     */
    appliesWhen?: Partial<Record<PreferenceCategoryId, string[]>>;
}
export interface ProjectPreferences {
    kind: string;
    gameDimension: string;
    gameGenre: string;
    gameArtStyle: string;
    gameControls: string;
    botKeyboardStyle: string;
    style: string;
    theme: string;
    header: string;
    density: string;
    bottomMenu: string;
}
export declare const PREFERENCES_CATALOG: PreferenceCategory[];
export declare const DEFAULT_PREFERENCES: ProjectPreferences;
/**
 * True when this category's `appliesWhen` constraint (if any) is satisfied
 * by the current selection. Used by both `buildPreferencesPrompt` and the
 * frontend modal (mirrored in `mini_app/app.js`).
 */
export declare function isCategoryActive(cat: PreferenceCategory, prefs: ProjectPreferences): boolean;
export interface ValidatePreferencesResult {
    ok: boolean;
    prefs: ProjectPreferences;
    errors: {
        key: string;
        reason: string;
    }[];
}
/**
 * Parse + validate a raw preferences object/string.
 *
 * - Drops unknown ids and replaces them with defaults.
 * - Always returns a fully-populated `ProjectPreferences` so downstream
 *   prompt builders never see `undefined`.
 * - `ok` is true only if every key resolves to a known option.
 */
export declare function validatePreferences(raw: unknown): ValidatePreferencesResult;
/**
 * Build the strict, non-negotiable PREFERENCES block prepended to planner
 * and build-agent prompts. Always returns a non-empty string (defaults
 * are used if anything is missing). Reads each chosen option's rules from
 * `agent_knowledge/preferences/<cat>/<opt>.md` so writers can iterate on
 * the rules without touching code.
 */
export declare function buildPreferencesPrompt(prefs: ProjectPreferences | null | undefined): string;
/** Convenience: parse the JSON column into ProjectPreferences (or null). */
export declare function parseProjectPreferences(raw: string | null | undefined): ProjectPreferences | null;
//# sourceMappingURL=preferences.catalog.d.ts.map