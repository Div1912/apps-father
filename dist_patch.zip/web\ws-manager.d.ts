import { WebSocket } from "ws";
import { IncomingMessage } from "http";
export interface ProjectWss {
    clients: Set<WebSocket>;
    broadcast(data: any): void;
    broadcastExcept(sender: WebSocket, data: any): void;
    onConnection(handler: (socket: WebSocket, req: IncomingMessage) => void): void;
}
/**
 * Force-reload a project's WebSocket handler.
 * Closes all connected clients (they will auto-reconnect), clears timers,
 * closes the DB, and removes the cached state so the next connection
 * re-initializes from the latest routes.js on disk.
 */
export declare function forceReloadProjectWs(projectId: string, isDev: boolean): void;
export declare function setupWebSocket(server: import("http").Server, miniAppWss?: import("ws").WebSocketServer): import("ws").Server<typeof import("ws"), typeof IncomingMessage>;
//# sourceMappingURL=ws-manager.d.ts.map