import type { AskTool } from "./AskTool";
import type { AskContext } from "./AskContext";
export declare class ReadFileAskTool implements AskTool {
    name: string;
    definition: {
        type: string;
        function: {
            name: string;
            description: string;
            parameters: {
                type: string;
                properties: {
                    path: {
                        type: string;
                        description: string;
                    };
                    offset: {
                        type: string;
                        description: string;
                    };
                    limit: {
                        type: string;
                        description: string;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
        };
    };
    execute(args: Record<string, any>, ctx: AskContext): Promise<string>;
    private _safePath;
}
//# sourceMappingURL=ReadFileAskTool.d.ts.map