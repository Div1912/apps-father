"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerConversationHandlers = registerConversationHandlers;
function registerConversationHandlers(_bot) {
    // All conversation handlers removed — Mini App API handles everything now
}
//# sourceMappingURL=conversation.js.map