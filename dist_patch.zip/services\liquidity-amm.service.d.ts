/**
 * Liquidity AMM service — V2 of the App Store token economy.
 *
 * Replaces the virtual-reserve bonding curve with a real Uniswap-V2-style
 * constant-product pool:
 *
 *   x = realTonReserve   (nanoTON held by platform vault)
 *   y = realTokenReserve (atomic Jettons held by platform vault)
 *   k = x * y            (invariant, only changes on add/remove liquidity)
 *
 * Trading (constant-product, fee subtracted from the input):
 *   buy : Δy = y * (Δx_net) / (x + Δx_net)
 *   sell: Δx = x * (Δy)     / (y + Δy)
 *   spot price = x / y     (TON per atomic token)
 *
 * Liquidity (Uniswap V2-style shares):
 *   first add → shares = floor(sqrt(Δx * Δy))
 *   later add → shares = min(Δx * S / x, Δy * S / y)   (S = lpTotalShares)
 *   remove    → tonOut   = shares * x / S
 *               tokenOut = shares * y / S
 *
 * The platform vault custodies the TON + Jettons; the LP "ownership" is
 * tracked off-chain via the LiquidityPosition table (keyed by the
 * publisher's TON wallet address). This is intentionally simpler than
 * minting on-chain LP jettons — we use the publisher's ownership address
 * as the source of truth, which matches how the user signs every deposit
 * and withdrawal from their own TonConnect wallet.
 */
export declare const NANO = 1000000000n;
export declare const TOKEN_UNIT = 1000000000n;
export declare function tonToNano(ton: number | string): bigint;
export declare function nanoToTon(nano: bigint): number;
export declare function tokensToAtomic(tokens: number | string): bigint;
export declare function atomicToTokens(atomic: bigint): number;
export interface PoolState {
    realTonReserve: bigint;
    realTokenReserve: bigint;
    lpTotalShares: bigint;
}
export interface BuyQuote {
    tokensOut: bigint;
    feeNano: bigint;
    netTonNano: bigint;
    newTonReserve: bigint;
    newTokenReserve: bigint;
    priceImpactBps: number;
}
export interface SellQuote {
    tonOutNet: bigint;
    tonOutGross: bigint;
    feeNano: bigint;
    newTonReserve: bigint;
    newTokenReserve: bigint;
    priceImpactBps: number;
}
/**
 * Quote a buy. `tonInNano` is the gross TON the user pays. Fee is taken
 * off the input before the swap, in line with most DEXes.
 */
export declare function quoteBuy(state: PoolState, tonInNano: bigint, feePercent: number): BuyQuote;
/** Quote a sell. `tokensIn` is in atomic units. Fee comes off TON output. */
export declare function quoteSell(state: PoolState, tokensIn: bigint, feePercent: number): SellQuote;
/** Spot price in nanoTON per WHOLE token. */
export declare function spotPriceNano(state: PoolState): bigint;
/** Fully-diluted market cap (price × totalSupply), in nanoTON. */
export declare function marketCapNano(state: PoolState, totalSupply: bigint): bigint;
export interface LiquidityAddQuote {
    shares: bigint;
    /** Adjusted TON to deposit (caller may have been over-quoted). */
    tonNano: bigint;
    /** Adjusted tokens to deposit (caller may have been over-quoted). */
    tokensAtomic: bigint;
    /** True for first-ever deposit; price is set entirely by caller. */
    isFirstDeposit: boolean;
}
/**
 * Quote how many LP shares the depositor receives. For non-empty pools the
 * smaller of the two ratios decides (excess of the other side is silently
 * truncated — the pool keeps its current price untouched).
 */
export declare function quoteAddLiquidity(state: PoolState, tonNanoIn: bigint, tokensIn: bigint): LiquidityAddQuote;
export interface LiquidityRemoveQuote {
    tonNanoOut: bigint;
    tokensOut: bigint;
}
export declare function quoteRemoveLiquidity(state: PoolState, sharesToBurn: bigint): LiquidityRemoveQuote;
export interface ExecuteBuyResult {
    tokenId: string;
    userId: number;
    tokensOut: bigint;
    feeNano: bigint;
    priceNano: bigint;
}
export declare function executeBuy(opts: {
    tokenId: string;
    userId: number;
    tonInNano: bigint;
    tradeId: string;
    txHashIn?: string;
}): Promise<ExecuteBuyResult>;
export interface ExecuteSellResult {
    tokenId: string;
    userId: number;
    tonOutNet: bigint;
    feeNano: bigint;
    priceNano: bigint;
}
export declare function executeSell(opts: {
    tokenId: string;
    userId: number;
    tokensIn: bigint;
    tradeId: string;
    txHashIn?: string;
}): Promise<ExecuteSellResult>;
export declare function markTradeSettled(tradeId: string, txHashOut?: string): Promise<void>;
export interface ApplyLiquidityResult {
    positionId: string;
    shares: bigint;
    newTotalShares: bigint;
    newTonReserve: bigint;
    newTokenReserve: bigint;
}
/**
 * Apply a confirmed liquidity deposit (init or add) to the DB. Both legs
 * (TON + Jetton) must be present in the same call — typically the caller
 * is the TON monitor that buffered the matching pair before invoking.
 */
export declare function applyLiquidityDeposit(opts: {
    tokenId: string;
    ownerWalletAddress: string;
    userId?: number | null;
    tonNanoIn: bigint;
    tokensIn: bigint;
    type: "init" | "add";
    txHash?: string;
}): Promise<ApplyLiquidityResult>;
export interface ApplyLiquidityRemoveResult {
    positionId: string;
    sharesBurned: bigint;
    tonOutNano: bigint;
    tokensOut: bigint;
    newTonReserve: bigint;
    newTokenReserve: bigint;
}
/**
 * Apply a confirmed liquidity withdrawal: burn `sharesToBurn` from the
 * caller's position and credit them with the proportional TON + tokens.
 * Returns the amounts the platform must pay out (the actual on-chain
 * payouts are dispatched by the caller, e.g. a hot-wallet payout step).
 */
export declare function applyLiquidityRemove(opts: {
    tokenId: string;
    ownerWalletAddress: string;
    sharesToBurn: bigint;
    txHash?: string;
}): Promise<ApplyLiquidityRemoveResult>;
//# sourceMappingURL=liquidity-amm.service.d.ts.map