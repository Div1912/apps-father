import { GeneratedApp } from "../types";
export declare class ClaudeService {
    private getProviderRouting;
    private streamMessage;
    generatePlan(description: string, assets?: string[], lang?: string, onChunk?: (delta: string, full: string) => void): Promise<{
        plan: string;
        inputTokens: number;
        outputTokens: number;
    }>;
    generateApp(description: string, plan: string, projectId: string, assets?: string[]): Promise<GeneratedApp>;
    generateUpdate(existingCode: string, updateDescription: string, projectId: string): Promise<GeneratedApp>;
    suggestImprovements(description: string, plan: string, lang?: string): Promise<{
        suggestions: string[];
        inputTokens: number;
        outputTokens: number;
    }>;
}
export declare const claudeService: ClaudeService;
//# sourceMappingURL=claude.service.d.ts.map