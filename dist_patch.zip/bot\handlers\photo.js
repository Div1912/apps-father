"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerPhotoHandlers = registerPhotoHandlers;
function registerPhotoHandlers(_bot) {
    // Photo handlers removed — file uploads handled via Mini App now
}
//# sourceMappingURL=photo.js.map