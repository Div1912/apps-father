"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BUILD_TOOL_DEFS = void 0;
exports.BUILD_TOOL_DEFS = [
    {
        name: "ask_user",
        description: "Ask the app owner a question and wait for their answer. Use ONLY when you truly need user input (API keys, credentials, external account IDs, design choices, naming, or choosing between fundamentally different approaches). If a requested feature requires an API key/credential and no public no-key alternative exists, you MUST call ask_user instead of inventing placeholders, using process.env, or shipping fake/mock behavior. Do NOT use for trivial implementation details you can decide yourself. Provide options as buttons when possible. The user can also type free text or press Skip.",
        input_schema: {
            type: "object",
            properties: {
                question: { type: "string", description: "The question to ask the user" },
                options: { type: "array", items: { type: "string" }, description: "Optional list of choices shown as buttons (e.g. ['Option A', 'Option B'])" },
            },
            required: ["question"],
        },
    },
    {
        name: "technical_plan",
        description: "MANDATORY first planning tool for new builds. Submit the concrete implementation contract before writing code. The schema is kind-specific: App uses dbKeys/restEndpoints/wsMessages/screens; Text Bot uses stateShape/conversationFlow/keyboards/commands/testScenarios; Game uses coordinateSystem/sceneGraph/camera/input/collision/stateMachine/performanceBudget. If the app needs external APIs, list them in externalDependencies and call ask_user first for any required credentials. After this, code must match the submitted names exactly.",
        input_schema: {
            type: "object",
            properties: {
                kind: { type: "string", enum: ["app", "game", "textBot"], description: "Project kind this plan targets" },
                summary: { type: "string", description: "One-sentence architecture summary" },
                dbKeys: { type: "array", items: { type: "object" }, description: "DB key contracts: key pattern + stored shape" },
                restEndpoints: { type: "array", items: { type: "object" }, description: "REST contracts: method, path, auth, input, output" },
                wsMessages: { type: "array", items: { type: "object" }, description: "WebSocket message contracts with direction/type/fields" },
                screens: { type: "array", items: { type: "object" }, description: "Frontend screens/components and their data/events" },
                botBehavior: { type: "array", items: { type: "object" }, description: "Optional bot commands/callback/deep-link behaviour for Mini Apps" },
                stateShape: { type: "object", description: "Text Bot state object stored under state:{uid}" },
                conversationFlow: { type: "array", items: { type: "object" }, description: "Text Bot steps/buttons/callbacks and transitions" },
                keyboards: { type: "array", items: { type: "object" }, description: "Text Bot reply/inline keyboards with exact button labels/callback_data" },
                commands: { type: "array", items: { type: "object" }, description: "Bot slash commands: command + description" },
                testScenarios: { type: "array", items: { type: "object" }, description: "Test cases the agent must run with simulate_* before finish" },
                externalDependencies: { type: "array", items: { type: "object" }, description: "External APIs/providers used, whether credentials are required, and whether ask_user is needed before implementation" },
                coordinateSystem: { type: "string", description: "Game coordinate system" },
                sceneGraph: { type: "array", items: { type: "object" }, description: "Game scene/group/object graph" },
                camera: { type: "object", description: "Game camera type/follow/smoothing" },
                input: { type: "array", items: { type: "object" }, description: "Game input mapping" },
                collision: { type: "object", description: "Game collision/win-loss rules" },
                stateMachine: { type: "array", items: { type: "string" }, description: "Game state machine" },
                performanceBudget: { type: "object", description: "Game FPS, pixel ratio, reuse/instancing budget" },
            },
            required: ["kind", "summary"],
        },
    },
    {
        name: "server_logs",
        description: "Read recent logs for this project: routes.js console.log/error output, webhook errors, simulate_telegram and simulate_api results. Call after deploy_to_dev or simulate_* to debug behaviour.",
        input_schema: {
            type: "object",
            properties: {
                lines: { type: "number", description: "How many recent log lines to return (default 50, max 200)" },
            },
            required: [],
        },
    },
    {
        name: "simulate_telegram",
        description: "Simulate a Telegram update (message or callback_query) hitting the bot webhook WITHOUT a real Telegram account. The test user always gets id=-100. All tg() API calls the bot makes are intercepted and returned. Also logged so server_logs shows them. Use after deploy_to_dev to test the bot flow end-to-end.",
        input_schema: {
            type: "object",
            properties: {
                update: {
                    type: "object",
                    description: "Telegram Update object. For a text message: { message: { from: { id: -100, first_name: 'Test', language_code: 'en' }, chat: { id: -100, type: 'private' }, text: '/start' } }. For a callback: { callback_query: { id: '1', from: { id: -100, first_name: 'Test' }, message: { chat: { id: -100 }, message_id: 1 }, data: 'like:123' } }",
                },
            },
            required: ["update"],
        },
    },
    {
        name: "simulate_api",
        description: "Simulate an HTTP request to the app's backend API routes as a Telegram test user. Defaults to id=-100; pass userId/firstName/username to test multi-user flows. Returns status and response body. Use to test REST endpoints in routes.js.",
        input_schema: {
            type: "object",
            properties: {
                method: { type: "string", description: "HTTP method: GET, POST, PUT, DELETE (default GET)" },
                path: { type: "string", description: "API path relative to the project, e.g. /tasks or /tasks/123" },
                body: { type: "object", description: "Request body for POST/PUT" },
                expectStatus: { type: "number", description: "Optional expected HTTP status for negative tests, e.g. 400 or 401" },
                userId: { type: "number", description: "Telegram user id for this request (default -100). Use different ids for multi-user tests." },
                firstName: { type: "string", description: "Optional Telegram first_name for this simulated user" },
                username: { type: "string", description: "Optional Telegram username for this simulated user" },
            },
            required: ["path"],
        },
    },
    {
        name: "simulate_ws",
        description: "Simulate project WebSocket traffic only: open fake client connections, send the explicit messages you provide, and capture outbound WebSocket data. Does not seed DB, does not run REST API steps, and does not send default/auth/setup messages. Uses an in-memory DB snapshot so project WS code cannot persist test mutations.",
        input_schema: {
            type: "object",
            properties: {
                scenarioId: { type: "string", description: "Optional id matching a technical_plan.testScenarios item" },
                clients: {
                    type: "array",
                    items: { type: "object" },
                    description: "Optional fake clients to connect before sending messages: [{ id: 'a', userId: -100 }, { id: 'b', userId: -101 }]. If omitted, clients are inferred from message clientId values.",
                },
                messages: {
                    type: "array",
                    items: { type: "object" },
                    description: "Required messages to send after connections open: [{ clientId: 'a', data: { type: 'auth', initData: '...' } }, { clientId: 'a', data: { type: 'ping' } }]. Data is sent exactly as provided.",
                },
                expectTypes: {
                    type: "array",
                    items: { type: "string" },
                    description: "Server WebSocket event types expected from this simulation. If omitted, validation falls back to planned server WS types.",
                },
            },
            required: ["messages"],
        },
    },
    {
        name: "set_bot_commands",
        description: "Safely set the bot slash-command menu with Telegram setMyCommands. Use for Text Bots after configure_app. Commands must all be handled in /bot-webhook.",
        input_schema: {
            type: "object",
            properties: {
                commands: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            command: { type: "string", description: "Command without leading slash, e.g. start" },
                            description: { type: "string", description: "Short user-facing description" },
                        },
                        required: ["command", "description"],
                    },
                },
            },
            required: ["commands"],
        },
    },
    {
        name: "deploy_to_dev",
        description: "Deploy your current code to the development environment for live testing. Runs syntax/contract validators first. After calling this, frontend is available at /dev/{projectId}/, API at /devapi/{projectId}/, and WS at /devws/{projectId}. Call this before simulate_api, simulate_telegram, or simulate_ws.",
        input_schema: {
            type: "object",
            properties: {},
            required: [],
        },
    },
    {
        name: "finish",
        description: "Atomically finish the build: save short user-facing summary, detailed technical summary, and signal completion - all in ONE call. This is the ONLY way to finish a build. Call this LAST, after technical_plan, file writes, deploy_to_dev, validators, and required simulate_* tests pass. There is NO separate done/summary/short_summary tool.",
        input_schema: {
            type: "object",
            properties: {
                shortSummary: {
                    type: "string",
                    description: "Short user-facing summary, format: 'Update title (3-5 words)\\n\\n1-2 sentences in simple non-technical language.' No jargon.",
                },
                summary: {
                    type: "string",
                    description: "Detailed technical summary/changelog: architecture decisions, new files, changes made, anything the next update should know.",
                },
                context_diff: {
                    type: "string",
                    description: "Short delta for the project passport (1-3 sentences). Describe NEW or REMOVED routes, DB keys, screens, key decisions, or architectural changes from THIS commit only. Used to incrementally update the passport without re-reading the codebase. If empty, the platform falls back to the first line of `summary`. Examples: 'Added /api/leaderboard returning top-10 by score from db.users.' / 'Removed legacy /api/stats-v1; replaced by /api/stats which paginates.' / 'New screen #profile with avatar upload via /api/upload-avatar.'",
                },
            },
            required: ["shortSummary", "summary"],
        },
    },
    {
        name: "configure_app",
        description: "Save the app's name, description, long description, and menu button text in Apps Father core DB, then configure the Telegram bot if it is already linked. ONLY use on FIRST build, never on updates. If no bot token is connected yet, the saved data will be applied automatically when the bot is later created and connected. Use this instead of direct Telegram Bot API calls.",
        input_schema: {
            type: "object",
            properties: {
                name: { type: "string", description: "App and bot display name (up to 64 chars)" },
                description: { type: "string", description: "Short app/bot description shown in Telegram previews (up to 120 chars)" },
                longDescription: { type: "string", description: "Long bot profile description shown in Telegram profile (up to 512 chars)" },
                menuButtonText: { type: "string", description: "Text for the Mini App menu button (e.g. 'Launch App'). Use empty string for Text Bots." },
            },
            required: ["name", "description", "longDescription"],
        },
    },
];
//# sourceMappingURL=build-tools.js.map