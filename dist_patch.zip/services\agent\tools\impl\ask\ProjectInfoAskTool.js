"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProjectInfoAskTool = void 0;
const project_service_1 = require("../../../../../services/project.service");
const features_service_1 = require("../../../../../services/features.service");
class ProjectInfoAskTool {
    name = "project_info";
    definition = {
        type: "function",
        function: {
            name: "project_info",
            description: "Get high-level metadata about THIS project: name, description, plan presence, last update, status, and which paid features are unlocked.",
            parameters: { type: "object", properties: {}, additionalProperties: false },
        },
    };
    async execute(_args, ctx) {
        const p = await project_service_1.projectService.getProject(ctx.projectId);
        if (!p)
            return "Project not found.";
        const features = await (0, features_service_1.getProjectFeatures)(ctx.projectId).catch(() => []);
        const info = {
            name: p.name || "(unnamed)",
            status: p.status || "unknown",
            description: (p.description || "").substring(0, 1500),
            hasPlan: !!p.plan,
            createdAt: p.createdAt ? new Date(p.createdAt).toISOString().slice(0, 10) : null,
            updatedAt: p.updatedAt ? new Date(p.updatedAt).toISOString().slice(0, 10) : null,
            botUsername: p.botUsername || null,
            paidFeatures: {
                telegram_stars: features.includes("telegram_stars") ? "UNLOCKED" : "LOCKED",
                ton_payment: features.includes("ton_payment") ? "UNLOCKED" : "LOCKED",
            },
        };
        return JSON.stringify(info, null, 2);
    }
}
exports.ProjectInfoAskTool = ProjectInfoAskTool;
//# sourceMappingURL=ProjectInfoAskTool.js.map