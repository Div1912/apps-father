"use strict";
/**
 * Liquidity AMM service — V2 of the App Store token economy.
 *
 * Replaces the virtual-reserve bonding curve with a real Uniswap-V2-style
 * constant-product pool:
 *
 *   x = realTonReserve   (nanoTON held by platform vault)
 *   y = realTokenReserve (atomic Jettons held by platform vault)
 *   k = x * y            (invariant, only changes on add/remove liquidity)
 *
 * Trading (constant-product, fee subtracted from the input):
 *   buy : Δy = y * (Δx_net) / (x + Δx_net)
 *   sell: Δx = x * (Δy)     / (y + Δy)
 *   spot price = x / y     (TON per atomic token)
 *
 * Liquidity (Uniswap V2-style shares):
 *   first add → shares = floor(sqrt(Δx * Δy))
 *   later add → shares = min(Δx * S / x, Δy * S / y)   (S = lpTotalShares)
 *   remove    → tonOut   = shares * x / S
 *               tokenOut = shares * y / S
 *
 * The platform vault custodies the TON + Jettons; the LP "ownership" is
 * tracked off-chain via the LiquidityPosition table (keyed by the
 * publisher's TON wallet address). This is intentionally simpler than
 * minting on-chain LP jettons — we use the publisher's ownership address
 * as the source of truth, which matches how the user signs every deposit
 * and withdrawal from their own TonConnect wallet.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TOKEN_UNIT = exports.NANO = void 0;
exports.tonToNano = tonToNano;
exports.nanoToTon = nanoToTon;
exports.tokensToAtomic = tokensToAtomic;
exports.atomicToTokens = atomicToTokens;
exports.quoteBuy = quoteBuy;
exports.quoteSell = quoteSell;
exports.spotPriceNano = spotPriceNano;
exports.marketCapNano = marketCapNano;
exports.quoteAddLiquidity = quoteAddLiquidity;
exports.quoteRemoveLiquidity = quoteRemoveLiquidity;
exports.executeBuy = executeBuy;
exports.executeSell = executeSell;
exports.markTradeSettled = markTradeSettled;
exports.applyLiquidityDeposit = applyLiquidityDeposit;
exports.applyLiquidityRemove = applyLiquidityRemove;
const db_1 = require("../db");
const runtime_config_service_1 = require("./runtime-config.service");
exports.NANO = 1000000000n;
exports.TOKEN_UNIT = 1000000000n;
// ── Number / unit conversion ─────────────────────────────────────────────────
function tonToNano(ton) {
    const s = String(ton);
    if (!s.match(/^-?\d+(\.\d+)?$/))
        throw new Error(`tonToNano: invalid number ${s}`);
    const [whole, frac = ""] = s.split(".");
    const fracPadded = (frac + "000000000").slice(0, 9);
    return BigInt(whole) * exports.NANO + BigInt(fracPadded || "0");
}
function nanoToTon(nano) {
    return Number(nano) / Number(exports.NANO);
}
function tokensToAtomic(tokens) {
    return tonToNano(tokens);
}
function atomicToTokens(atomic) {
    return Number(atomic) / Number(exports.TOKEN_UNIT);
}
// Integer sqrt for BigInt (Newton's method).
function bigintSqrt(n) {
    if (n < 0n)
        throw new Error("sqrt of negative");
    if (n < 2n)
        return n;
    let x = n;
    let y = (x + 1n) >> 1n;
    while (y < x) {
        x = y;
        y = (x + n / x) >> 1n;
    }
    return x;
}
/**
 * Quote a buy. `tonInNano` is the gross TON the user pays. Fee is taken
 * off the input before the swap, in line with most DEXes.
 */
function quoteBuy(state, tonInNano, feePercent) {
    if (tonInNano <= 0n || state.realTonReserve <= 0n || state.realTokenReserve <= 0n) {
        return {
            tokensOut: 0n, feeNano: 0n, netTonNano: 0n,
            newTonReserve: state.realTonReserve, newTokenReserve: state.realTokenReserve,
            priceImpactBps: 0,
        };
    }
    const feeBps = BigInt(Math.round(feePercent * 100));
    const feeNano = (tonInNano * feeBps) / 10000n;
    const netTon = tonInNano - feeNano;
    const x = state.realTonReserve;
    const y = state.realTokenReserve;
    // Δy = y * Δx / (x + Δx)
    const tokensOut = (y * netTon) / (x + netTon);
    const newX = x + netTon;
    const newY = y - tokensOut;
    // Spot price moves x/y → newX/newY. Impact = |Δprice| / oldPrice.
    let impactBps = 0;
    if (y > 0n && newY > 0n) {
        // (newX/newY - x/y) / (x/y) = (newX*y - x*newY) / (x*newY)
        const num = newX * y - x * newY;
        const den = x * newY;
        if (den > 0n)
            impactBps = Number((num * 10000n) / den);
    }
    return {
        tokensOut, feeNano, netTonNano: netTon,
        newTonReserve: newX, newTokenReserve: newY,
        priceImpactBps: impactBps,
    };
}
/** Quote a sell. `tokensIn` is in atomic units. Fee comes off TON output. */
function quoteSell(state, tokensIn, feePercent) {
    if (tokensIn <= 0n || state.realTonReserve <= 0n || state.realTokenReserve <= 0n) {
        return {
            tonOutNet: 0n, tonOutGross: 0n, feeNano: 0n,
            newTonReserve: state.realTonReserve, newTokenReserve: state.realTokenReserve,
            priceImpactBps: 0,
        };
    }
    const x = state.realTonReserve;
    const y = state.realTokenReserve;
    // Δx = x * Δy / (y + Δy)
    let tonOutGross = (x * tokensIn) / (y + tokensIn);
    if (tonOutGross > x)
        tonOutGross = x;
    const feeBps = BigInt(Math.round(feePercent * 100));
    const feeNano = (tonOutGross * feeBps) / 10000n;
    const tonOutNet = tonOutGross - feeNano;
    const newX = x - tonOutGross;
    const newY = y + tokensIn;
    let impactBps = 0;
    if (y > 0n && newY > 0n) {
        const num = x * newY - newX * y;
        const den = x * newY;
        if (den > 0n)
            impactBps = Number((num * 10000n) / den);
    }
    return {
        tonOutNet, tonOutGross, feeNano,
        newTonReserve: newX, newTokenReserve: newY,
        priceImpactBps: impactBps,
    };
}
/** Spot price in nanoTON per WHOLE token. */
function spotPriceNano(state) {
    if (state.realTokenReserve <= 0n)
        return 0n;
    return (state.realTonReserve * exports.TOKEN_UNIT) / state.realTokenReserve;
}
/** Fully-diluted market cap (price × totalSupply), in nanoTON. */
function marketCapNano(state, totalSupply) {
    return (spotPriceNano(state) * totalSupply) / exports.TOKEN_UNIT;
}
/**
 * Quote how many LP shares the depositor receives. For non-empty pools the
 * smaller of the two ratios decides (excess of the other side is silently
 * truncated — the pool keeps its current price untouched).
 */
function quoteAddLiquidity(state, tonNanoIn, tokensIn) {
    if (state.lpTotalShares === 0n) {
        if (tonNanoIn <= 0n || tokensIn <= 0n) {
            throw new Error("First liquidity must include both TON and tokens");
        }
        const shares = bigintSqrt(tonNanoIn * tokensIn);
        return { shares, tonNano: tonNanoIn, tokensAtomic: tokensIn, isFirstDeposit: true };
    }
    if (state.realTonReserve <= 0n || state.realTokenReserve <= 0n) {
        throw new Error("Pool reserves are empty (impossible — corrupt state)");
    }
    const sharesFromTon = (tonNanoIn * state.lpTotalShares) / state.realTonReserve;
    const sharesFromTokens = (tokensIn * state.lpTotalShares) / state.realTokenReserve;
    // Use the smaller side; truncate the other so the price stays put.
    if (sharesFromTon < sharesFromTokens) {
        const requiredTokens = (tonNanoIn * state.realTokenReserve) / state.realTonReserve;
        return {
            shares: sharesFromTon,
            tonNano: tonNanoIn,
            tokensAtomic: requiredTokens,
            isFirstDeposit: false,
        };
    }
    else {
        const requiredTon = (tokensIn * state.realTonReserve) / state.realTokenReserve;
        return {
            shares: sharesFromTokens,
            tonNano: requiredTon,
            tokensAtomic: tokensIn,
            isFirstDeposit: false,
        };
    }
}
function quoteRemoveLiquidity(state, sharesToBurn) {
    if (sharesToBurn <= 0n || state.lpTotalShares <= 0n)
        return { tonNanoOut: 0n, tokensOut: 0n };
    if (sharesToBurn > state.lpTotalShares)
        throw new Error("Cannot burn more than total shares");
    const tonNanoOut = (sharesToBurn * state.realTonReserve) / state.lpTotalShares;
    const tokensOut = (sharesToBurn * state.realTokenReserve) / state.lpTotalShares;
    return { tonNanoOut, tokensOut };
}
async function executeBuy(opts) {
    const cfg = runtime_config_service_1.runtimeConfig.get().appStore;
    return db_1.prisma.$transaction(async (tx) => {
        const token = await tx.appToken.findUniqueOrThrow({ where: { id: opts.tokenId } });
        if (token.status !== "live")
            throw new Error(`Token not live (status=${token.status})`);
        const state = {
            realTonReserve: token.realTonReserve,
            realTokenReserve: token.realTokenReserve,
            lpTotalShares: token.lpTotalShares,
        };
        const q = quoteBuy(state, opts.tonInNano, cfg.tradingFeePercent);
        if (q.tokensOut <= 0n)
            throw new Error("Buy yields zero tokens");
        const creatorFee = (q.feeNano * BigInt(Math.round(cfg.creatorFeeShare * 1_000_000))) / 1000000n;
        const platformFee = q.feeNano - creatorFee;
        const priceNano = (opts.tonInNano * exports.TOKEN_UNIT) / q.tokensOut;
        await tx.appToken.update({
            where: { id: opts.tokenId },
            data: {
                realTonReserve: q.newTonReserve,
                realTokenReserve: q.newTokenReserve,
                soldSupply: { increment: q.tokensOut },
                feeBalanceNanoTon: { increment: platformFee },
                creatorFeeBalanceNanoTon: { increment: creatorFee },
            },
        });
        // Holding upsert with weighted-avg buy.
        const holding = await tx.tokenHolding.findUnique({
            where: { tokenId_userId: { tokenId: opts.tokenId, userId: opts.userId } },
        });
        let newBalance, newAvg;
        if (!holding) {
            newBalance = q.tokensOut;
            newAvg = priceNano;
        }
        else {
            newBalance = holding.balance + q.tokensOut;
            newAvg = newBalance > 0n
                ? (holding.balance * holding.avgBuyNanoTon + q.tokensOut * priceNano) / newBalance
                : 0n;
        }
        await tx.tokenHolding.upsert({
            where: { tokenId_userId: { tokenId: opts.tokenId, userId: opts.userId } },
            create: { tokenId: opts.tokenId, userId: opts.userId, balance: newBalance, avgBuyNanoTon: newAvg },
            update: { balance: newBalance, avgBuyNanoTon: newAvg },
        });
        await tx.tokenTrade.update({
            where: { id: opts.tradeId },
            data: {
                tokenAmount: q.tokensOut,
                priceNanoTon: priceNano,
                feeTonAmount: q.feeNano,
                txHashIn: opts.txHashIn,
                status: "received",
            },
        });
        const newState = {
            realTonReserve: q.newTonReserve,
            realTokenReserve: q.newTokenReserve,
            lpTotalShares: token.lpTotalShares,
        };
        const mcap = marketCapNano(newState, token.totalSupply);
        await tx.appListing.update({
            where: { id: token.listingId },
            data: {
                volume24hNanoTon: { increment: opts.tonInNano },
                marketCapNanoTon: mcap,
            },
        });
        return { tokenId: opts.tokenId, userId: opts.userId, tokensOut: q.tokensOut, feeNano: q.feeNano, priceNano };
    });
}
async function executeSell(opts) {
    const cfg = runtime_config_service_1.runtimeConfig.get().appStore;
    return db_1.prisma.$transaction(async (tx) => {
        const token = await tx.appToken.findUniqueOrThrow({ where: { id: opts.tokenId } });
        if (token.status !== "live")
            throw new Error(`Token not live (status=${token.status})`);
        const state = {
            realTonReserve: token.realTonReserve,
            realTokenReserve: token.realTokenReserve,
            lpTotalShares: token.lpTotalShares,
        };
        const q = quoteSell(state, opts.tokensIn, cfg.tradingFeePercent);
        if (q.tonOutGross <= 0n)
            throw new Error("Sell yields zero TON");
        const creatorFee = (q.feeNano * BigInt(Math.round(cfg.creatorFeeShare * 1_000_000))) / 1000000n;
        const platformFee = q.feeNano - creatorFee;
        const priceNano = (q.tonOutGross * exports.TOKEN_UNIT) / opts.tokensIn;
        await tx.appToken.update({
            where: { id: opts.tokenId },
            data: {
                realTonReserve: q.newTonReserve,
                realTokenReserve: q.newTokenReserve,
                feeBalanceNanoTon: { increment: platformFee },
                creatorFeeBalanceNanoTon: { increment: creatorFee },
            },
        });
        const holding = await tx.tokenHolding.findUnique({
            where: { tokenId_userId: { tokenId: opts.tokenId, userId: opts.userId } },
        });
        if (!holding || holding.balance < opts.tokensIn)
            throw new Error("Insufficient holding for sell");
        await tx.tokenHolding.update({
            where: { tokenId_userId: { tokenId: opts.tokenId, userId: opts.userId } },
            data: { balance: holding.balance - opts.tokensIn },
        });
        await tx.tokenTrade.update({
            where: { id: opts.tradeId },
            data: {
                tonAmount: q.tonOutNet,
                priceNanoTon: priceNano,
                feeTonAmount: q.feeNano,
                txHashIn: opts.txHashIn,
                status: "received",
            },
        });
        const mcap = marketCapNano({ realTonReserve: q.newTonReserve, realTokenReserve: q.newTokenReserve, lpTotalShares: token.lpTotalShares }, token.totalSupply);
        await tx.appListing.update({
            where: { id: token.listingId },
            data: {
                volume24hNanoTon: { increment: q.tonOutGross },
                marketCapNanoTon: mcap,
            },
        });
        return { tokenId: opts.tokenId, userId: opts.userId, tonOutNet: q.tonOutNet, feeNano: q.feeNano, priceNano };
    });
}
async function markTradeSettled(tradeId, txHashOut) {
    await db_1.prisma.tokenTrade.update({
        where: { id: tradeId },
        data: { status: "settled", txHashOut, settledAt: new Date() },
    });
}
/**
 * Apply a confirmed liquidity deposit (init or add) to the DB. Both legs
 * (TON + Jetton) must be present in the same call — typically the caller
 * is the TON monitor that buffered the matching pair before invoking.
 */
async function applyLiquidityDeposit(opts) {
    return db_1.prisma.$transaction(async (tx) => {
        const token = await tx.appToken.findUniqueOrThrow({ where: { id: opts.tokenId } });
        const state = {
            realTonReserve: token.realTonReserve,
            realTokenReserve: token.realTokenReserve,
            lpTotalShares: token.lpTotalShares,
        };
        const q = quoteAddLiquidity(state, opts.tonNanoIn, opts.tokensIn);
        const newTon = state.realTonReserve + q.tonNano;
        const newTokens = state.realTokenReserve + q.tokensAtomic;
        const newTotalShares = state.lpTotalShares + q.shares;
        // Token state.
        const newStatus = opts.type === "init" ? "live" : token.status;
        const newOwner = opts.type === "init"
            ? (token.ownerWalletAddress || opts.ownerWalletAddress)
            : token.ownerWalletAddress;
        await tx.appToken.update({
            where: { id: opts.tokenId },
            data: {
                realTonReserve: newTon,
                realTokenReserve: newTokens,
                lpTotalShares: newTotalShares,
                status: newStatus,
                ownerWalletAddress: newOwner,
            },
        });
        // Position upsert keyed by (tokenId, ownerWalletAddress).
        const existing = await tx.liquidityPosition.findUnique({
            where: { tokenId_ownerWalletAddress: { tokenId: opts.tokenId, ownerWalletAddress: opts.ownerWalletAddress } },
        });
        let position;
        if (existing) {
            position = await tx.liquidityPosition.update({
                where: { id: existing.id },
                data: {
                    shares: existing.shares + q.shares,
                    cumTonDepositedNano: existing.cumTonDepositedNano + q.tonNano,
                    cumTokenDeposited: existing.cumTokenDeposited + q.tokensAtomic,
                    userId: opts.userId ?? existing.userId,
                },
            });
        }
        else {
            position = await tx.liquidityPosition.create({
                data: {
                    tokenId: opts.tokenId,
                    ownerWalletAddress: opts.ownerWalletAddress,
                    userId: opts.userId ?? null,
                    shares: q.shares,
                    cumTonDepositedNano: q.tonNano,
                    cumTokenDeposited: q.tokensAtomic,
                },
            });
        }
        await tx.liquidityEvent.create({
            data: {
                tokenId: opts.tokenId,
                positionId: position.id,
                ownerWalletAddress: opts.ownerWalletAddress,
                type: opts.type,
                tonNano: q.tonNano,
                tokenAmount: q.tokensAtomic,
                shares: q.shares,
                txHash: opts.txHash,
                status: "settled",
            },
        });
        // Refresh listing market cap.
        const mcap = marketCapNano({
            realTonReserve: newTon, realTokenReserve: newTokens, lpTotalShares: newTotalShares,
        }, token.totalSupply);
        await tx.appListing.update({
            where: { id: token.listingId },
            data: { marketCapNanoTon: mcap },
        });
        return {
            positionId: position.id,
            shares: q.shares,
            newTotalShares,
            newTonReserve: newTon,
            newTokenReserve: newTokens,
        };
    });
}
/**
 * Apply a confirmed liquidity withdrawal: burn `sharesToBurn` from the
 * caller's position and credit them with the proportional TON + tokens.
 * Returns the amounts the platform must pay out (the actual on-chain
 * payouts are dispatched by the caller, e.g. a hot-wallet payout step).
 */
async function applyLiquidityRemove(opts) {
    return db_1.prisma.$transaction(async (tx) => {
        const token = await tx.appToken.findUniqueOrThrow({ where: { id: opts.tokenId } });
        const position = await tx.liquidityPosition.findUnique({
            where: { tokenId_ownerWalletAddress: { tokenId: opts.tokenId, ownerWalletAddress: opts.ownerWalletAddress } },
        });
        if (!position)
            throw new Error("Position not found");
        if (position.shares < opts.sharesToBurn)
            throw new Error("Not enough shares to burn");
        const state = {
            realTonReserve: token.realTonReserve,
            realTokenReserve: token.realTokenReserve,
            lpTotalShares: token.lpTotalShares,
        };
        const q = quoteRemoveLiquidity(state, opts.sharesToBurn);
        if (q.tonNanoOut <= 0n && q.tokensOut <= 0n)
            throw new Error("Removal yields nothing");
        const newTon = state.realTonReserve - q.tonNanoOut;
        const newTokens = state.realTokenReserve - q.tokensOut;
        const newTotalShares = state.lpTotalShares - opts.sharesToBurn;
        await tx.appToken.update({
            where: { id: opts.tokenId },
            data: {
                realTonReserve: newTon,
                realTokenReserve: newTokens,
                lpTotalShares: newTotalShares,
            },
        });
        await tx.liquidityPosition.update({
            where: { id: position.id },
            data: {
                shares: position.shares - opts.sharesToBurn,
                cumTonWithdrawnNano: position.cumTonWithdrawnNano + q.tonNanoOut,
                cumTokenWithdrawn: position.cumTokenWithdrawn + q.tokensOut,
            },
        });
        await tx.liquidityEvent.create({
            data: {
                tokenId: opts.tokenId,
                positionId: position.id,
                ownerWalletAddress: opts.ownerWalletAddress,
                type: "remove",
                tonNano: -q.tonNanoOut,
                tokenAmount: -q.tokensOut,
                shares: -opts.sharesToBurn,
                txHash: opts.txHash,
                status: "settled",
            },
        });
        const mcap = marketCapNano({
            realTonReserve: newTon, realTokenReserve: newTokens, lpTotalShares: newTotalShares,
        }, token.totalSupply);
        await tx.appListing.update({
            where: { id: token.listingId },
            data: { marketCapNanoTon: mcap },
        });
        return {
            positionId: position.id,
            sharesBurned: opts.sharesToBurn,
            tonOutNano: q.tonNanoOut,
            tokensOut: q.tokensOut,
            newTonReserve: newTon,
            newTokenReserve: newTokens,
        };
    });
}
//# sourceMappingURL=liquidity-amm.service.js.map