/**
 * Console tagger — attaches a `[app:<projectId>]` prefix to every stdout/stderr
 * line written while inside a project's execution context.
 *
 * Usage:
 *   - Call `installConsoleTagger()` once at process start (before any user code).
 *   - Wrap any code that runs a user-generated app's `routes.js`/ws handlers in
 *     `runWithProject(projectId, () => { ... })`. AsyncLocalStorage propagates
 *     through promises, setTimeout, setInterval and `ws.on(...)` listeners
 *     registered inside the wrapped function, so transitive logs are tagged
 *     automatically — no need to modify the generated app code.
 *
 * The PM2-captured log file ends up looking like:
 *   2025-... [app:9f3a-...] User connected: 1234
 *   2025-... [BotRunner] Bot @foo started for project ...        <- core (untagged)
 *
 * The log viewer parses the `[app:<id>]` prefix to filter by project.
 */
/** Run `fn` so any console output produced (sync, in promises, in timers, in
 * event listeners registered while inside `fn`) is tagged with `projectId`. */
export declare function runWithProject<T>(projectId: string, fn: () => T): T;
/** Returns the current project ID if the running async chain is inside a
 * `runWithProject` block, otherwise `null`. */
export declare function getCurrentProjectId(): string | null;
/** Patch process.stdout/stderr.write so that every line emitted while inside a
 * `runWithProject` context is prefixed with `[app:<projectId>] `, AND every
 * line (project-tagged or core) is forked into the persistent `app_logs`
 * sink via app-log.service.ts.
 *
 * Tagging happens at the stream level (not at console.log) so multi-line
 * payloads (object inspection, stack traces, `\n`-containing strings) get
 * tagged on every line, not just the first. */
export declare function installConsoleTagger(): void;
//# sourceMappingURL=console-tagger.service.d.ts.map