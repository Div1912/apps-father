"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SERVER_TOOLS = exports.AGENT_TOOL_INSTANCES = void 0;
// ── Filesystem tools ──────────────────────────────────────────────────────────
const ListFilesTool_1 = require("./impl/filesystem/ListFilesTool");
const ReadFileTool_1 = require("./impl/filesystem/ReadFileTool");
const WriteFileTool_1 = require("./impl/filesystem/WriteFileTool");
const EditFileTool_1 = require("./impl/filesystem/EditFileTool");
const GrepTool_1 = require("./impl/filesystem/GrepTool");
const ShellTool_1 = require("./impl/filesystem/ShellTool");
const FetchUrlTool_1 = require("./impl/filesystem/FetchUrlTool");
// ── Build / workflow tools ────────────────────────────────────────────────────
const TechnicalPlanTool_1 = require("./impl/build/TechnicalPlanTool");
const DbTool_1 = require("./impl/build/DbTool");
const DeployToDevTool_1 = require("./impl/build/DeployToDevTool");
const LoadSkillTool_1 = require("./impl/build/LoadSkillTool");
const AskUserTool_1 = require("./impl/build/AskUserTool");
const ServerLogsTool_1 = require("./impl/build/ServerLogsTool");
const SimulateTelegramTool_1 = require("./impl/build/SimulateTelegramTool");
const SimulateApiTool_1 = require("./impl/build/SimulateApiTool");
const SimulateWsTool_1 = require("./impl/build/SimulateWsTool");
const ConfigureAppTool_1 = require("./impl/build/ConfigureAppTool");
const FinishTool_1 = require("./impl/build/FinishTool");
const VisualTestTool_1 = require("./impl/build/VisualTestTool");
const ImageGenerateTool_1 = require("./impl/build/ImageGenerateTool");
/**
 * All agent tool instances. Each exposes renderDefinition() (OpenAI schema)
 * and execute(args, ctx) (implementation). The AgentRunner builds the dispatch
 * map from these at run time.
 */
exports.AGENT_TOOL_INSTANCES = [
    new ListFilesTool_1.ListFilesTool(),
    new ReadFileTool_1.ReadFileTool(),
    new WriteFileTool_1.WriteFileTool(),
    new EditFileTool_1.EditFileTool(),
    new GrepTool_1.GrepTool(),
    new ShellTool_1.ShellTool(),
    new FetchUrlTool_1.FetchUrlTool(),
    new TechnicalPlanTool_1.TechnicalPlanTool(),
    new DbTool_1.DbTool(),
    new DeployToDevTool_1.DeployToDevTool(),
    new LoadSkillTool_1.LoadSkillTool(),
    new AskUserTool_1.AskUserTool(),
    new ServerLogsTool_1.ServerLogsTool(),
    new SimulateTelegramTool_1.SimulateTelegramTool(),
    new SimulateApiTool_1.SimulateApiTool(),
    new SimulateWsTool_1.SimulateWsTool(),
    new ConfigureAppTool_1.ConfigureAppTool(),
    new VisualTestTool_1.VisualTestTool(),
    new ImageGenerateTool_1.ImageGenerateTool(),
    new FinishTool_1.FinishTool(),
];
/** OpenRouter server tools — executed transparently by OpenRouter. */
exports.SERVER_TOOLS = [
    { type: "openrouter:datetime" },
    { type: "openrouter:web_search", parameters: { max_results: 5, max_total_results: 15 } },
    { type: "openrouter:web_fetch" },
];
//# sourceMappingURL=registry.js.map