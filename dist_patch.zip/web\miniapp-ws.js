"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.broadcastToProject = broadcastToProject;
exports.registerAnswerResolver = registerAnswerResolver;
exports.resolveAnswer = resolveAnswer;
exports.hasPendingAnswer = hasPendingAnswer;
exports.setupMiniAppWebSocket = setupMiniAppWebSocket;
exports.getMiniAppWss = getMiniAppWss;
const ws_1 = require("ws");
const crypto_1 = __importDefault(require("crypto"));
const config_1 = require("../config");
const clients = new Set();
const pendingAnswers = new Map();
function validateInitData(initData) {
    if (!initData)
        return { valid: false };
    try {
        const params = new URLSearchParams(initData);
        const hash = params.get("hash");
        if (!hash)
            return { valid: false };
        params.delete("hash");
        const entries = Array.from(params.entries());
        entries.sort(([a], [b]) => a.localeCompare(b));
        const dataCheckString = entries.map(([k, v]) => `${k}=${v}`).join("\n");
        const secretKey = crypto_1.default.createHmac("sha256", "WebAppData").update(config_1.config.botToken).digest();
        const computedHash = crypto_1.default.createHmac("sha256", secretKey).update(dataCheckString).digest("hex");
        if (computedHash !== hash)
            return { valid: false };
        let userData;
        try {
            userData = JSON.parse(params.get("user") || "{}");
        }
        catch {
            userData = {};
        }
        if (!userData.id)
            return { valid: false };
        return { valid: true, telegramId: userData.id, username: userData.username, firstName: userData.first_name };
    }
    catch {
        return { valid: false };
    }
}
function send(client, data) {
    if (client.ws.readyState === ws_1.WebSocket.OPEN) {
        client.ws.send(typeof data === "string" ? data : JSON.stringify(data));
    }
}
function broadcastToProject(projectId, data) {
    const msg = typeof data === "string" ? data : JSON.stringify(data);
    for (const c of clients) {
        if (c.subscribedProject === projectId && c.ws.readyState === ws_1.WebSocket.OPEN) {
            c.ws.send(msg);
        }
    }
}
function registerAnswerResolver(projectId, resolve) {
    pendingAnswers.set(projectId, resolve);
}
function resolveAnswer(projectId, answer) {
    const resolver = pendingAnswers.get(projectId);
    if (!resolver)
        return false;
    pendingAnswers.delete(projectId);
    resolver(answer);
    return true;
}
function hasPendingAnswer(projectId) {
    return pendingAnswers.has(projectId);
}
let miniAppWss = null;
function setupMiniAppWebSocket() {
    miniAppWss = new ws_1.WebSocketServer({ noServer: true });
    miniAppWss.on("connection", (ws, _req) => {
        const client = { ws };
        clients.add(client);
        ws.on("message", (raw) => {
            try {
                const data = JSON.parse(raw.toString());
                if (data.type === "auth") {
                    const auth = validateInitData(data.initData || "");
                    if (auth.valid) {
                        client.telegramId = auth.telegramId;
                        send(client, { type: "auth_ok", telegramId: auth.telegramId });
                    }
                    else {
                        send(client, { type: "auth_error", error: "Invalid initData" });
                    }
                    return;
                }
                if (data.type === "subscribe") {
                    if (!client.telegramId) {
                        send(client, { type: "error", error: "Not authenticated" });
                        return;
                    }
                    client.subscribedProject = data.projectId;
                    send(client, { type: "subscribed", projectId: data.projectId });
                    return;
                }
                if (data.type === "answer") {
                    if (!client.telegramId || !data.projectId)
                        return;
                    resolveAnswer(data.projectId, data.answer || "");
                    return;
                }
            }
            catch (err) {
                console.error("[MiniApp WS] Message parse error:", err);
            }
        });
        ws.on("close", () => {
            clients.delete(client);
        });
        ws.on("error", () => {
            clients.delete(client);
        });
    });
    console.log("[MiniApp WS] WebSocket handler ready (path: /telegram-mini-app/ws)");
    return miniAppWss;
}
function getMiniAppWss() {
    return miniAppWss;
}
//# sourceMappingURL=miniapp-ws.js.map