/**
 * Jetton service — deploy TIP-3 Jetton Master contracts on TON for App Store
 * tokens, plus mint / accept-back operations driven by the bonding curve.
 *
 * Two operation modes:
 *
 *  1. Real on-chain deploy. Requires the TIP-3 jetton minter + wallet code
 *     BoCs to be present at `data/jetton/jetton-minter.boc` and
 *     `data/jetton/jetton-wallet.boc` (admin places them after auditing). When
 *     present, deploys a brand-new master contract from the platform hot
 *     wallet, with the platform wallet as admin so we can later mint.
 *
 *  2. Simulation mode (default fallback). When the BoCs are missing OR
 *     `runtimeConfig.appStore.enabled` is false, deploy / mint / burn calls
 *     succeed with a fake `SIM_…` address and log a notice. This lets the
 *     full App Store UX (publish / browse / buy / sell from the user's
 *     custodial perspective) work end-to-end while we wait for the on-chain
 *     pieces to be audited and dropped in.
 */
export declare function isJettonInfraReady(): boolean;
export interface DeployResult {
    jettonMasterAddress: string;
    txHash: string;
    simulated: boolean;
}
/**
 * Deploy a jetton master from the platform hot wallet. The platform wallet
 * is the jetton admin, so it can later mint / change content / withdraw.
 */
export declare function deployJettonMaster(opts: {
    metadataUrl: string;
    /** Optional pre-mint to this address (in atomic units). 0 = no pre-mint. */
    initialMintTo?: string;
    initialMintAmount?: bigint;
}): Promise<DeployResult>;
/**
 * Mint jetton from the platform wallet (the master's admin). Used when a
 * user buys via the bonding curve — we mint the tokens directly to their
 * wallet so they appear in TonKeeper.
 */
export declare function mintJetton(opts: {
    jettonMasterAddress: string;
    to: string;
    amount: bigint;
}): Promise<{
    txHash: string;
    simulated: boolean;
}>;
/**
 * Send TON back to a user when they sell their jettons. The user has
 * already transferred jettons into the platform's jetton wallet (we don't
 * burn here — the platform holds the supply). This just dispatches the
 * payout TON.
 */
export declare function payoutTon(opts: {
    to: string;
    amountNano: bigint;
    comment?: string;
}): Promise<{
    txHash: string;
    simulated: boolean;
}>;
//# sourceMappingURL=jetton.service.d.ts.map