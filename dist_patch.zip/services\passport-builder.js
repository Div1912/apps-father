"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.passportBuilder = exports.PassportBuilder = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const convention_extractor_js_1 = require("./convention-extractor.js");
class PassportBuilder {
    build(opts) {
        const { projectName, description, commitDir, commitNum, doneSummary, keyDecisions, prevPassport } = opts;
        const fileTree = this.buildFileTree(commitDir);
        const npmPackages = this.readNpmPackages(commitDir);
        const dbKeys = this.readDbKeys(commitDir);
        const routes = this.extractRoutes(commitDir);
        const wsEvents = this.extractWebSocketEvents(commitDir);
        const screens = this.extractScreens(commitDir);
        const cssVars = this.extractCssVariables(commitDir);
        const codeLocations = this.extractCodeLocations(commitDir);
        const extractor = new convention_extractor_js_1.ConventionExtractor();
        const { structure, conventions } = extractor.extract(commitDir);
        const decisions = this.mergeDecisions(prevPassport, commitNum, keyDecisions);
        const history = this.buildHistory(prevPassport, commitNum, doneSummary, keyDecisions);
        const lines = [];
        lines.push(`## App: ${projectName || this.guessAppName(commitDir) || "Telegram Mini App"}`);
        lines.push(`Purpose: ${(description || "Telegram Mini App").split("\n")[0].trim()}`);
        lines.push("");
        lines.push("## Architecture");
        if (routes.length > 0) {
            lines.push("### API Routes");
            lines.push(...routes.map(r => `- ${r}`));
        }
        if (wsEvents.length > 0) {
            lines.push("### WebSocket Events");
            lines.push(...wsEvents.map(e => `- ${e}`));
        }
        if (screens.length > 0) {
            lines.push("### Screens / Containers");
            lines.push(...screens.map(s => `- ${s}`));
        }
        if (dbKeys) {
            lines.push("### DB Keys (sqlite kv)");
            lines.push(dbKeys);
        }
        if (npmPackages) {
            lines.push("### NPM Packages");
            lines.push(npmPackages);
        }
        lines.push("");
        if (codeLocations) {
            lines.push("## Code Locations");
            lines.push(codeLocations);
            lines.push("");
        }
        if (structure) {
            lines.push("## Code Structure (auto-extracted)");
            lines.push(structure);
            lines.push("");
        }
        if (conventions) {
            lines.push("## Code Conventions (auto-extracted)");
            lines.push(conventions);
            lines.push("");
        }
        if (cssVars.length > 0) {
            lines.push("## UI Theme (CSS Variables)");
            lines.push(...cssVars.map(v => `- ${v}`));
            lines.push("");
        }
        if (fileTree) {
            lines.push("## File Tree");
            lines.push("```");
            lines.push(fileTree);
            lines.push("```");
            lines.push("");
        }
        lines.push("## Key Decisions");
        if (decisions.length === 0) {
            lines.push("_(none recorded yet — pass `keyDecisions` to finish() to populate)_");
        }
        else {
            lines.push(...decisions);
        }
        lines.push("");
        const passportText = lines.join("\n").trim() + "\n";
        const combined = passportText + "\n## Update History\n" + history + "\n";
        return { passportText, history, combined };
    }
    // ──────────────────────────────────────────────────────────────────────
    // EXTRACTORS
    // ──────────────────────────────────────────────────────────────────────
    extractRoutes(commitDir) {
        const out = [];
        const scan = (rel) => {
            const p = path_1.default.join(commitDir, rel);
            if (!fs_1.default.existsSync(p))
                return;
            const lines = this.safeRead(p).split("\n");
            for (let i = 0; i < lines.length; i++) {
                const m = lines[i].match(/router\.(get|post|put|delete|patch|all)\s*\(\s*['"`]([^'"`]+)['"`]/);
                if (m)
                    out.push(`${rel}:${i + 1} — ${m[1].toUpperCase()} ${m[2]}`);
            }
        };
        const backendDir = path_1.default.join(commitDir, "backend");
        if (fs_1.default.existsSync(backendDir)) {
            for (const f of fs_1.default.readdirSync(backendDir)) {
                if (f.endsWith(".js"))
                    scan(`backend/${f}`);
            }
        }
        return out;
    }
    extractWebSocketEvents(commitDir) {
        const out = [];
        const scan = (rel) => {
            const p = path_1.default.join(commitDir, rel);
            if (!fs_1.default.existsSync(p))
                return;
            const lines = this.safeRead(p).split("\n");
            for (let i = 0; i < lines.length; i++) {
                const m = lines[i].match(/(?:socket|wss?)\.on\s*\(\s*['"`]([^'"`]+)['"`]/);
                if (m)
                    out.push(`${rel}:${i + 1} — '${m[1]}'`);
                const send = lines[i].match(/sendToProject\s*\(.*?,\s*\{\s*type:\s*['"`]([^'"`]+)['"`]/);
                if (send)
                    out.push(`${rel}:${i + 1} — sendToProject type='${send[1]}'`);
            }
        };
        const backendDir = path_1.default.join(commitDir, "backend");
        if (fs_1.default.existsSync(backendDir)) {
            for (const f of fs_1.default.readdirSync(backendDir)) {
                if (f.endsWith(".js"))
                    scan(`backend/${f}`);
            }
        }
        const fePath = path_1.default.join(commitDir, "frontend", "app.js");
        if (fs_1.default.existsSync(fePath)) {
            const lines = this.safeRead(fePath).split("\n");
            for (let i = 0; i < lines.length; i++) {
                const m = lines[i].match(/data\.type\s*===?\s*['"`]([^'"`]+)['"`]/);
                if (m)
                    out.push(`frontend/app.js:${i + 1} — handles type='${m[1]}'`);
            }
        }
        return out.slice(0, 60);
    }
    extractScreens(commitDir) {
        const htmlPath = path_1.default.join(commitDir, "frontend", "index.html");
        if (!fs_1.default.existsSync(htmlPath))
            return [];
        const lines = this.safeRead(htmlPath).split("\n");
        const out = [];
        for (let i = 0; i < lines.length; i++) {
            const m = lines[i].match(/<(div|section|main|nav|header|footer)\s[^>]*id="([^"]+)"/);
            if (m) {
                const cls = lines[i].match(/class="([^"]+)"/);
                const tag = m[1];
                const id = m[2];
                out.push(`frontend/index.html:${i + 1} — <${tag} id="${id}"${cls ? ` class="${cls[1]}"` : ""}>`);
            }
        }
        return out.slice(0, 50);
    }
    extractCssVariables(commitDir) {
        const cssPath = path_1.default.join(commitDir, "frontend", "styles.css");
        if (!fs_1.default.existsSync(cssPath))
            return [];
        const text = this.safeRead(cssPath);
        const lines = text.split("\n");
        const rootStart = lines.findIndex(l => l.trim().match(/^:root\s*\{/));
        if (rootStart < 0)
            return [];
        const out = [];
        for (let i = rootStart + 1; i < lines.length; i++) {
            const l = lines[i].trim();
            if (l.startsWith("}"))
                break;
            const m = l.match(/^(--[\w-]+)\s*:\s*([^;]+);?/);
            if (m)
                out.push(`${m[1]}: ${m[2].trim()}`);
            if (out.length >= 40)
                break;
        }
        return out;
    }
    // Same logic as agent.service.ts#extractCodeLocations (deduped here so
    // the builder is self-contained). Returns markdown bullets, capped to a
    // sensible length so the passport stays readable.
    extractCodeLocations(commitDir) {
        const out = [];
        const scanFile = (rel) => {
            const p = path_1.default.join(commitDir, rel);
            if (!fs_1.default.existsSync(p))
                return;
            const lines = this.safeRead(p).split("\n");
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                const route = line.match(/router\.(get|post|put|delete|patch)\s*\(\s*['"`]([^'"`]+)['"`]/);
                if (route) {
                    out.push(`- ${rel}:${i + 1} — ${route[1].toUpperCase()} ${route[2]}`);
                    continue;
                }
                const fn = line.match(/^(?:  )?(?:async\s+)?function\s+(\w+)\s*\(/);
                if (fn) {
                    out.push(`- ${rel}:${i + 1} — ${fn[1]}()`);
                    continue;
                }
                const cfn = line.match(/^(?:  )?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(?:\(|function)/);
                if (cfn) {
                    out.push(`- ${rel}:${i + 1} — ${cfn[1]}()`);
                    continue;
                }
                if (line.match(/module\.exports\.ws\s*=/)) {
                    out.push(`- ${rel}:${i + 1} — module.exports.ws (WebSocket handler)`);
                    continue;
                }
                if (line.match(/module\.exports\s*[.=]/)) {
                    out.push(`- ${rel}:${i + 1} — module.exports`);
                    continue;
                }
                const cst = line.match(/^(?:  )?const\s+([A-Z_]{2,})\s*=/);
                if (cst)
                    out.push(`- ${rel}:${i + 1} — ${cst[1]} (constant)`);
            }
        };
        scanFile("backend/routes.js");
        scanFile("frontend/app.js");
        const backendDir = path_1.default.join(commitDir, "backend");
        if (fs_1.default.existsSync(backendDir)) {
            for (const f of fs_1.default.readdirSync(backendDir)) {
                if (f !== "routes.js" && f.endsWith(".js"))
                    scanFile(`backend/${f}`);
            }
        }
        if (out.length === 0)
            return "";
        if (out.length > 150) {
            const head = out.slice(0, 150);
            head.push(`- _(... ${out.length - 150} more locations omitted)_`);
            return head.join("\n");
        }
        return out.join("\n");
    }
    // ──────────────────────────────────────────────────────────────────────
    // FILE INFO
    // ──────────────────────────────────────────────────────────────────────
    buildFileTree(commitDir) {
        const SKIP_DIRS = new Set(["node_modules", "data", ".git"]);
        const lines = [];
        const walk = (dir, prefix, depth) => {
            if (depth > 3)
                return;
            let entries;
            try {
                entries = fs_1.default.readdirSync(dir, { withFileTypes: true });
            }
            catch {
                return;
            }
            entries.sort((a, b) => {
                if (a.isDirectory() !== b.isDirectory())
                    return a.isDirectory() ? -1 : 1;
                return a.name.localeCompare(b.name);
            });
            for (const e of entries) {
                if (e.name.startsWith("."))
                    continue;
                if (SKIP_DIRS.has(e.name))
                    continue;
                const rel = prefix ? `${prefix}/${e.name}` : e.name;
                if (e.isDirectory()) {
                    lines.push(`${rel}/`);
                    walk(path_1.default.join(dir, e.name), rel, depth + 1);
                }
                else {
                    let size = "";
                    try {
                        const stat = fs_1.default.statSync(path_1.default.join(dir, e.name));
                        size = ` (${this.fmtBytes(stat.size)})`;
                    }
                    catch { }
                    lines.push(`${rel}${size}`);
                }
            }
        };
        walk(commitDir, "", 0);
        return lines.join("\n");
    }
    readNpmPackages(commitDir) {
        const pkgPath = path_1.default.join(commitDir, "package.json");
        if (!fs_1.default.existsSync(pkgPath))
            return "";
        try {
            const pkg = JSON.parse(this.safeRead(pkgPath));
            const deps = Object.keys(pkg.dependencies || {});
            return deps.length > 0 ? deps.join(", ") : "";
        }
        catch {
            return "";
        }
    }
    readDbKeys(commitDir) {
        try {
            // commitDir is .../<projectId>/commits/<n>; the live sqlite DB lives at
            // .../<projectId>/development/data/app.db
            const projectRoot = path_1.default.resolve(commitDir, "..", "..");
            const dbPath = path_1.default.join(projectRoot, "development", "data", "app.db");
            if (!fs_1.default.existsSync(dbPath))
                return "";
            // Lazy require so module load works even when better-sqlite3 isn't
            // available in some environments (tests, CI).
            const Database = require("better-sqlite3");
            const sqlite = new Database(dbPath, { readonly: true });
            const keys = sqlite.prepare("SELECT key FROM kv").all().map((r) => r.key);
            sqlite.close();
            return keys.length > 0 ? keys.join(", ") : "";
        }
        catch {
            return "";
        }
    }
    // ──────────────────────────────────────────────────────────────────────
    // DECISIONS + HISTORY
    // ──────────────────────────────────────────────────────────────────────
    // Pull existing "Key Decisions" entries from the previous passport (if any)
    // and append the new ones from this commit. Each entry is prefixed with the
    // commit number so a later reader can correlate decisions with code changes.
    mergeDecisions(prevPassport, commitNum, newDecisions) {
        const previous = this.extractDecisionsFromPrev(prevPassport);
        const fresh = (newDecisions || [])
            .map(s => (s || "").toString().trim())
            .filter(Boolean)
            .map(d => `- #${commitNum}: ${d}`);
        return [...previous, ...fresh];
    }
    extractDecisionsFromPrev(prevPassport) {
        if (!prevPassport)
            return [];
        const lines = prevPassport.split("\n");
        const startIdx = lines.findIndex(l => l.trim().match(/^##\s+Key Decisions\b/i));
        if (startIdx < 0)
            return [];
        const out = [];
        for (let i = startIdx + 1; i < lines.length; i++) {
            const l = lines[i];
            if (l.trim().match(/^##\s+/))
                break;
            const trimmed = l.trim();
            if (!trimmed)
                continue;
            if (trimmed.startsWith("_("))
                continue;
            if (trimmed.startsWith("- "))
                out.push(l.trimEnd());
        }
        return out;
    }
    buildHistory(prevPassport, commitNum, doneSummary, keyDecisions) {
        const prevHistory = this.extractHistoryFromPrev(prevPassport).trim();
        const headline = (doneSummary || "Update").split("\n")[0].substring(0, 200).trim() || "Update";
        let line = `- #${commitNum}: ${headline}`;
        if (keyDecisions && keyDecisions.length > 0) {
            const dec = keyDecisions.map(d => (d || "").toString().trim()).filter(Boolean);
            if (dec.length > 0) {
                line += ` — Decisions: ${dec.join(" | ").substring(0, 400)}`;
            }
        }
        return (prevHistory ? prevHistory + "\n" + line : line).trim();
    }
    extractHistoryFromPrev(prevPassport) {
        if (!prevPassport)
            return "";
        const lines = prevPassport.split("\n");
        const startIdx = lines.findIndex(l => l.trim().match(/^##\s+(?:Update History|Recent Updates)\b/i));
        if (startIdx < 0)
            return "";
        const out = [];
        for (let i = startIdx + 1; i < lines.length; i++) {
            const l = lines[i];
            if (l.trim().match(/^##\s+/))
                break;
            out.push(l);
        }
        return out.join("\n").trim();
    }
    // ──────────────────────────────────────────────────────────────────────
    // HELPERS
    // ──────────────────────────────────────────────────────────────────────
    safeRead(p) {
        try {
            return fs_1.default.readFileSync(p, "utf-8");
        }
        catch {
            return "";
        }
    }
    guessAppName(commitDir) {
        const pkgPath = path_1.default.join(commitDir, "package.json");
        if (!fs_1.default.existsSync(pkgPath))
            return "";
        try {
            const pkg = JSON.parse(this.safeRead(pkgPath));
            return (pkg.name || "").toString();
        }
        catch {
            return "";
        }
    }
    fmtBytes(n) {
        if (n < 1024)
            return `${n}B`;
        if (n < 1024 * 1024)
            return `${(n / 1024).toFixed(1)}KB`;
        return `${(n / 1024 / 1024).toFixed(1)}MB`;
    }
}
exports.PassportBuilder = PassportBuilder;
exports.passportBuilder = new PassportBuilder();
//# sourceMappingURL=passport-builder.js.map