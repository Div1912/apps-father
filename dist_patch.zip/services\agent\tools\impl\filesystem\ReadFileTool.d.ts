import type OpenAI from "openai";
import type { AgentTool } from "../../../AgentTool";
import type { RunContext } from "../../../RunContext";
export declare class ReadFileTool implements AgentTool {
    renderDefinition(): OpenAI.Chat.Completions.ChatCompletionTool;
    execute(args: Record<string, any>, ctx: RunContext): Promise<string>;
    private _safePath;
}
//# sourceMappingURL=ReadFileTool.d.ts.map