import type { RouterTool } from "./RouterTool";
import type { RouterContext } from "./RouterContext";
/**
 * Lets the router ask the user one clarification question and wait for the
 * answer. Can be called any number of times until the model has enough info
 * to call propose_action.
 *
 * The answer is returned as the tool result string, so the model sees the
 * user's reply on its next turn and can decide whether to ask more, switch
 * intent, or finalize a proposal.
 */
export declare class QuestionnaireTool implements RouterTool {
    name: string;
    definition: {
        type: string;
        function: {
            name: string;
            description: string;
            parameters: {
                type: string;
                properties: {
                    question: {
                        type: string;
                        description: string;
                    };
                    options: {
                        type: string;
                        items: {
                            type: string;
                        };
                        description: string;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
        };
    };
    execute(args: Record<string, any>, ctx: RouterContext): Promise<string>;
}
//# sourceMappingURL=QuestionnaireTool.d.ts.map