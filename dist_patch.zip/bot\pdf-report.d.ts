export declare function generateReportPdf(title: string, summary: string, cost?: string): Promise<Buffer>;
//# sourceMappingURL=pdf-report.d.ts.map