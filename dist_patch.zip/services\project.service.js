"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.projectService = exports.ProjectService = void 0;
const db_1 = require("../db");
const crypto_service_1 = require("./crypto.service");
const notify_service_1 = require("./notify.service");
const config_1 = require("../config");
class ProjectService {
    async getOrCreateUser(telegramId, username, firstName, referredBy, utmSource) {
        // Atomic create-or-fetch using the unique constraint on telegramId.
        // This is critical: the Mini App fires several API calls in parallel on
        // load (/api/init, /api/projects, /api/balance, ...). The previous
        // findUnique-then-upsert pattern had a race where multiple parallel
        // calls all saw "not exists", all reported isNew=true, all sent the
        // admin notification, and the random winner of the create decided
        // whether utm_source/referred_by were persisted (only /api/init passes
        // those, so the source data was being lost ~75% of the time).
        const WELCOME_CREDITS = 50;
        const createData = { telegramId: BigInt(telegramId), username, firstName, balance: 0, credits: WELCOME_CREDITS };
        if (referredBy && referredBy !== telegramId) {
            createData.referredBy = BigInt(referredBy);
        }
        if (utmSource) {
            createData.utmSource = utmSource;
        }
        let user;
        let isNew = false;
        // True iff this call is the one that first persisted utmSource and/or
        // referredBy for this user (either by creating the row, or by
        // back-filling NULL columns on an existing row that lost the race).
        let attributedNow = false;
        try {
            user = await db_1.prisma.user.create({ data: createData });
            isNew = true;
            attributedNow = Boolean(createData.utmSource || createData.referredBy);
        }
        catch (err) {
            if (err?.code === "P2002") {
                // Lost the race — another call already created the row.
                // CRITICAL: back-fill utmSource / referredBy if they're still NULL.
                // Otherwise, when /api/projects (or any other endpoint) wins the
                // race-to-create, /api/init's legitimate attribution data is
                // silently discarded. We only fill, never overwrite — once a user
                // has been attributed, the original source is sticky.
                const existing = await db_1.prisma.user.findUnique({
                    where: { telegramId: BigInt(telegramId) },
                    select: { utmSource: true, referredBy: true },
                });
                const updateData = { username, firstName };
                if (utmSource && !existing?.utmSource) {
                    updateData.utmSource = utmSource;
                    attributedNow = true;
                }
                if (referredBy &&
                    referredBy !== telegramId &&
                    (existing?.referredBy === null || existing?.referredBy === undefined)) {
                    updateData.referredBy = BigInt(referredBy);
                    attributedNow = true;
                }
                user = await db_1.prisma.user.update({
                    where: { telegramId: BigInt(telegramId) },
                    data: updateData,
                });
            }
            else {
                throw err;
            }
        }
        if (isNew) {
            // Diagnostic: emit a WARN line whenever a user row is created
            // WITHOUT any attribution. This is the actionable signal that some
            // call-site is reaching getOrCreateUser without source/referrer
            // (frontend not deployed yet, missing helper somewhere, bot-side
            // /start without payload, etc.). Grep prod logs for this line —
            // every hit is a user that will land in #organic stats.
            if (!utmSource && !referredBy) {
                console.warn(`[getOrCreateUser] WARN tg=${telegramId} created with NO attribution — will count as #organic until back-fill arrives`);
            }
            else {
                console.log(`[getOrCreateUser] tg=${telegramId} created src=${JSON.stringify(utmSource ?? null)} ref=${referredBy ?? null}`);
            }
            (0, notify_service_1.notifyNewUser)(telegramId, username, firstName, referredBy !== telegramId ? referredBy : undefined, utmSource ?? null);
        }
        else if (attributedNow) {
            // Back-fill case: user existed without attribution, this call
            // landed source/referrer on the row. Both the row itself (for
            // #sources stats) and the admin notification are now correct.
            console.log(`[getOrCreateUser] tg=${telegramId} BACKFILLED src=${JSON.stringify(utmSource ?? null)} ref=${referredBy ?? null}`);
            (0, notify_service_1.notifyNewUser)(telegramId, username, firstName, referredBy !== telegramId ? referredBy : undefined, utmSource ?? null);
        }
        return { user, isNew, attributedNow };
    }
    async createProject(userId, name) {
        return db_1.prisma.project.create({
            data: { userId, name, status: "created" },
        });
    }
    async setProjectBot(projectId, botUserId, botUsername, botToken) {
        return db_1.prisma.project.update({
            where: { id: projectId },
            data: {
                botUserId: BigInt(botUserId),
                botUsername,
                botTokenEncrypted: (0, crypto_service_1.encryptToken)(botToken),
                status: "planning",
            },
        });
    }
    async unlinkBot(projectId) {
        return db_1.prisma.project.update({
            where: { id: projectId },
            data: {
                botTokenEncrypted: null,
                botUsername: null,
                botUserId: null,
            },
        });
    }
    async updateProjectStatus(projectId, status) {
        return db_1.prisma.project.update({
            where: { id: projectId },
            data: { status },
        });
    }
    async updateProjectPlan(projectId, plan) {
        return db_1.prisma.project.update({
            where: { id: projectId },
            data: { plan, status: "planning" },
        });
    }
    async updateProjectDescription(projectId, description) {
        return db_1.prisma.project.update({
            where: { id: projectId },
            data: { description },
        });
    }
    async updateProjectName(projectId, name) {
        return db_1.prisma.project.update({
            where: { id: projectId },
            data: { name },
        });
    }
    async updateProjectAppConfig(projectId, input) {
        const data = {};
        if (input.name !== undefined)
            data.name = input.name;
        if (input.description !== undefined)
            data.appDescription = input.description;
        if (input.longDescription !== undefined)
            data.appLongDescription = input.longDescription;
        if (input.menuButtonText !== undefined)
            data.appMenuButtonText = input.menuButtonText;
        return db_1.prisma.project.update({
            where: { id: projectId },
            data,
        });
    }
    async configureProjectBotFromAppConfig(projectId, botToken) {
        const project = await this.getProject(projectId);
        if (!project)
            return { configured: false, lines: ["project not found"] };
        const token = botToken || (project.botTokenEncrypted ? (0, crypto_service_1.decryptToken)(project.botTokenEncrypted) : "");
        if (!token)
            return { configured: false, lines: ["bot token not available; saved app config for later bot linking"] };
        // IMPORTANT: never fall back to project.description here — that's the raw
        // user prompt ("an app for booking dentists with reminders…") and pushing
        // it as the public bot description leaks the user's idea brief into
        // Telegram's profile previews. Only use values the agent has explicitly
        // saved via configure_app; otherwise leave the bot description alone.
        const rawAppDescription = project.appDescription;
        const rawAppLongDescription = project.appLongDescription;
        const appDescription = rawAppDescription ? String(rawAppDescription).substring(0, 120) : null;
        const appLongDescription = rawAppLongDescription ? String(rawAppLongDescription).substring(0, 512) : null;
        const rawMenuButtonText = (project.appMenuButtonText ?? "Launch App").toString().substring(0, 32);
        const appUrl = `${config_1.config.baseUrl}/app/${projectId}/`;
        const base = `https://api.telegram.org/bot${token}`;
        const callApi = async (method, params) => {
            const resp = await fetch(`${base}/${method}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(params),
            });
            return { method, status: resp.status, body: await resp.text() };
        };
        const menuButtonPayload = rawMenuButtonText === ""
            ? { menu_button: { type: "default" } }
            : { menu_button: { type: "web_app", text: rawMenuButtonText, web_app: { url: appUrl } } };
        const calls = [
            callApi("setChatMenuButton", menuButtonPayload),
        ];
        if (appLongDescription) {
            calls.push(callApi("setMyDescription", { description: appLongDescription }));
        }
        if (appDescription) {
            calls.push(callApi("setMyShortDescription", { short_description: appDescription }));
        }
        if (project.name) {
            calls.push(callApi("setMyName", { name: project.name.toString().substring(0, 64) }));
        }
        const results = await Promise.all(calls);
        const lines = results.map(r => `${r.method}: ${r.status} ${r.body.substring(0, 200)}`);
        return { configured: true, lines };
    }
    async getProject(projectId) {
        return db_1.prisma.project.findUnique({ where: { id: projectId } });
    }
    async getProjectsByUser(userId) {
        return db_1.prisma.project.findMany({
            where: { userId },
            orderBy: { createdAt: "desc" },
        });
    }
    async getProjectByBotUserId(botUserId) {
        return db_1.prisma.project.findFirst({
            where: { botUserId: BigInt(botUserId) },
        });
    }
    /** Returns the user's most-recently-updated project that has no bot linked yet.
     *  Used by the managed_bot handler to link a newly-created bot to an already-built project. */
    async getUnbottedProject(userId) {
        return db_1.prisma.project.findFirst({
            where: { userId, botTokenEncrypted: null },
            orderBy: { updatedAt: "desc" },
        });
    }
    async getAllActiveProjects() {
        return db_1.prisma.project.findMany({
            where: {
                botTokenEncrypted: { not: null },
                status: { in: ["planning", "building", "deployed", "released"] },
            },
        });
    }
    async getProjectToken(projectId) {
        const project = await db_1.prisma.project.findUnique({
            where: { id: projectId },
            select: { botTokenEncrypted: true },
        });
        if (!project?.botTokenEncrypted)
            return null;
        return (0, crypto_service_1.decryptToken)(project.botTokenEncrypted);
    }
    async createVersion(projectId, version, changelog) {
        await db_1.prisma.project.update({
            where: { id: projectId },
            data: { currentVersion: version },
        });
        return db_1.prisma.version.create({
            data: { projectId, version, changelog },
        });
    }
    async saveAsset(projectId, fileId, filePath, fileName, description) {
        return db_1.prisma.asset.create({
            data: { projectId, fileId, filePath, fileName, description },
        });
    }
    async getProjectAssets(projectId) {
        return db_1.prisma.asset.findMany({
            where: { projectId },
            orderBy: { createdAt: "desc" },
        });
    }
    async storeGeneratedCode(projectId, code) {
        return db_1.prisma.project.update({
            where: { id: projectId },
            data: { generatedCode: code, status: "deployed" },
        });
    }
    async updateProjectSummary(projectId, summary) {
        return db_1.prisma.project.update({
            where: { id: projectId },
            data: { projectSummary: summary },
        });
    }
    async updateProjectLastTaskId(projectId, taskId) {
        return db_1.prisma.project.update({
            where: { id: projectId },
            data: { lastTaskId: taskId },
        });
    }
    async setTonWallet(projectId, wallet) {
        return db_1.prisma.project.update({
            where: { id: projectId },
            data: { tonWallet: wallet },
        });
    }
    async getTonWallet(projectId) {
        const project = await db_1.prisma.project.findUnique({
            where: { id: projectId },
            select: { tonWallet: true },
        });
        return project?.tonWallet ?? null;
    }
    async deleteProject(projectId) {
        await db_1.prisma.asset.deleteMany({ where: { projectId } });
        await db_1.prisma.version.deleteMany({ where: { projectId } });
        await db_1.prisma.project.delete({ where: { id: projectId } });
    }
    async getUserSlotInfo(userId) {
        const [user, count] = await Promise.all([
            db_1.prisma.user.findUnique({ where: { id: userId }, select: { appSlots: true } }),
            db_1.prisma.project.count({ where: { userId } }),
        ]);
        return { used: count, total: user?.appSlots ?? 5 };
    }
    async canCreateApp(userId) {
        const { used, total } = await this.getUserSlotInfo(userId);
        return used < total;
    }
    async getUserByUsername(username) {
        return db_1.prisma.user.findFirst({ where: { username: { equals: username, mode: "insensitive" } } });
    }
    async transferProject(projectId, newOwnerId) {
        return db_1.prisma.project.update({
            where: { id: projectId },
            data: { userId: newOwnerId },
        });
    }
    async buySlot(userId) {
        const { runtimeConfig } = await Promise.resolve().then(() => __importStar(require("./runtime-config.service")));
        const SLOT_PRICE_CREDITS = runtimeConfig.get().slotPriceCredits || 250;
        const user = await db_1.prisma.user.findUnique({ where: { id: userId }, select: { credits: true, appSlots: true } });
        if (!user || (user.credits ?? 0) < SLOT_PRICE_CREDITS)
            throw new Error("Insufficient credits");
        const updated = await db_1.prisma.user.update({
            where: { id: userId },
            data: {
                credits: { decrement: SLOT_PRICE_CREDITS },
                appSlots: { increment: 1 },
            },
        });
        return { newSlots: updated.appSlots, newBalance: updated.credits, newCredits: updated.credits };
    }
}
exports.ProjectService = ProjectService;
exports.projectService = new ProjectService();
//# sourceMappingURL=project.service.js.map