export declare function getWalletAddress(): Promise<string>;
export declare function getWalletBalance(): Promise<number>;
export declare function getUsdtBalance(): Promise<number>;
/**
 * Send USDT (jetton on TON) from hot wallet to a recipient.
 * @param toAddress  Recipient TON address
 * @param amountUsdt Amount in USDT (e.g. 50.00)
 * @returns Transaction hash or fallback identifier
 */
export declare function sendUsdt(toAddress: string, amountUsdt: number): Promise<string>;
//# sourceMappingURL=wallet.service.d.ts.map