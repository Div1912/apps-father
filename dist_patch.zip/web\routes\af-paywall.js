/* Apps Father — Player paywall overlay.
 *
 * Injected into every /dev/{projectId}/ preview page right after the splash
 * (see dev.routes.ts). For users who never deposited and haven't already
 * paid the one-time 20-credit unlock for this project, we cover the running
 * app with a frosted overlay and ask them to spend 20 credits to unlock.
 *
 * On insufficient funds we close the player and deep-link to the main bot's
 * Topup view (start_param = "topup") so the user can credit up and try again.
 *
 * Project ID is interpolated by the server (`__AFPID__` placeholder).
 *
 * The script is intentionally vanilla JS (no bundler, no transpiler) — it
 * runs INSIDE the user's generated app, which is sandboxed and uses its
 * own toolchain. Keep it dependency-free.
 */
(function () {
  if (window.__af_paywall_loaded) return;
  window.__af_paywall_loaded = true;

  var PROJECT_ID = '__AFPID__';
  var API_BASE = '/telegram-mini-app/api/preview/' + PROJECT_ID;
  var FALLBACK_FEE = 20;

  function tg() { try { return window.Telegram && window.Telegram.WebApp; } catch (_) { return null; } }
  function initData() { var w = tg(); return (w && w.initData) || ''; }

  function isDev() {
    try { return location.hostname === 'dev.apps-father.com'; } catch (_) { return false; }
  }
  function topupDeeplink() {
    var bot = isDev() ? 'apps_father_dev_bot' : 'apps_father_bot';
    return 'https://t.me/' + bot + '/app?startapp=topup';
  }

  // Build overlay synchronously so the underlying app never flashes through
  // for free users while the state request is in flight. We attach as soon
  // as <body> exists.
  function ensureBody(cb) {
    if (document.body) return cb();
    var iv = setInterval(function () {
      if (document.body) { clearInterval(iv); cb(); }
    }, 16);
  }

  function buildOverlay() {
    var ov = document.createElement('div');
    ov.id = '_af_paywall';
    ov.setAttribute('style', [
      'position:fixed', 'inset:0', 'z-index:2147483646',
      'display:flex', 'align-items:center', 'justify-content:center',
      'padding:16px',
      'background:rgba(10,10,15,0.55)',
      'backdrop-filter:blur(24px) saturate(140%)',
      '-webkit-backdrop-filter:blur(24px) saturate(140%)',
      'opacity:1', 'transition:opacity .25s ease',
      'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif',
      'color:#fff',
    ].join(';'));
    ov.innerHTML = ''
      + '<div id="_af_paywall_card" style="'
      +   'width:100%;max-width:340px;border-radius:24px;'
      +   'background:linear-gradient(135deg,rgba(36,28,68,0.92),rgba(20,18,40,0.92));'
      +   'border:1px solid rgba(255,255,255,0.08);'
      +   'box-shadow:0 24px 64px rgba(0,0,0,0.6);'
      +   'padding:24px;text-align:center;backdrop-filter:blur(18px)">'
      +   '<div style="width:64px;height:64px;margin:0 auto 14px;border-radius:50%;'
      +       'background:linear-gradient(135deg,#6366f1,#8b5cf6);display:flex;align-items:center;'
      +       'justify-content:center;box-shadow:0 8px 24px rgba(139,92,246,0.45)">'
      +     '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
      +       '<rect x="3" y="11" width="18" height="11" rx="2"/>'
      +       '<path d="M7 11V7a5 5 0 0 1 10 0v4"/>'
      +     '</svg>'
      +   '</div>'
      +   '<div id="_af_paywall_title" style="font-size:20px;font-weight:700;margin-bottom:6px">Preview locked</div>'
      +   '<div id="_af_paywall_sub" style="font-size:14px;color:rgba(255,255,255,0.7);margin-bottom:14px">'
      +     'Loading…'
      +   '</div>'
      +   '<div id="_af_paywall_balance" style="font-size:13px;color:rgba(255,255,255,0.55);margin-bottom:20px"></div>'
      +   '<button id="_af_paywall_btn" type="button" disabled style="'
      +     'width:100%;border:none;cursor:pointer;'
      +     'padding:13px 18px;border-radius:14px;'
      +     'background:linear-gradient(135deg,#6366f1,#8b5cf6);'
      +     'color:#fff;font-size:15px;font-weight:600;letter-spacing:0.01em;'
      +     'transition:transform .15s ease,opacity .15s ease;opacity:0.6">'
      +     'Loading…'
      +   '</button>'
      +   '<div id="_af_paywall_hint" style="margin-top:12px;font-size:11px;color:rgba(255,255,255,0.4)"></div>'
      + '</div>';
    return ov;
  }

  function fadeOutAndRemove(ov) {
    if (!ov) return;
    ov.style.opacity = '0';
    setTimeout(function () { if (ov.parentNode) ov.parentNode.removeChild(ov); }, 280);
  }

  function showError(ov, text) {
    var sub = ov.querySelector('#_af_paywall_sub');
    if (sub) { sub.textContent = text; sub.style.color = '#ef4444'; }
  }

  function setBtn(ov, label, enabled) {
    var btn = ov.querySelector('#_af_paywall_btn');
    if (!btn) return;
    btn.textContent = label;
    btn.disabled = !enabled;
    btn.style.opacity = enabled ? '1' : '0.6';
    btn.style.cursor = enabled ? 'pointer' : 'default';
  }

  function fetchJson(url, opts) {
    var headers = { 'Accept': 'application/json' };
    var d = initData();
    if (d) headers['X-Telegram-Init-Data'] = d;
    if (opts && opts.body) headers['Content-Type'] = 'application/json';
    return fetch(url, {
      method: (opts && opts.method) || 'GET',
      headers: headers,
      body: opts && opts.body ? JSON.stringify(opts.body) : undefined,
    }).then(function (r) {
      return r.json().then(function (j) { return { status: r.status, ok: r.ok, data: j }; }).catch(function () {
        return { status: r.status, ok: r.ok, data: {} };
      });
    });
  }

  function openTopupAndClose() {
    var w = tg();
    var url = topupDeeplink();
    try { if (w && w.openTelegramLink) w.openTelegramLink(url); } catch (_) {}
    setTimeout(function () {
      try { if (w && w.close) w.close(); } catch (_) {}
    }, 100);
  }

  function applyTexts(ov, fee, balance) {
    var sub = ov.querySelector('#_af_paywall_sub');
    var bal = ov.querySelector('#_af_paywall_balance');
    var hint = ov.querySelector('#_af_paywall_hint');
    if (sub) sub.textContent = 'Unlock this preview for ' + fee + ' credits.';
    if (bal) bal.textContent = 'Your balance: ' + balance + ' cr';
    if (hint) hint.textContent = balance < fee ? 'Not enough credits — top up first.' : '';
    setBtn(ov, 'Unlock for ' + fee + ' cr', true);
  }

  function startUnlockFlow(ov, fee) {
    var btn = ov.querySelector('#_af_paywall_btn');
    if (!btn) return;
    btn.addEventListener('click', function () {
      if (btn.disabled) return;
      btn.disabled = true;
      btn.textContent = 'Unlocking…';
      btn.style.opacity = '0.6';
      fetchJson(API_BASE + '/unlock', { method: 'POST' }).then(function (resp) {
        if (resp.ok && resp.data && resp.data.ok) {
          fadeOutAndRemove(ov);
          return;
        }
        if (resp.status === 402) {
          // Insufficient funds: hand off to main bot's topup view.
          showError(ov, 'Not enough credits — opening Top Up…');
          setTimeout(openTopupAndClose, 600);
          return;
        }
        showError(ov, (resp.data && resp.data.error) || 'Could not unlock');
        btn.disabled = false;
        btn.style.opacity = '1';
        btn.textContent = 'Try again';
      }).catch(function () {
        showError(ov, 'Network error — please try again.');
        btn.disabled = false;
        btn.style.opacity = '1';
        btn.textContent = 'Retry';
      });
    });
  }

  ensureBody(function () {
    var ov = buildOverlay();
    document.body.appendChild(ov);

    fetchJson(API_BASE + '/state').then(function (resp) {
      if (!resp.ok || !resp.data) {
        // Fail open in case of network/auth glitch — don't block the app
        // for paying users when the API briefly hiccups.
        fadeOutAndRemove(ov);
        return;
      }
      if (!resp.data.requiresPayment) {
        fadeOutAndRemove(ov);
        return;
      }
      var fee = Number(resp.data.fee || FALLBACK_FEE);
      var balance = Number(resp.data.balance || 0);
      applyTexts(ov, fee, balance);
      startUnlockFlow(ov, fee);
    }).catch(function () {
      // Same fail-open behavior on a thrown error.
      fadeOutAndRemove(ov);
    });
  });
})();
