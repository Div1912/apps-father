export declare function publishReport(title: string, summary: string): Promise<string>;
//# sourceMappingURL=telegraph.service.d.ts.map