"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.evictDevApiCache = evictDevApiCache;
const express_1 = require("express");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const crypto_1 = __importDefault(require("crypto"));
const dotenv_1 = __importDefault(require("dotenv"));
const better_sqlite3_1 = __importDefault(require("better-sqlite3"));
const initdata_1 = require("../middleware/initdata");
const project_service_1 = require("../../services/project.service");
const crypto_service_1 = require("../../services/crypto.service");
const console_tagger_service_1 = require("../../services/console-tagger.service");
const config_1 = require("../../config");
const router = (0, express_1.Router)();
const PROJECTS_DIR = path_1.default.join(process.cwd(), "projects");
const projectCache = new Map();
function createProjectDb(projectDir, botToken, botUsername, projectId) {
    const dataDir = path_1.default.join(projectDir, "data");
    fs_1.default.mkdirSync(dataDir, { recursive: true });
    const sqlite = new better_sqlite3_1.default(path_1.default.join(dataDir, "app.db"));
    sqlite.pragma("journal_mode = WAL");
    sqlite.exec("CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT)");
    return {
        get(key) {
            const row = sqlite.prepare("SELECT value FROM kv WHERE key = ?").get(key);
            return row ? JSON.parse(row.value) : null;
        },
        set(key, value) {
            sqlite.prepare("INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)").run(key, JSON.stringify(value));
        },
        getAll() {
            const rows = sqlite.prepare("SELECT key, value FROM kv").all();
            const result = {};
            for (const row of rows)
                result[row.key] = JSON.parse(row.value);
            return result;
        },
        delete(key) {
            sqlite.prepare("DELETE FROM kv WHERE key = ?").run(key);
        },
        keys() {
            return sqlite.prepare("SELECT key FROM kv").all().map(r => r.key);
        },
        close() {
            sqlite.close();
        },
        botToken,
        botUsername,
        projectId,
    };
}
function evictProject(projectId) {
    const entry = projectCache.get(projectId);
    if (entry) {
        try {
            entry.db.close();
        }
        catch { }
        projectCache.delete(projectId);
    }
    // Always purge require.cache for this project's backend so the next
    // require() call reads the freshly-deployed files from disk rather than
    // returning the stale module.  This must run even when there is no
    // projectCache entry (e.g. evictDevApiCache was called right after a deploy
    // before any request hit the cache).
    const backendDir = path_1.default.join(PROJECTS_DIR, projectId, "development", "backend");
    for (const key of Object.keys(require.cache)) {
        if (key.startsWith(backendDir) && !key.includes("node_modules")) {
            delete require.cache[key];
        }
    }
}
async function loadProjectEntry(projectId, projectDir, backendDir, routesFile) {
    const mtime = fs_1.default.statSync(routesFile).mtimeMs;
    const existing = projectCache.get(projectId);
    if (existing && existing.mtime === mtime) {
        return existing;
    }
    // File changed (new deploy) or first load — evict stale entry.
    // evictProject also purges require.cache for this project's backendDir.
    if (existing) {
        evictProject(projectId);
    }
    const routeFactory = require(routesFile);
    const project = await project_service_1.projectService.getProject(projectId);
    let botToken = "";
    let botUsername = "";
    if (project?.botTokenEncrypted)
        botToken = (0, crypto_service_1.decryptToken)(project.botTokenEncrypted);
    if (project?.botUsername)
        botUsername = project.botUsername;
    const devDir = path_1.default.join(projectDir, "development");
    const db = createProjectDb(devDir, botToken, botUsername, projectId);
    const envPath = path_1.default.join(backendDir, ".env");
    const envVars = fs_1.default.existsSync(envPath) ? dotenv_1.default.parse(fs_1.default.readFileSync(envPath)) : {};
    // Inject platform vars so routes.js can use the AF Bucket API
    envVars.AF_INTERNAL_SECRET = process.env.AF_INTERNAL_SECRET || "";
    envVars.BASE_URL = config_1.config.baseUrl;
    envVars.PROJECT_ID = projectId;
    // INTERNAL_BASE_URL bypasses nginx/Cloudflare — use this for server-side bucket calls
    envVars.INTERNAL_BASE_URL = `http://localhost:${config_1.config.port}`;
    const entry = { mtime, routeFactory, db, envVars };
    projectCache.set(projectId, entry);
    return entry;
}
// ── Request handler ───────────────────────────────────────────────────────────
router.use("/:projectId/{*routePath}", initdata_1.verifyInitData);
router.all("/:projectId/{*routePath}", async (req, res) => {
    const projectId = String(req.params.projectId);
    const rawRoute = req.params.routePath;
    const routePath = Array.isArray(rawRoute) ? rawRoute.join("/") : String(rawRoute || "");
    const projectDir = path_1.default.join(PROJECTS_DIR, projectId);
    const backendDir = path_1.default.join(projectDir, "development", "backend");
    const routesFile = path_1.default.join(backendDir, "routes.js");
    if (!fs_1.default.existsSync(routesFile)) {
        res.status(404).json({ error: "No backend routes configured for this project" });
        return;
    }
    await (0, console_tagger_service_1.runWithProject)(projectId, async () => {
        try {
            const entry = await loadProjectEntry(projectId, projectDir, backendDir, routesFile);
            // Expose deploy timestamp so the agent / devtools can confirm which
            // version is running (mtime = milliseconds since epoch of the deployed file).
            res.setHeader("X-App-Deploy-Time", entry.mtime.toString());
            const projectRouter = (0, express_1.Router)();
            // Re-sign visual-test initData so routes.js auth checks pass
            const vtHeader = req.headers["x-telegram-init-data"] || "";
            if (vtHeader.includes("hash=visualtest_fake_hash_dev_only") && entry.db.botToken) {
                req.headers["x-telegram-init-data"] = resignVisualTestInitData(vtHeader, entry.db.botToken);
            }
            if (typeof entry.routeFactory === "function") {
                try {
                    entry.routeFactory(projectRouter, entry.db, projectId, entry.envVars);
                }
                catch (regErr) {
                    console.error(`[DevAPI] Route registration error for ${projectId}:`, regErr);
                }
            }
            // Preserve the original query string — req.params strips it, but
            // Express re-parses req.query from req.url when the sub-router runs,
            // so we must keep the "?" portion or req.query will be empty.
            const qsIdx = req.originalUrl.indexOf("?");
            const qs = qsIdx !== -1 ? req.originalUrl.slice(qsIdx) : "";
            req.url = "/" + routePath + qs;
            projectRouter(req, res, () => {
                res.status(404).json({ error: "Endpoint not found" });
            });
        }
        catch (err) {
            console.error(`[DevAPI] Error loading routes for ${projectId}:`, err);
            // Evict on error so the next request gets a clean retry.
            evictProject(projectId);
            res.status(500).json({ error: "Internal server error" });
        }
    });
});
// ── Visual-test initData re-signer ────────────────────────────────────────────
// When the visual test sends hash=visualtest_fake_hash_dev_only we re-sign the
// initData with the project's real bot token so routes.js auth checks pass.
function resignVisualTestInitData(initData, botToken) {
    const params = new URLSearchParams(initData);
    params.delete("hash");
    const entries = Array.from(params.entries());
    entries.sort(([a], [b]) => a.localeCompare(b));
    const dataCheckString = entries.map(([k, v]) => `${k}=${v}`).join("\n");
    const secretKey = crypto_1.default.createHmac("sha256", "WebAppData").update(botToken).digest();
    const hash = crypto_1.default.createHmac("sha256", secretKey).update(dataCheckString).digest("hex");
    params.set("hash", hash);
    return params.toString();
}
// ── Cache eviction endpoint (called by deploy_to_dev / ws-manager) ────────────
// Exported so other parts of the server can force-evict a project's module
// cache immediately after syncing new files to development/.
function evictDevApiCache(projectId) {
    evictProject(projectId);
}
exports.default = router;
//# sourceMappingURL=devapi.routes.js.map