"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.commitService = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const db_1 = require("../db");
const PROJECTS_DIR = path_1.default.join(process.cwd(), "projects");
function copyDirSync(src, dest) {
    if (!fs_1.default.existsSync(src))
        return;
    fs_1.default.mkdirSync(dest, { recursive: true });
    for (const entry of fs_1.default.readdirSync(src, { withFileTypes: true })) {
        const srcPath = path_1.default.join(src, entry.name);
        const destPath = path_1.default.join(dest, entry.name);
        if (entry.isDirectory()) {
            copyDirSync(srcPath, destPath);
        }
        else {
            fs_1.default.copyFileSync(srcPath, destPath);
        }
    }
}
function rmDirSync(dir) {
    if (fs_1.default.existsSync(dir)) {
        fs_1.default.rmSync(dir, { recursive: true, force: true });
    }
}
function bustCache(dir) {
    const indexPath = path_1.default.join(dir, "frontend", "index.html");
    if (!fs_1.default.existsSync(indexPath))
        return;
    try {
        const v = Date.now();
        let html = fs_1.default.readFileSync(indexPath, "utf-8");
        html = html.replace(/(href|src)="([^"]+\.(css|js))(\?[^"]*)?"/g, (_, attr, file) => `${attr}="${file}?v=${v}"`);
        fs_1.default.writeFileSync(indexPath, html, "utf-8");
    }
    catch { }
}
class CommitService {
    /**
     * Prepare a new commit folder for the agent to work in.
     * Copies latest commit (or development/) into commits/N+1/.
     */
    async prepareCommitFolder(projectId) {
        const projectDir = path_1.default.join(PROJECTS_DIR, projectId);
        const commitsDir = path_1.default.join(projectDir, "commits");
        fs_1.default.mkdirSync(commitsDir, { recursive: true });
        const existing = await db_1.prisma.version.findMany({
            where: { projectId },
            orderBy: { id: "desc" },
            take: 1,
        });
        let commitNum = 0;
        if (existing.length > 0) {
            const parsed = parseInt(existing[0].version, 10);
            commitNum = isNaN(parsed) ? 0 : parsed + 1;
        }
        const commitDir = path_1.default.join(commitsDir, String(commitNum));
        rmDirSync(commitDir);
        fs_1.default.mkdirSync(commitDir, { recursive: true });
        const prevCommitDir = commitNum > 0
            ? path_1.default.join(commitsDir, String(commitNum - 1))
            : null;
        if (prevCommitDir && fs_1.default.existsSync(prevCommitDir)) {
            copyDirSync(path_1.default.join(prevCommitDir, "frontend"), path_1.default.join(commitDir, "frontend"));
            copyDirSync(path_1.default.join(prevCommitDir, "backend"), path_1.default.join(commitDir, "backend"));
            // Carry forward context.md from previous commit
            const prevContext = path_1.default.join(prevCommitDir, "context.md");
            if (fs_1.default.existsSync(prevContext)) {
                fs_1.default.copyFileSync(prevContext, path_1.default.join(commitDir, "context.md"));
            }
        }
        else {
            const devDir = path_1.default.join(projectDir, "development");
            if (fs_1.default.existsSync(path_1.default.join(devDir, "frontend"))) {
                copyDirSync(path_1.default.join(devDir, "frontend"), path_1.default.join(commitDir, "frontend"));
            }
            if (fs_1.default.existsSync(path_1.default.join(devDir, "backend"))) {
                copyDirSync(path_1.default.join(devDir, "backend"), path_1.default.join(commitDir, "backend"));
            }
        }
        fs_1.default.mkdirSync(path_1.default.join(commitDir, "frontend"), { recursive: true });
        fs_1.default.mkdirSync(path_1.default.join(commitDir, "backend"), { recursive: true });
        // Overlay assets from development/ (handles newly uploaded files)
        const devAssets = path_1.default.join(projectDir, "development", "frontend", "assets");
        if (fs_1.default.existsSync(devAssets)) {
            copyDirSync(devAssets, path_1.default.join(commitDir, "frontend", "assets"));
        }
        console.log(`[Commit] Prepared commit #${commitNum} for project ${projectId.substring(0, 8)}`);
        return { commitDir, commitNum };
    }
    /**
     * Copy commit folder contents to development/ for live testing.
     */
    syncToDev(projectId, commitDir) {
        const projectDir = path_1.default.join(PROJECTS_DIR, projectId);
        const devDir = path_1.default.join(projectDir, "development");
        rmDirSync(path_1.default.join(devDir, "frontend"));
        rmDirSync(path_1.default.join(devDir, "backend"));
        copyDirSync(path_1.default.join(commitDir, "frontend"), path_1.default.join(devDir, "frontend"));
        copyDirSync(path_1.default.join(commitDir, "backend"), path_1.default.join(devDir, "backend"));
        fs_1.default.mkdirSync(path_1.default.join(devDir, "data"), { recursive: true });
        bustCache(devDir);
        console.log(`[Commit] Synced to development/ for project ${projectId.substring(0, 8)}`);
    }
    /**
     * Finalize a commit: create DB record, copy agent log, sync to development/.
     */
    async createCommit(projectId, message, commitNum, commitDir, logPath) {
        if (logPath && fs_1.default.existsSync(logPath)) {
            try {
                fs_1.default.copyFileSync(logPath, path_1.default.join(commitDir, "agent.log"));
            }
            catch { }
        }
        this.syncToDev(projectId, commitDir);
        await db_1.prisma.version.create({
            data: {
                projectId,
                version: String(commitNum),
                changelog: message,
            },
        });
        console.log(`[Commit] Project ${projectId.substring(0, 8)} → commit #${commitNum}: ${message.substring(0, 60)}`);
        return commitNum;
    }
    /**
     * Release: copy development/ code to release/ (preserving release DB).
     */
    async releaseCurrentDev(projectId) {
        const projectDir = path_1.default.join(PROJECTS_DIR, projectId);
        const devDir = path_1.default.join(projectDir, "development");
        const releaseDir = path_1.default.join(projectDir, "release");
        rmDirSync(path_1.default.join(releaseDir, "frontend"));
        rmDirSync(path_1.default.join(releaseDir, "backend"));
        fs_1.default.mkdirSync(releaseDir, { recursive: true });
        copyDirSync(path_1.default.join(devDir, "frontend"), path_1.default.join(releaseDir, "frontend"));
        copyDirSync(path_1.default.join(devDir, "backend"), path_1.default.join(releaseDir, "backend"));
        const releaseDbDir = path_1.default.join(releaseDir, "data");
        fs_1.default.mkdirSync(releaseDbDir, { recursive: true });
        const releaseDbPath = path_1.default.join(releaseDbDir, "app.db");
        if (!fs_1.default.existsSync(releaseDbPath)) {
            const devDbPath = path_1.default.join(devDir, "data", "app.db");
            if (fs_1.default.existsSync(devDbPath)) {
                fs_1.default.copyFileSync(devDbPath, releaseDbPath);
                console.log(`[Release] Seeded release DB from development for project ${projectId.substring(0, 8)}`);
            }
        }
        bustCache(releaseDir);
        const latest = await db_1.prisma.version.findFirst({
            where: { projectId },
            orderBy: { id: "desc" },
        });
        const commitNum = latest ? parseInt(latest.version, 10) || 0 : 0;
        await db_1.prisma.project.update({
            where: { id: projectId },
            data: { releaseCommit: commitNum, status: "released" },
        });
        console.log(`[Release] Project ${projectId.substring(0, 8)} → released commit #${commitNum}`);
        return commitNum;
    }
    /**
     * Revert: restore commits/N/ to development/, delete newer commits.
     */
    async revertToCommit(projectId, commitNum) {
        const projectDir = path_1.default.join(PROJECTS_DIR, projectId);
        const commitDir = path_1.default.join(projectDir, "commits", String(commitNum));
        if (!fs_1.default.existsSync(commitDir)) {
            throw new Error(`Commit #${commitNum} not found on disk`);
        }
        this.syncToDev(projectId, commitDir);
        const allCommits = await db_1.prisma.version.findMany({
            where: { projectId },
            orderBy: { id: "asc" },
        });
        const toDelete = [];
        for (const v of allCommits) {
            const num = parseInt(v.version, 10);
            if (!isNaN(num) && num > commitNum) {
                toDelete.push(v.id);
                rmDirSync(path_1.default.join(projectDir, "commits", String(num)));
            }
        }
        if (toDelete.length > 0) {
            await db_1.prisma.version.deleteMany({ where: { id: { in: toDelete } } });
        }
        console.log(`[Revert] Project ${projectId.substring(0, 8)} → reverted to commit #${commitNum}, deleted ${toDelete.length} newer commit(s)`);
    }
    async getCommits(projectId) {
        return db_1.prisma.version.findMany({
            where: { projectId },
            orderBy: { id: "desc" },
        });
    }
    getLogPath(projectId, commitNum) {
        const logFile = path_1.default.join(PROJECTS_DIR, projectId, "commits", String(commitNum), "agent.log");
        return fs_1.default.existsSync(logFile) ? logFile : null;
    }
    getDetailedLogPath(projectId, commitNum) {
        const file = path_1.default.join(PROJECTS_DIR, projectId, "commits", String(commitNum), "detailed-log.json");
        return fs_1.default.existsSync(file) ? file : null;
    }
    /**
     * Migrate existing projects from old layout (root frontend/backend/data)
     * to new layout (development/, release/data/).
     */
    async migrateExistingProjects() {
        const projects = await db_1.prisma.project.findMany({
            where: {
                status: { in: ["deployed", "released", "building", "planning", "created", "error"] },
            },
        });
        let migrated = 0;
        for (const project of projects) {
            const projectDir = path_1.default.join(PROJECTS_DIR, project.id);
            const oldFrontend = path_1.default.join(projectDir, "frontend");
            const devDir = path_1.default.join(projectDir, "development");
            if (!fs_1.default.existsSync(oldFrontend))
                continue;
            if (fs_1.default.existsSync(path_1.default.join(devDir, "frontend")))
                continue;
            try {
                fs_1.default.mkdirSync(devDir, { recursive: true });
                copyDirSync(path_1.default.join(projectDir, "frontend"), path_1.default.join(devDir, "frontend"));
                copyDirSync(path_1.default.join(projectDir, "backend"), path_1.default.join(devDir, "backend"));
                const oldDataDir = path_1.default.join(projectDir, "data");
                const devDataDir = path_1.default.join(devDir, "data");
                fs_1.default.mkdirSync(devDataDir, { recursive: true });
                if (fs_1.default.existsSync(path_1.default.join(oldDataDir, "app.db"))) {
                    fs_1.default.copyFileSync(path_1.default.join(oldDataDir, "app.db"), path_1.default.join(devDataDir, "app.db"));
                }
                const releaseDir = path_1.default.join(projectDir, "release");
                if (fs_1.default.existsSync(releaseDir)) {
                    const releaseDataDir = path_1.default.join(releaseDir, "data");
                    fs_1.default.mkdirSync(releaseDataDir, { recursive: true });
                    if (!fs_1.default.existsSync(path_1.default.join(releaseDataDir, "app.db")) && fs_1.default.existsSync(path_1.default.join(oldDataDir, "app.db"))) {
                        fs_1.default.copyFileSync(path_1.default.join(oldDataDir, "app.db"), path_1.default.join(releaseDataDir, "app.db"));
                    }
                }
                const commitsDir = path_1.default.join(projectDir, "commits");
                if (!fs_1.default.existsSync(path_1.default.join(commitsDir, "0"))) {
                    fs_1.default.mkdirSync(path_1.default.join(commitsDir, "0"), { recursive: true });
                    copyDirSync(path_1.default.join(projectDir, "frontend"), path_1.default.join(commitsDir, "0", "frontend"));
                    copyDirSync(path_1.default.join(projectDir, "backend"), path_1.default.join(commitsDir, "0", "backend"));
                    const existingVersion = await db_1.prisma.version.findFirst({ where: { projectId: project.id } });
                    if (!existingVersion) {
                        await db_1.prisma.version.create({
                            data: { projectId: project.id, version: "0", changelog: "Initial version (migrated)" },
                        });
                    }
                    if (project.releaseCommit === null) {
                        await db_1.prisma.project.update({
                            where: { id: project.id },
                            data: { releaseCommit: 0 },
                        });
                    }
                }
                rmDirSync(path_1.default.join(projectDir, "frontend"));
                rmDirSync(path_1.default.join(projectDir, "backend"));
                rmDirSync(path_1.default.join(projectDir, "data"));
                migrated++;
                console.log(`[Migration] Project "${project.name}" (${project.id.substring(0, 8)}) → migrated to new layout`);
            }
            catch (err) {
                console.error(`[Migration] Failed for project ${project.id.substring(0, 8)}:`, err);
            }
        }
        return migrated;
    }
}
exports.commitService = new CommitService();
//# sourceMappingURL=commit.service.js.map