declare const router: import("express-serve-static-core").Router;
export declare const BUCKET_ROOT: string;
export declare const MIME_TO_EXT: Record<string, string>;
export interface BucketFileInfo {
    filename: string;
    file_id: string;
    ext: string;
    size: number;
    direct_link: string;
    uploaded_at: string;
}
export declare function listProjectFiles(projectId: string): BucketFileInfo[];
export declare function deleteProjectFile(projectId: string, filename: string): boolean;
export declare function uploadProjectFile(projectId: string, data: string, name?: string): {
    file_id: string;
    direct_link: string;
    filename: string;
    size: number;
    mime: string;
};
export declare function uploadProjectFileFromBuffer(projectId: string, buf: Buffer, mime: string): {
    file_id: string;
    direct_link: string;
    filename: string;
    size: number;
    mime: string;
};
export default router;
//# sourceMappingURL=bucket.routes.d.ts.map