export declare function encryptToken(token: string): string;
export declare function decryptToken(encrypted: string): string;
//# sourceMappingURL=crypto.service.d.ts.map