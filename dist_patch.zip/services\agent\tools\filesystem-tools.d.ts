import { AgentToolDefinition } from "./types";
export declare const FILESYSTEM_TOOL_DEFS: AgentToolDefinition[];
//# sourceMappingURL=filesystem-tools.d.ts.map