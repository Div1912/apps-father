import type { Request, Response, NextFunction } from "express";
export declare class BotRunnerService {
    private bots;
    /**
     * Start (or re-start) the user's bot and register its webhook.
     *
     * @param sendOwnerWelcome When true, immediately push the "Good job, bot
     *   created" card to the owner via bot.api.sendMessage *after* the webhook
     *   is live. This covers the race where the user is bounced into their new
     *   bot by mobile Telegram and presses /start before our webhook is set —
     *   they'd otherwise get nothing. Pass `false` (the default) when restoring
     *   bots at server boot, or every old user would get spammed with the
     *   welcome card on every deploy.
     */
    startBot(projectId: string, token: string, botUsername: string, sendOwnerWelcome?: boolean): Promise<void>;
    /**
     * Push the localized "Good job, bot created" card directly to the owner
     * the moment the webhook is live. This covers the mobile race where
     * Telegram bounces the user into their freshly created bot and they tap
     * /start before our webhook has been registered — without this, the
     * /start update is dropped on the floor and the user sees nothing.
     */
    private sendOwnerWelcome;
    stopBot(projectId: string): Promise<void>;
    getWebhookHandler(tokenHash: string): ((req: Request, res: Response, next: NextFunction) => void) | null;
    loadAllBots(): Promise<void>;
    isRunning(projectId: string): boolean;
    getRunningCount(): number;
    private hashToken;
    private getTokenFromInstance;
    /** Returns the webhook route path registered in routes.js, or null if none. */
    private getCustomWebhookPath;
    private hasCustomWebhook;
    private forwardToAppWebhook;
    /**
     * Simulate a Telegram update hitting the bot webhook without a real Telegram
     * account. All calls to api.telegram.org that the routes.js makes are
     * intercepted and returned as a captured list. Also logged via ALS so
     * server_logs can show them.
     */
    simulateBotWebhook(projectId: string, update: any, options?: {
        deployment?: "release" | "development";
    }): Promise<Array<{
        method: string;
        body: any;
    }>>;
}
export declare const botRunnerService: BotRunnerService;
//# sourceMappingURL=bot-runner.service.d.ts.map