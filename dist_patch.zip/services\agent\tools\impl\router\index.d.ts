import type { AskTool } from "../ask/AskTool";
import type { RouterTool } from "./RouterTool";
export { QuestionnaireTool } from "./QuestionnaireTool";
export { ProposeActionTool } from "./ProposeActionTool";
export type { RouterTool } from "./RouterTool";
export type { RouterContext, RouterChatHooks, ProposalKind, QuestionnaireResult, } from "./RouterContext";
/**
 * Adapt an AskTool (which only needs the read-only AskContext) so the router
 * can use it. Avoids duplicating ReadFile / ListFiles / DbQuery / etc.
 *
 * RouterContext extends AskContext, so the AskTool's execute method receives
 * a structurally-compatible object — no actual delegation needed beyond the
 * type erasure here.
 */
export declare function wrapAskTool(askTool: AskTool): RouterTool;
//# sourceMappingURL=index.d.ts.map