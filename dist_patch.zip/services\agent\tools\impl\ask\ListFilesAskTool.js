"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ListFilesAskTool = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const config_1 = require("../../../config");
class ListFilesAskTool {
    name = "list_files";
    definition = {
        type: "function",
        function: {
            name: "list_files",
            description: "List files in the live app (frontend/ + backend/) with sizes. Use this to see what the project actually contains before asking the owner.",
            parameters: { type: "object", properties: {}, additionalProperties: false },
        },
    };
    async execute(_args, ctx) {
        if (!ctx.projectDir)
            return "Project has no built files yet.";
        const files = this._walkDir(ctx.projectDir, ctx.projectDir);
        if (files.length === 0)
            return "(empty project)";
        return files.slice(0, 80).join("\n") + (files.length > 80 ? `\n... +${files.length - 80} more` : "");
    }
    _walkDir(dir, base) {
        const results = [];
        if (!fs_1.default.existsSync(dir))
            return results;
        for (const entry of fs_1.default.readdirSync(dir, { withFileTypes: true })) {
            const fullPath = path_1.default.join(dir, entry.name);
            if (config_1.SKIP_DIRS.has(entry.name))
                continue;
            if (entry.isDirectory()) {
                results.push(...this._walkDir(fullPath, base));
            }
            else {
                const ext = path_1.default.extname(entry.name).toLowerCase();
                const relPath = path_1.default.relative(base, fullPath).replace(/\\/g, "/");
                try {
                    const stat = fs_1.default.statSync(fullPath);
                    const sizeKB = (stat.size / 1024).toFixed(1);
                    if (config_1.BINARY_EXTS.has(ext) || config_1.SKIP_EXTS.has(ext)) {
                        results.push(`${relPath} (${sizeKB}KB, binary)`);
                        continue;
                    }
                    if (stat.size > config_1.READ_FILE_MAX_BYTES) {
                        results.push(`${relPath} (${sizeKB}KB, large)`);
                        continue;
                    }
                    results.push(`${relPath} (${fs_1.default.readFileSync(fullPath, "utf-8").split("\n").length} lines, ${sizeKB}KB)`);
                }
                catch {
                    results.push(relPath);
                }
            }
        }
        return results;
    }
}
exports.ListFilesAskTool = ListFilesAskTool;
//# sourceMappingURL=ListFilesAskTool.js.map