import type { RouterTool } from "./RouterTool";
import type { RouterContext, ProposalKind } from "./RouterContext";
/**
 * Terminal tool. The router calls this exactly once to classify the user's
 * intent and emit a proposal card. The card is shown immediately in the chat.
 *
 * Kinds:
 *  - answer      : answered in `description`; no agent run required (free)
 *  - suggestions : short list of ideas shown to user (free)
 *  - build       : create a new app; pass `brief` with the full app spec
 *  - update      : single focused change; pass `prefilledPrompt`
 *  - update-plan : multi-step change; pass `plan` array + `prefilledPrompt`
 *  - bug-fix     : fix a reported bug; pass `prefilledPrompt`
 *
 * For paid kinds the router MUST also classify `complexity` into one of:
 *   trivial | small | medium | large | huge
 * That bucket selects the column of the agentPricing matrix and yields the
 * exact credit cost shown to the user.
 *
 * After this returns, the runner sees ctx.proposalEmitted=true and stops.
 */
export declare class ProposeActionTool implements RouterTool {
    name: string;
    definition: {
        type: string;
        function: {
            name: string;
            description: string;
            parameters: {
                type: string;
                properties: {
                    kind: {
                        type: string;
                        enum: ProposalKind[];
                        description: string;
                    };
                    complexity: {
                        type: string;
                        enum: import("../../../../../services/runtime-config.service").AgentComplexity[];
                        description: string;
                    };
                    title: {
                        type: string;
                        description: string;
                    };
                    description: {
                        type: string;
                        description: string;
                    };
                    plan: {
                        type: string;
                        items: {
                            type: string;
                        };
                        description: string;
                    };
                    brief: {
                        type: string;
                        description: string;
                    };
                    prefilledPrompt: {
                        type: string;
                        description: string;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
        };
    };
    execute(args: Record<string, any>, ctx: RouterContext): Promise<string>;
}
//# sourceMappingURL=ProposeActionTool.d.ts.map