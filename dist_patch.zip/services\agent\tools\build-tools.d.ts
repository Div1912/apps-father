import { AgentToolDefinition } from "./types";
export declare const BUILD_TOOL_DEFS: AgentToolDefinition[];
//# sourceMappingURL=build-tools.d.ts.map