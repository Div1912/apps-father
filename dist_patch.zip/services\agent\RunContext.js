"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RunContext = void 0;
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
class RunContext {
    // ── Static per-run config ────────────────────────────────────────────────
    projectId;
    projectDir;
    projectRootDir;
    commitDir;
    commitNum;
    mode;
    botToken;
    tierConfig;
    taskId;
    selectedWorkflow;
    logger;
    onAskUser;
    _rawProgress;
    // ── Mutable agent state ──────────────────────────────────────────────────
    wroteFiles = false;
    deployed = false;
    finished = false;
    configuredApp = false;
    deployCount = 0;
    deployLocked = false;
    technicalPlan = null;
    technicalPlanSubmitted;
    testsRun = { telegram: false, api: false, ws: false };
    wsCoverage = { types: new Set(), scenarios: new Set() };
    loadedSkills = new Set();
    validatorResults = [];
    testResults = [];
    lastWsFailureSignature = "";
    repeatedWsFailureCount = 0;
    summary = "";
    shortSummary = "";
    contextDiff = "";
    consecutiveNoWrite = 0;
    // ── Billing / cost ───────────────────────────────────────────────────────
    totalInputTokens = 0;
    totalOutputTokens = 0;
    totalCacheWriteTokens = 0;
    totalCacheReadTokens = 0;
    liveCostUsd = 0;
    /**
     * Authoritative USD cost reported by OpenRouter (sum of `usage.cost`
     * across iterations). Preferred over the token×price-table estimate when
     * non-zero. Filled when the request opts into usage accounting via
     * `extra_body.usage = { include: true }`.
     */
    totalCostUsd = 0;
    /** Sum of `usage.cost_details.upstream_inference_prompt_cost`. */
    totalCostUsdInput = 0;
    /** Sum of `usage.cost_details.upstream_inference_completions_cost`. */
    totalCostUsdOutput = 0;
    startBalance;
    currentPercent;
    // ── Timing ───────────────────────────────────────────────────────────────
    runStartMs = Date.now();
    stepCounter = 0;
    // ── Termination signal ───────────────────────────────────────────────────
    /** Set by FinishTool to stop the runner loop and return this result. */
    terminalResult = null;
    // ── Detailed log accumulator ─────────────────────────────────────────────
    detailedEntries = [];
    constructor(params, userBalance) {
        this.projectId = params.projectId;
        this.projectDir = params.projectDir;
        this.projectRootDir = params.projectRootDir;
        this.commitDir = params.commitDir;
        this.commitNum = params.commitNum;
        this.mode = params.mode;
        this.botToken = params.botToken;
        this.tierConfig = params.tierConfig;
        this.taskId = params.taskId;
        this.selectedWorkflow = params.selectedWorkflow;
        this.logger = params.logger;
        this.onAskUser = params.onAskUser;
        this._rawProgress = params.rawProgress;
        this.technicalPlanSubmitted = params.mode === "update";
        this.startBalance = userBalance ?? 0;
    }
    // ── Event emitters ───────────────────────────────────────────────────────
    async progress(p) {
        p.costUsd = this.liveCostUsd;
        p.balance = this.startBalance > 0 ? Math.max(0, this.startBalance - this.liveCostUsd) : undefined;
        return this._rawProgress(p);
    }
    newStepId(prefix) {
        return `${prefix}-${Date.now().toString(36)}-${++this.stepCounter}`;
    }
    async emitStepStart(kind, title, toolName, target) {
        const stepId = this.newStepId(toolName || kind);
        await this.progress({
            event: "step_start",
            stepId,
            kind,
            title,
            toolName,
            target,
            action: title,
            detail: target?.file || target?.url || target?.key || "",
            percent: this.currentPercent,
        });
        return stepId;
    }
    async emitStepEnd(stepId, status, meta) {
        await this.progress({
            event: "step_end",
            stepId,
            status,
            meta,
            action: "",
            detail: "",
            percent: this.currentPercent,
        });
    }
    async emitNarrationStart(stepId) {
        await this.progress({ event: "narration_start", stepId, action: "", detail: "", percent: this.currentPercent });
    }
    async emitNarrationChunk(stepId, delta, text) {
        await this.progress({ event: "narration_chunk", stepId, delta, text, action: "", detail: "", percent: this.currentPercent });
    }
    async emitNarrationEnd(stepId) {
        await this.progress({ event: "narration_end", stepId, action: "", detail: "", percent: this.currentPercent });
    }
    async emitWritingChunk(stepId, toolName, argsDelta, argsFull) {
        await this.progress({
            event: "writing_chunk",
            stepId,
            toolName,
            delta: argsDelta,
            text: argsFull,
            action: "",
            detail: "",
            percent: this.currentPercent,
        });
    }
    // ── Terminal signal ───────────────────────────────────────────────────────
    /** Called by FinishTool to stop the runner loop. */
    terminate(result) {
        this.terminalResult = result;
        this.finished = true;
    }
    // ── Detailed log ──────────────────────────────────────────────────────────
    writeDetailedLog(reason) {
        try {
            const detailedLogPath = path_1.default.join(this.commitDir, "detailed-log.json");
            fs_1.default.writeFileSync(detailedLogPath, JSON.stringify({
                projectId: this.projectId,
                commitNum: this.commitNum,
                mode: this.mode,
                selectedWorkflow: this.selectedWorkflow,
                reason,
                loadedSkills: [...this.loadedSkills],
                technicalPlan: this.technicalPlan,
                state: {
                    technicalPlanSubmitted: this.technicalPlanSubmitted,
                    wroteFiles: this.wroteFiles,
                    deployed: this.deployed,
                    finished: this.finished,
                    testsRun: this.testsRun,
                },
                validatorResults: this.validatorResults,
                testResults: this.testResults,
                entries: this.detailedEntries,
            }, null, 2), "utf-8");
        }
        catch (err) {
            console.warn(`[Agent] failed to write detailed-log.json (${reason}): ${err.message}`);
        }
    }
}
exports.RunContext = RunContext;
//# sourceMappingURL=RunContext.js.map