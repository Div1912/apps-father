"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const console_tagger_service_1 = require("./services/console-tagger.service");
// Install before any other import that might log, so per-project AsyncLocalStorage
// tagging is in place before any user-app code runs.
(0, console_tagger_service_1.installConsoleTagger)();
// Make BigInt JSON-serialisable across the whole app. Without this, returning
// any Prisma row with a BigInt column (App Store token reserves, telegram IDs,
// etc.) from Express crashes JSON.stringify with "Do not know how to serialize
// a BigInt". Existing call sites that manually convert with .toString() keep
// working; this just makes implicit serialisation safe everywhere.
BigInt.prototype.toJSON = function () { return this.toString(); };
const config_1 = require("./config");
const db_1 = require("./db");
const bot_1 = require("./bot");
const server_1 = require("./web/server");
const bot_runner_service_1 = require("./services/bot-runner.service");
const grammy_1 = require("grammy");
const processing_1 = require("./bot/processing");
const commit_service_1 = require("./services/commit.service");
const chat_service_1 = require("./services/chat.service");
const retention_service_1 = require("./services/retention.service");
const ton_monitor_service_1 = require("./services/ton-monitor.service");
const app_log_service_1 = require("./services/app-log.service");
async function recoverStuckProjects() {
    const stuck = await db_1.prisma.project.findMany({ where: { status: "building" } });
    for (const p of stuck) {
        const newStatus = p.generatedCode ? "deployed" : p.plan ? "planning" : "created";
        await db_1.prisma.project.update({ where: { id: p.id }, data: { status: newStatus } });
        console.log(`[Recovery] Project "${p.name}" (${p.id}): building -> ${newStatus}`);
    }
    if (stuck.length > 0)
        console.log(`[Recovery] Recovered ${stuck.length} stuck project(s)`);
    // Heal chat histories whose last message is a dangling `progress` / `question`
    // (server died before the agent could write a `result`/`error`/`answer`).
    // Runs across all projects, not just the ones flipped above, so we also catch
    // any orphans from prior restarts where the DB was already healed.
    const healed = chat_service_1.chatService.recoverDanglingProgress("Build interrupted by server restart. Please retry.");
    if (healed.length > 0) {
        console.log(`[Recovery] Healed dangling progress in ${healed.length} chat history(ies)`);
    }
}
async function main() {
    console.log("🏗️  Apps Father starting...\n");
    console.log("[1/4] Connecting to database...");
    await (0, db_1.connectDatabase)();
    // Persist runtime logs from now on. Lines written before this point
    // (during module init) were buffered by the tee but won't be flushed
    // until the timer fires — no data lost. Safe to call before / after DB.
    (0, app_log_service_1.startAppLogFlusher)();
    await recoverStuckProjects();
    console.log("[1.5/4] Migrating existing projects to version control...");
    const migrated = await commit_service_1.commitService.migrateExistingProjects();
    if (migrated > 0)
        console.log(`[Migration] Migrated ${migrated} project(s) to version control`);
    console.log("[2/4] Starting web server...");
    await (0, server_1.startWebServer)();
    console.log("[3/4] Loading managed bots...");
    await bot_runner_service_1.botRunnerService.loadAllBots();
    console.log("[4/4] Starting Apps Father bot...");
    const bot = (0, bot_1.createBot)();
    if (config_1.config.nodeEnv === "production") {
        const app = (0, server_1.getExpressApp)();
        if (app) {
            app.post("/bot-webhook", (0, grammy_1.webhookCallback)(bot, "express"));
        }
        const webhookUrl = `${config_1.config.baseUrl}/bot-webhook`;
        await bot.api.setWebhook(webhookUrl, {
            secret_token: config_1.config.webhookSecret,
        });
        console.log(`[Bot] Webhook set: ${webhookUrl}`);
    }
    else {
        bot.start({
            onStart: (info) => {
                console.log(`[Bot] Apps Father bot started as @${info.username}`);
            },
        });
    }
    (0, retention_service_1.startRetentionScheduler)();
    ton_monitor_service_1.tonMonitorService.start();
    console.log("\n✅ Apps Father is running!");
    console.log(`   Domain: ${config_1.config.domain}`);
    console.log(`   Port: ${config_1.config.port}`);
    console.log(`   Mode: ${config_1.config.nodeEnv}`);
    console.log(`   Managed bots: ${bot_runner_service_1.botRunnerService.getRunningCount()}`);
}
main().catch((err) => {
    console.error("Fatal error:", err);
    process.exit(1);
});
process.on("unhandledRejection", (err) => {
    console.error("Unhandled rejection:", err);
});
// User-generated apps run inside this process and may create pg/ws clients
// without 'error' listeners. An unhandled EventEmitter 'error' event would
// otherwise crash the entire server. Log it and keep running.
process.on("uncaughtException", (err) => {
    console.error("Uncaught exception (isolated — server continues):", err?.message || err);
});
let shuttingDown = false;
async function gracefulShutdown(signal) {
    if (shuttingDown)
        return;
    shuttingDown = true;
    console.log(`\n[Shutdown] ${signal} received.`);
    if (processing_1.processingProjects.size === 0) {
        console.log("[Shutdown] No active agents. Exiting.");
        process.exit(0);
    }
    console.log(`[Shutdown] Waiting for ${processing_1.processingProjects.size} active agent(s) to finish...`);
    const start = Date.now();
    const MAX_WAIT = 5 * 60 * 1000;
    while (processing_1.processingProjects.size > 0 && Date.now() - start < MAX_WAIT) {
        console.log(`[Shutdown] ${processing_1.processingProjects.size} agent(s) still running (${Math.round((Date.now() - start) / 1000)}s elapsed)`);
        await new Promise(r => setTimeout(r, 5000));
    }
    if (processing_1.processingProjects.size > 0) {
        console.log(`[Shutdown] Timeout reached. ${processing_1.processingProjects.size} agent(s) still running. Force exiting.`);
    }
    else {
        console.log("[Shutdown] All agents finished. Exiting.");
    }
    // Best-effort drain of any buffered log lines so the final shutdown
    // messages above land in the DB before we exit.
    try {
        (0, app_log_service_1.stopAppLogFlusher)();
        await (0, app_log_service_1.drainAppLogs)();
    }
    catch { /* swallow — we're exiting */ }
    process.exit(0);
}
process.on("SIGINT", () => gracefulShutdown("SIGINT"));
process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
//# sourceMappingURL=index.js.map