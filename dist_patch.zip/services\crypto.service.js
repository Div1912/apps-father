"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.encryptToken = encryptToken;
exports.decryptToken = decryptToken;
const crypto_js_1 = __importDefault(require("crypto-js"));
const config_1 = require("../config");
function encryptToken(token) {
    return crypto_js_1.default.AES.encrypt(token, config_1.config.encryptionKey).toString();
}
function decryptToken(encrypted) {
    const bytes = crypto_js_1.default.AES.decrypt(encrypted, config_1.config.encryptionKey);
    return bytes.toString(crypto_js_1.default.enc.Utf8);
}
//# sourceMappingURL=crypto.service.js.map