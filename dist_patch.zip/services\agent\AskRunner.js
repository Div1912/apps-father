"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AskRunner = void 0;
const openrouter_service_1 = require("../openrouter.service");
/**
 * Simplified runner for the answerQuestionStream tool-use loop.
 * Mirrors AgentRunner's fluent pattern but with the lighter ask-tool context.
 */
class AskRunner {
    async run(opts) {
        const { modelCfg, systemPrompt, tools, ctx, onChunk } = opts;
        const toolMap = new Map(tools.map(t => [t.name, t]));
        const openAiTools = tools.map(t => t.definition);
        const messages = [...opts.messages];
        const reasoningBudget = modelCfg.reasoningBudget ?? 0;
        const maxIterations = modelCfg.maxIterations ?? 4;
        const client = (0, openrouter_service_1.getOpenRouterClient)();
        let fullText = "";
        let inputTokens = 0;
        let outputTokens = 0;
        let costUsd = 0;
        let costUsdInput = 0;
        let costUsdOutput = 0;
        for (let iter = 0; iter < maxIterations; iter++) {
            const params = {
                model: modelCfg.modelId,
                max_tokens: modelCfg.maxTokens,
                messages: [{ role: "system", content: systemPrompt }, ...messages],
                tools: openAiTools,
                tool_choice: "auto",
                ...(opts.telegramId ? { user: opts.telegramId } : {}),
                // Opt into OpenRouter's usage accounting so each response carries
                // `usage.cost` and `usage.cost_details`. This is what the admin
                // Sessions table sums up for the authoritative price.
                extra_body: { session_id: opts.sessionId, usage: { include: true } },
                ...(this._getProviderRouting(modelCfg.modelId, modelCfg.provider)
                    ? { provider: this._getProviderRouting(modelCfg.modelId, modelCfg.provider) }
                    : {}),
                ...(reasoningBudget > 0 ? { reasoning: { max_tokens: reasoningBudget } } : {}),
            };
            let response;
            try {
                response = await this._streamCall(params, (delta) => {
                    fullText += delta;
                    onChunk(delta, fullText);
                });
            }
            catch (err) {
                console.warn("[Ask] Tool streaming failed, falling back to plain answer:", err.message);
                const fallback = await client.chat.completions.create({
                    ...params, tools: undefined, tool_choice: undefined,
                });
                const txt = fallback.choices?.[0]?.message?.content || "";
                if (txt) {
                    fullText += txt;
                    onChunk(txt, fullText);
                }
                if (fallback.usage) {
                    inputTokens += fallback.usage.prompt_tokens || 0;
                    outputTokens += fallback.usage.completion_tokens || 0;
                    costUsd += Number(fallback.usage.cost) || 0;
                    costUsdInput += Number(fallback.usage.cost_details?.upstream_inference_prompt_cost) || 0;
                    costUsdOutput += Number(fallback.usage.cost_details?.upstream_inference_completions_cost) || 0;
                }
                break;
            }
            if (response.usage) {
                inputTokens += response.usage.prompt_tokens || 0;
                outputTokens += response.usage.completion_tokens || 0;
                costUsd += Number(response.usage.cost) || 0;
                costUsdInput += Number(response.usage.cost_details?.upstream_inference_prompt_cost) || 0;
                costUsdOutput += Number(response.usage.cost_details?.upstream_inference_completions_cost) || 0;
            }
            const choice = response.choices?.[0];
            const assistantMsg = choice?.message || {};
            const toolCalls = assistantMsg.tool_calls || [];
            messages.push({
                role: "assistant",
                content: assistantMsg.content || "",
                tool_calls: toolCalls.length > 0 ? toolCalls : undefined,
            });
            if (toolCalls.length === 0 || choice?.finish_reason === "stop")
                break;
            for (const tc of toolCalls) {
                let argsObj = {};
                try {
                    argsObj = JSON.parse(tc.function?.arguments || "{}");
                }
                catch { }
                const tool = toolMap.get(tc.function?.name || "");
                const toolResult = tool
                    ? await tool.execute(argsObj, ctx).catch(err => `Tool error: ${err.message}`)
                    : `Unknown tool: ${tc.function?.name}`;
                messages.push({ role: "tool", tool_call_id: tc.id, content: toolResult });
            }
        }
        return {
            text: fullText || "Unable to answer.",
            inputTokens, outputTokens,
            costUsd, costUsdInput, costUsdOutput,
        };
    }
    _getProviderRouting(modelId, provider) {
        const sel = provider?.trim();
        return sel ? { only: [sel], allow_fallbacks: false } : undefined;
    }
    async _streamCall(params, onTextDelta) {
        const client = (0, openrouter_service_1.getOpenRouterClient)();
        const stream = (await client.chat.completions.create({
            ...params, stream: true, stream_options: { include_usage: true },
        }));
        let assistantText = "";
        const toolCallAcc = new Map();
        let usage;
        let finishReason = null;
        let modelEcho;
        let id;
        for await (const chunk of stream) {
            if (!chunk)
                continue;
            if (chunk.id)
                id = chunk.id;
            if (chunk.model)
                modelEcho = chunk.model;
            if (chunk.usage)
                usage = chunk.usage;
            const choice = chunk.choices?.[0];
            if (!choice)
                continue;
            const delta = choice.delta || {};
            if (typeof delta.content === "string" && delta.content.length > 0) {
                assistantText += delta.content;
                try {
                    onTextDelta(delta.content);
                }
                catch { }
            }
            if (Array.isArray(delta.tool_calls)) {
                for (const tc of delta.tool_calls) {
                    const idx = typeof tc.index === "number" ? tc.index : 0;
                    const acc = toolCallAcc.get(idx) || { name: "", args: "" };
                    if (tc.id)
                        acc.id = tc.id;
                    if (tc.function?.name)
                        acc.name = (acc.name || "") + tc.function.name;
                    if (tc.function?.arguments)
                        acc.args += tc.function.arguments;
                    toolCallAcc.set(idx, acc);
                }
            }
            if (choice.finish_reason)
                finishReason = choice.finish_reason;
        }
        const tool_calls = [...toolCallAcc.entries()]
            .sort((a, b) => a[0] - b[0])
            .map(([idx, v]) => ({ id: v.id || `call_${idx}`, type: "function", function: { name: v.name, arguments: v.args || "{}" } }));
        const fakeMessage = { role: "assistant", content: assistantText };
        if (tool_calls.length > 0)
            fakeMessage.tool_calls = tool_calls;
        return {
            id: id || "stream",
            object: "chat.completion",
            created: Math.floor(Date.now() / 1000),
            model: modelEcho || params.model,
            choices: [{ index: 0, message: fakeMessage, finish_reason: finishReason || (tool_calls.length > 0 ? "tool_calls" : "stop"), logprobs: null }],
            usage,
        };
    }
}
exports.AskRunner = AskRunner;
//# sourceMappingURL=AskRunner.js.map