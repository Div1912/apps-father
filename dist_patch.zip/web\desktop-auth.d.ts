export declare function signDesktopToken(payload: {
    telegramId: number;
    username?: string;
    firstName?: string;
}): string;
export declare function verifyDesktopToken(token: string): {
    valid: boolean;
    telegramId?: number;
    username?: string;
    firstName?: string;
};
//# sourceMappingURL=desktop-auth.d.ts.map