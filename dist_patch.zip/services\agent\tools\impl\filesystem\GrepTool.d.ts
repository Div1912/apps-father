import type OpenAI from "openai";
import type { AgentTool } from "../../../AgentTool";
import type { RunContext } from "../../../RunContext";
export declare class GrepTool implements AgentTool {
    renderDefinition(): OpenAI.Chat.Completions.ChatCompletionTool;
    execute(args: Record<string, any>, ctx: RunContext): Promise<string>;
    private _safePath;
}
//# sourceMappingURL=GrepTool.d.ts.map