import type { AskTool } from "./AskTool";
import type { AskContext } from "./AskContext";
export declare class ListFilesAskTool implements AskTool {
    name: string;
    definition: {
        type: string;
        function: {
            name: string;
            description: string;
            parameters: {
                type: string;
                properties: {};
                additionalProperties: boolean;
            };
        };
    };
    execute(_args: Record<string, any>, ctx: AskContext): Promise<string>;
    private _walkDir;
}
//# sourceMappingURL=ListFilesAskTool.d.ts.map