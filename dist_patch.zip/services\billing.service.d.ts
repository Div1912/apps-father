import type { AgentSessionType, AgentComplexity } from "./runtime-config.service";
export interface TokenUsage {
    input_tokens: number;
    output_tokens: number;
    cache_creation_input_tokens: number;
    cache_read_input_tokens: number;
}
export interface UsageResult {
    costUsd: number;
    creditsCharged: number;
    newBalance: number;
    newCredits: number;
}
export declare class BillingService {
    private decodeTonTextComment;
    private extractTonMessageText;
    getUserBalance(userId: number): Promise<number>;
    getUserCredits(userId: number): Promise<number>;
    /** Check if user has enough credits. minAmount is in credits. */
    hasBalance(userId: number, minAmount?: number): Promise<boolean>;
    hasCredits(userId: number, minCredits?: number): Promise<boolean>;
    private calculateCostWithPricing;
    calculateCostAsync(model: string, usage: TokenUsage): Promise<number>;
    /**
     * Immediately deduct the flat credit cost for a session type from the user's
     * balance so the balance update is visible before the agent finishes.
     * Returns the credits charged and the new balance.
     * Call recordUsage afterwards with preCharged=true to log without double-deducting.
     */
    preChargeAction(userId: number, projectId: string | null, sessionType: AgentSessionType, complexity?: AgentComplexity, planLength?: number): Promise<{
        creditsCharged: number;
        newCredits: number;
    }>;
    /**
     * Pre-charge an exact, already-computed credit amount. Used by
     * `execute-proposal` to honour the price quoted to the user on the
     * proposal card, immune to admin price edits between propose and execute.
     */
    preChargeAmount(userId: number, projectId: string | null, creditsCharged: number): Promise<{
        creditsCharged: number;
        newCredits: number;
    }>;
    private _preChargeWithAmount;
    /**
     * Refund credits previously taken via preChargeAction when the agent
     * fails before producing usable output. Logs a UsageLog row with a
     * negative `creditsCharged` so admin sessions page reflects refunds.
     * Operation should be the original action id ("build", "update", ...);
     * we tag the log row as `refund_<operation>` for clarity.
     * Idempotent: refunds the requested amount as a single increment, so
     * callers must guard against double-refund themselves (we do that via
     * progress-message metadata flagging in /abort recovery).
     */
    refundAction(userId: number, projectId: string | null, operation: string, credits: number, taskId?: string): Promise<{
        newCredits: number;
    }>;
    /**
     * True iff the user has ever made a confirmed deposit (any payment row
     * with status = "confirmed"). Used to gate the player-preview paywall.
     */
    hasEverDeposited(userId: number): Promise<boolean>;
    /**
     * True iff this user has previously unlocked the preview for this
     * project (one-time 20-credit purchase logged in usage_logs).
     */
    hasUnlockedPreview(userId: number, projectId: string): Promise<boolean>;
    /**
     * True iff this user has previously paid the one-time 15-credit fee
     * to unlock the "Create Bot" / link-bot flow for this project.
     * The actual bot-link itself is tracked via Project.botUsername; this
     * is just the gate that prevents charging the same project twice when
     * the user re-clicks the button before completing the flow.
     */
    hasUnlockedBotCreate(userId: number, projectId: string): Promise<boolean>;
    recordUsage(userId: number, projectId: string | null, model: string, usage: TokenUsage, operation: string, _legacyTierId?: string, preCharged?: boolean | number, taskId?: string): Promise<UsageResult>;
    /**
     * Resolve credits to grant for a payment.
     * Uses bundle definition when bundleId is present, else falls back to creditsPerDollar rate.
     * isFirstPurchase = user has 0 previously confirmed payments → doubles total.
     */
    resolveCreditsForPayment(paymentId: number): Promise<{
        total: number;
        base: number;
        bonus: number;
        isFirstPurchase: boolean;
        bundleName?: string;
    }>;
    createTopUp(userId: number, amountUsd: number, bundleId?: string): Promise<{
        paymentId: number;
        invoiceUrl: string;
    }>;
    createCryptoBotInvoice(userId: number, amountUsd: number, bundleId?: string): Promise<{
        paymentId: number;
        invoiceUrl: string;
    }>;
    createStarsInvoice(userId: number, amountUsd: number, stars: number, bundleId?: string): Promise<{
        paymentId: number;
        invoiceUrl: string;
    }>;
    static readonly TON_WALLET = "UQCoZZWxI49ZtHqiUfc5v23OzY0lGG31LNEvyxu_NDlE4wNV";
    createTonPayment(userId: number, amountUsd: number, bundleId?: string): Promise<{
        paymentId: number;
        walletAddress: string;
        amountNano: string;
    }>;
    getTonUsdPrice(): Promise<number>;
    verifyTonPayment(paymentId: number): Promise<{
        confirmed: boolean;
        balance?: number;
    }>;
    reconcilePendingTonPaymentsForUser(userId: number): Promise<number>;
    private confirmTonPayment;
    handleStarsPayment(paymentId: number): Promise<void>;
    handleIPN(body: any, hmacHeader: string): Promise<void>;
    checkPaymentStatus(paymentId: number): Promise<{
        status: string;
        amountUsd: number;
    }>;
    /**
     * Credit a percentage-based bonus on the user's very first confirmed deposit.
     * The bonus equals `runtimeConfig.firstTopupBonusPercent`% of the deposited
     * amount (e.g. 100% → user deposits $5 and receives an extra +$5).
     * Atomic: only triggers if `firstDepositBonusGiven` is still false AND the
     * confirmed-payments-count equals 1 (i.e. the payment we just confirmed).
     */
    creditFirstDepositBonus(userId: number, justConfirmedPaymentId: number): Promise<void>;
    creditReferralBonus(user: {
        referredBy: bigint | null;
        telegramId: bigint;
    }, amountUsd: number, creditsGranted?: number): Promise<void>;
}
export declare const billingService: BillingService;
//# sourceMappingURL=billing.service.d.ts.map