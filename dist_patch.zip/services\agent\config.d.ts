export declare const BLOCKED_COMMANDS: string[];
export declare const BLOCKED_INFRA_SHELL_PATTERNS: RegExp[];
export declare const SKIP_DIRS: Set<string>;
export declare const SKIP_EXTS: Set<string>;
export declare const BINARY_EXTS: Set<string>;
export declare const READ_FILE_MAX_BYTES: number;
export declare const READ_FILE_SOFT_CAP_BYTES: number;
export declare const PASSPORT_REGEN_EVERY = 5;
//# sourceMappingURL=config.d.ts.map