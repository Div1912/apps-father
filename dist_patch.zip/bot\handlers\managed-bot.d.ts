import { Bot } from "grammy";
import { BotContext } from "../../types";
export declare function registerManagedBotHandlers(bot: Bot<BotContext>): void;
//# sourceMappingURL=managed-bot.d.ts.map