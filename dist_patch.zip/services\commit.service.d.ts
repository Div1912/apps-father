declare class CommitService {
    /**
     * Prepare a new commit folder for the agent to work in.
     * Copies latest commit (or development/) into commits/N+1/.
     */
    prepareCommitFolder(projectId: string): Promise<{
        commitDir: string;
        commitNum: number;
    }>;
    /**
     * Copy commit folder contents to development/ for live testing.
     */
    syncToDev(projectId: string, commitDir: string): void;
    /**
     * Finalize a commit: create DB record, copy agent log, sync to development/.
     */
    createCommit(projectId: string, message: string, commitNum: number, commitDir: string, logPath?: string): Promise<number>;
    /**
     * Release: copy development/ code to release/ (preserving release DB).
     */
    releaseCurrentDev(projectId: string): Promise<number>;
    /**
     * Revert: restore commits/N/ to development/, delete newer commits.
     */
    revertToCommit(projectId: string, commitNum: number): Promise<void>;
    getCommits(projectId: string): Promise<{
        projectId: string;
        id: number;
        createdAt: Date;
        version: string;
        changelog: string | null;
        snapshot: string | null;
    }[]>;
    getLogPath(projectId: string, commitNum: number): string | null;
    getDetailedLogPath(projectId: string, commitNum: number): string | null;
    /**
     * Migrate existing projects from old layout (root frontend/backend/data)
     * to new layout (development/, release/data/).
     */
    migrateExistingProjects(): Promise<number>;
}
export declare const commitService: CommitService;
export {};
//# sourceMappingURL=commit.service.d.ts.map