export declare const GAME_KIND_FEE_CREDITS = 100;
export declare const PREVIEW_UNLOCK_FEE_CREDITS = 20;
export declare const LINK_BOT_FEE_CREDITS = 15;
export type AgentSessionType = "router" | "answer" | "build" | "update" | "update-plan" | "bug-fix" | "suggestions" | "context" | "max-mode";
export interface AgentSessionConfig {
    model: string;
    provider?: string;
    max_tokens: number;
    reasoning: boolean;
    thinking: number;
    iterations: number;
}
/**
 * Complexity bucket emitted by the router's `propose_action` tool.
 * The router classifies how big the requested change is; the bucket selects
 * the credit price for that session type.
 */
export type AgentComplexity = "trivial" | "small" | "medium" | "large" | "huge";
export declare const AGENT_COMPLEXITIES: AgentComplexity[];
/** Session types that need a complexity-priced credit cost. */
export type PricedSessionType = "build" | "update" | "update-plan" | "bug-fix";
/**
 * Complexity-indexed credit price matrix.
 *
 * Layout (rows × columns):
 *   build              | trivial small medium large huge
 *   update             | trivial small medium large huge
 *   update-plan        | trivial small medium large huge   (base credits)
 *   update-plan-per-item| trivial small medium large huge  (per checklist item)
 *   bug-fix            | trivial small medium large huge
 *
 * Final cost = matrix[type][complexity]
 *   except update-plan: matrix["update-plan"][c] + planLen × matrix["update-plan-per-item"][c]
 */
export interface AgentComplexityPricing {
    build: Record<AgentComplexity, number>;
    update: Record<AgentComplexity, number>;
    "update-plan": Record<AgentComplexity, number>;
    "update-plan-per-item": Record<AgentComplexity, number>;
    "bug-fix": Record<AgentComplexity, number>;
}
export interface RuntimeConfig {
    creditsPerDollar: number;
    slotPriceCredits: number;
    minTopup: number;
    maxAgentIterations: number;
    firstTopupBonusPercent: number;
    referralBonusPercent: number;
    referralBonusUsd: number;
    partnerDefaultPercent: number;
    cashbackPercent: number;
    cashbackEnabled: boolean;
    aiAvatarPriceUsd: number;
    bundlePriceUsd: number;
    defaultLanguage: string;
    splashSecondsBeforeContinue: number;
    agentTimeoutMs: number;
    disableNewSignups: boolean;
    disableNewProjects: boolean;
    allowAdminShell: boolean;
    serviceMode: boolean;
    filesBrowserBaseUrl: string;
    filesBrowserProjectsRoot: string;
    openrouterApiKey: string;
    trainingOpenrouterApiKey: string;
    trainingModel: string;
    trainingProvider: string;
    appStore: {
        publishFeeTon: number;
        tradingFeePercent: number;
        creatorFeeShare: number;
        tokenTotalSupply: number;
        initialLiquidityTon: number;
        initialLiquidityTokenShare: number;
        minInitialLiquidityTon: number;
        minInitialLiquidityTokenShare: number;
        curveSupplyShare: number;
        initialVirtualTon: number;
        minScreenshots: number;
        maxScreenshots: number;
        enabled: boolean;
    };
    agentSessions: Record<AgentSessionType, AgentSessionConfig>;
    agentPricing: AgentComplexityPricing;
    /**
     * Multiplier applied to the final credit price when the user enables MAX
     * MODE on a paid proposal. Authoritative on the server. Min 1 — anything
     * lower would let users pay less than the standard price by toggling.
     */
    maxModeMultiplier: number;
}
declare class RuntimeConfigService {
    private config;
    constructor();
    private load;
    private mergeSessionConfigs;
    private save;
    get(): RuntimeConfig;
    update(partial: Partial<RuntimeConfig>): void;
    getMinTopup(): number;
    getMaxAgentIterations(): number;
    getOpenRouterApiKey(): string;
    /** DEDICATED key for the agent-feedback analysis pipeline (no fallback). */
    getTrainingApiKey(): string;
    getTrainingModel(): string;
    getTrainingProvider(): string;
    isServiceMode(): boolean;
    getCreditsPerDollar(): number;
    /** Returns the full AgentSessionConfig for the given session type. */
    getSessionConfig(type: AgentSessionType): AgentSessionConfig;
    /**
     * Returns the credit cost for starting a session of this type and
     * complexity bucket. `complexity` defaults to "medium" if missing or
     * invalid, so callers in legacy code paths still get a price.
     *
     * For "update-plan" pass `planLength` to add the variable per-item cost.
     * Returns 0 for router / answer / suggestions / context.
     */
    getSessionCost(type: AgentSessionType, complexity?: AgentComplexity, planLength?: number): number;
    /** Returns the full complexity matrix (read-only copy). */
    getAgentPricing(): AgentComplexityPricing;
    getAllSessionConfigs(): Record<AgentSessionType, AgentSessionConfig>;
    /** Multiplier applied to the credit cost when MAX MODE is enabled. >= 1. */
    getMaxModeMultiplier(): number;
    /**
     * Resolve the effective session config for an agent run.
     *  - When `maxMode` is true we bypass the per-type config entirely and use
     *    the dedicated `max-mode` slot — admins set its model/tokens/iterations
     *    independent of the base type.
     *  - Without max mode this is identical to `getSessionConfig(type)`.
     */
    getEffectiveSessionConfig(type: AgentSessionType, maxMode: boolean): AgentSessionConfig;
}
export declare const runtimeConfig: RuntimeConfigService;
export {};
//# sourceMappingURL=runtime-config.service.d.ts.map