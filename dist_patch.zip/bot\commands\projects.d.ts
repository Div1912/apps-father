import { BotContext } from "../../types";
export declare function projectsCommand(ctx: BotContext): Promise<void>;
//# sourceMappingURL=projects.d.ts.map