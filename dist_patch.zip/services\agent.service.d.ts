/**
 * Low-level agent executor with a fluent builder interface.
 *
 * Responsibilities:
 *   - Read session config from runtimeConfig (model, tokens, iterations, thinking)
 *   - Accept system prompt, messages, tools, and optional RunContext
 *   - Route execution to the appropriate runner (AgentRunner / AskRunner / RouterRunner)
 *
 * Does NOT orchestrate sessions, build prompts, log to DB, or broadcast WebSocket events.
 * Use agent-session.service.ts for full session orchestration.
 */
import { type AgentSessionType } from "./runtime-config.service";
import type { RunContext } from "./agent/RunContext";
import type { AskContext } from "./agent/tools/impl/ask/AskContext";
import type { RouterContext } from "./agent/tools/impl/router/RouterContext";
import type { AgentTool } from "./agent/AgentTool";
import type { ToolStepKind } from "./agent/AgentTool";
export type AgentStepKind = ToolStepKind;
export type AgentEventType = "step_start" | "step_end" | "narration_start" | "narration_chunk" | "narration_end" | "writing_chunk";
export interface AgentProgress {
    action: string;
    detail: string;
    percent?: number;
    costUsd?: number;
    balance?: number;
    event?: AgentEventType;
    stepId?: string;
    kind?: AgentStepKind;
    toolName?: string;
    title?: string;
    target?: {
        file?: string;
        range?: string;
        url?: string;
        key?: string;
    };
    status?: "ok" | "error";
    meta?: Record<string, any>;
    delta?: string;
    text?: string;
}
export interface AgentResult {
    summary: string;
    shortSummary: string;
    /**
     * Short agent-authored delta describing architectural changes this commit.
     * Populated when agent calls finish(context_diff=...). Used by append-passport path.
     */
    contextDiff?: string;
    model: string;
    inputTokens: number;
    outputTokens: number;
    cacheWriteTokens: number;
    cacheReadTokens: number;
    /**
     * Authoritative USD cost for the whole agent run, summed from each
     * iteration's OpenRouter `usage.cost`. Preferred over token×catalog
     * estimates when present. Zero when the upstream model didn't return cost.
     */
    costUsd?: number;
    /** Input portion of costUsd (sum of upstream_inference_prompt_cost). */
    costUsdInput?: number;
    /** Output portion of costUsd (sum of upstream_inference_completions_cost). */
    costUsdOutput?: number;
    logPath?: string;
    commitNum?: number;
    commitDir?: string;
    stepCount?: number;
    durationMs?: number;
}
export declare class AgentAbortedError extends Error {
    inputTokens: number;
    outputTokens: number;
    cacheWriteTokens: number;
    cacheReadTokens: number;
    model: string;
    constructor(model: string, inputTokens: number, outputTokens: number, cacheWriteTokens: number, cacheReadTokens: number);
}
/**
 * Fluent builder for a single LLM agent invocation.
 *
 * Usage:
 *   const result = await new Agent("build")
 *     .setSystemPrompt(sp)
 *     .setMessages(msgs)
 *     .setTools(AGENT_TOOL_INSTANCES)
 *     .setRawTools(SERVER_TOOLS)
 *     .setContext(ctx)
 *     .executeAsAgent();
 */
export declare class Agent {
    private readonly _sessionType;
    private _cfg;
    private _systemPrompt;
    private _messages;
    private _tools;
    private _rawTools;
    private _runContext?;
    constructor(sessionType: AgentSessionType);
    setModel(model: string): this;
    setMaxTokens(n: number): this;
    setIterations(n: number): this;
    setThinking(budget: number): this;
    setSystemPrompt(sp: string): this;
    setMessages(msgs: any[]): this;
    setTools(tools: AgentTool[]): this;
    setRawTools(tools: any[]): this;
    setContext(ctx: RunContext): this;
    /**
     * Full agentic run with tool loop. Requires setContext() first.
     */
    executeAsAgent(): Promise<AgentResult | null>;
    /**
     * Lightweight ask/answer run with streaming text output.
     */
    executeAsAsker(opts: {
        onChunk: (delta: string, full: string) => void;
        ctx: AskContext;
        telegramId?: string;
        sessionId?: string;
    }): Promise<{
        text: string;
        inputTokens: number;
        outputTokens: number;
        costUsd: number;
        costUsdInput: number;
        costUsdOutput: number;
    }>;
    /**
     * Router classification run. Returns proposal status and free-form text.
     */
    executeAsRouter(ctx: RouterContext, opts?: {
        telegramId?: string;
        sessionId?: string;
        onToolCall?: (toolName: string) => void;
    }): Promise<{
        proposed: boolean;
        text: string;
        inputTokens: number;
        outputTokens: number;
        costUsd: number;
        costUsdInput: number;
        costUsdOutput: number;
    }>;
    private _buildModelCfg;
}
/** Convenience factory — mirrors `new Agent(sessionType)`. */
export declare function createAgent(sessionType: AgentSessionType): Agent;
//# sourceMappingURL=agent.service.d.ts.map