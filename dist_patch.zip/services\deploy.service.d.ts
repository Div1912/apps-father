import { GeneratedApp } from "../types";
export declare class DeployService {
    deployProject(projectId: string, app: GeneratedApp, onProgress?: (msg: string) => Promise<void>): Promise<string>;
    private configureManagedBot;
}
export declare const deployService: DeployService;
//# sourceMappingURL=deploy.service.d.ts.map