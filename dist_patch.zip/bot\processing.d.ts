export declare const processingProjects: Set<string>;
export declare const abortedProjects: Set<string>;
//# sourceMappingURL=processing.d.ts.map