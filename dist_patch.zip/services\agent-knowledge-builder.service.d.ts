export interface SessionPrompts {
    systemPrompt: string;
    userPrompt: string;
}
export declare function loadLatestContext(projectId: string): string | null;
export declare function loadAskPlatformOverview(): string;
export declare function getDbSummary(projectId: string): string | null;
export declare function buildFeatureGating(projectId: string): Promise<string>;
export declare function walkDirWithStats(dir: string, base: string): string[];
export declare function gatherProjectInfo(projectDir: string): {
    fileTree: string;
    dbKeys: string;
    npmPackages: string;
};
export declare function extractRecentChanges(passport: string): string;
export declare function listProjectFiles(commitDir: string): string[];
export declare function buildFallbackSummary(projectDir: string, doneSummary: string): string;
export declare function resolveAskProjectDir(projectId: string): string | null;
export declare function session_router(projectId: string, args: {
    userMessage: string;
    lang?: string;
    conversationHistory?: {
        role: "user" | "assistant";
        content: string;
    }[];
}): Promise<{
    systemPrompt: string;
    messages: any[];
    isFirstMessage: boolean;
}>;
export declare function session_answer(projectId: string, args: {
    question: string;
    lastUpdate?: string;
    appDescription?: string;
    conversationHistory?: {
        role: "user" | "assistant";
        content: string;
    }[];
    lang?: string;
}): Promise<{
    systemPrompt: string;
    messages: any[];
}>;
export declare function session_suggestions(projectId: string, args: {
    lang?: string;
}): Promise<{
    userPrompt: string;
}>;
export declare function session_build(projectId: string, args: {
    name?: string;
    description?: string;
    brief?: string;
    userPrompt?: string;
    lang?: string;
    hasAttachments?: boolean;
}): Promise<{
    userPrompt: string;
}>;
export declare function session_update(projectId: string, args: {
    updateDescription: string;
    lang?: string;
    attachments?: {
        localPath: string;
        projectPath: string;
        originalName: string;
        caption?: string;
    }[];
}): Promise<{
    userPrompt: string;
}>;
export declare function session_context(projectId: string, args: {
    commitDir: string;
    commitNum: number;
    description?: string;
    doneSummary?: string;
    prevPassport?: string;
}): Promise<{
    inputText: string;
}>;
//# sourceMappingURL=agent-knowledge-builder.service.d.ts.map