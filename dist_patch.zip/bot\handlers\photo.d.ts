import { Bot } from "grammy";
import { BotContext } from "../../types";
export declare function registerPhotoHandlers(_bot: Bot<BotContext>): void;
//# sourceMappingURL=photo.d.ts.map