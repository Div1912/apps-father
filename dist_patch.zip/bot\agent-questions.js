"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setPending = setPending;
exports.resolveByProject = resolveByProject;
exports.resolveByChat = resolveByChat;
exports.hasPendingForChat = hasPendingForChat;
exports.getPendingByProject = getPendingByProject;
const pendingByProject = new Map();
const pendingByChat = new Map();
const MIN_ANSWER_DELAY_MS = 3000;
function setPending(projectId, chatId, options, resolve) {
    const q = { resolve, projectId, chatId, options, createdAt: Date.now() };
    pendingByProject.set(projectId, q);
    pendingByChat.set(chatId, q);
}
function resolveByProject(projectId, answer) {
    const q = pendingByProject.get(projectId);
    if (!q)
        return false;
    pendingByProject.delete(projectId);
    pendingByChat.delete(q.chatId);
    q.resolve(answer);
    return true;
}
function resolveByChat(chatId, answer, messageDate) {
    const q = pendingByChat.get(chatId);
    if (!q)
        return false;
    if (messageDate !== undefined) {
        const msgTimeMs = messageDate * 1000;
        if (msgTimeMs < q.createdAt + MIN_ANSWER_DELAY_MS) {
            return false;
        }
    }
    else {
        if (Date.now() - q.createdAt < MIN_ANSWER_DELAY_MS) {
            return false;
        }
    }
    pendingByProject.delete(q.projectId);
    pendingByChat.delete(chatId);
    q.resolve(answer);
    return true;
}
function hasPendingForChat(chatId) {
    const q = pendingByChat.get(chatId);
    if (!q)
        return false;
    if (Date.now() - q.createdAt < MIN_ANSWER_DELAY_MS)
        return false;
    return true;
}
function getPendingByProject(projectId) {
    return pendingByProject.get(projectId);
}
//# sourceMappingURL=agent-questions.js.map