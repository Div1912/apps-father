export interface PaidFeature {
    id: string;
    label: string;
    price: number;
    creditsPrice: number;
    description: string;
}
export declare const PAID_FEATURES: PaidFeature[];
export declare const BUNDLE_FEATURES: string[];
export declare const BUNDLE_PRICE = 50;
export declare const BUNDLE_CREDITS_PRICE = 2000;
export declare function getBundleFullPrice(): number;
export declare function getBundleFullCreditsPrice(): number;
/**
 * Quote the bundle for a given owned-features list.
 *
 * Behaviour:
 *  - If everything in BUNDLE_FEATURES is already owned → not available.
 *  - Otherwise the bundle covers only the still-missing features at a flat
 *    50% discount of their regular total. This way the offer keeps making
 *    sense even after the user bought one or two features individually
 *    (it's always a strictly better deal than buying the rest one by one).
 *  - When the bundle covers the full set we keep the headline price at the
 *    canonical $50 (in case rounding ever drifts), so the marketing
 *    "Get Everything for $50, save $50" still holds.
 */
export declare function getBundleQuote(owned: string[]): {
    missingIds: string[];
    fullPrice: number;
    bundlePrice: number;
    saveAmount: number;
    fullCreditsPrice: number;
    bundleCreditsPrice: number;
    saveCredits: number;
    available: boolean;
};
export declare function getFeatureById(featureId: string): PaidFeature | undefined;
export declare function getProjectFeatures(projectId: string): Promise<string[]>;
export declare function hasFeature(projectId: string, featureId: string): Promise<boolean>;
export declare function purchaseFeature(userId: number, projectId: string, featureId: string, payWith?: "credits" | "balance"): Promise<{
    newBalance: number;
    newCredits?: number;
}>;
/**
 * Purchase the "Get Everything" bundle.
 *
 * Rules:
 *  - The bundle stays available until ALL bundle features are owned.
 *  - When some features are already owned, the bundle covers only the missing
 *    ones at the 50%-off price returned by getBundleQuote().
 *  - All missing BUNDLE_FEATURES are granted atomically; previously-owned
 *    features are kept untouched.
 */
export declare function purchaseBundle(userId: number, projectId: string, payWith?: "credits" | "balance"): Promise<{
    newBalance: number;
    newCredits?: number;
    granted: string[];
    charged: number;
}>;
//# sourceMappingURL=features.service.d.ts.map