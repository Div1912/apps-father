import { InlineKeyboard } from "grammy";
import { BotContext } from "../../types";
import { Lang } from "../i18n";
export declare function getWelcomeCaption(lang: Lang): string;
export declare function buildMiniAppUrl(startParam?: string | null): string;
export declare function buildWelcomeKeyboard(lang: Lang, startParam?: string | null): InlineKeyboard;
export declare function getNavWelcomeText(balance: number, lang?: Lang): string;
export declare function startCommand(ctx: BotContext): Promise<void>;
//# sourceMappingURL=start.d.ts.map