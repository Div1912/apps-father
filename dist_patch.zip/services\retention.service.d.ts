export declare function processRetentionTick(): Promise<void>;
export declare function startRetentionScheduler(): void;
export declare function stopRetentionScheduler(): void;
//# sourceMappingURL=retention.service.d.ts.map