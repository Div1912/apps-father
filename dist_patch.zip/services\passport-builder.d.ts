export interface BuildPassportOpts {
    projectName?: string;
    description?: string;
    commitDir: string;
    commitNum: number;
    doneSummary?: string;
    keyDecisions?: string[];
    prevPassport?: string;
}
export interface BuiltPassport {
    passportText: string;
    history: string;
    combined: string;
}
export declare class PassportBuilder {
    build(opts: BuildPassportOpts): BuiltPassport;
    private extractRoutes;
    private extractWebSocketEvents;
    private extractScreens;
    private extractCssVariables;
    private extractCodeLocations;
    private buildFileTree;
    private readNpmPackages;
    private readDbKeys;
    private mergeDecisions;
    private extractDecisionsFromPrev;
    private buildHistory;
    private extractHistoryFromPrev;
    private safeRead;
    private guessAppName;
    private fmtBytes;
}
export declare const passportBuilder: PassportBuilder;
//# sourceMappingURL=passport-builder.d.ts.map