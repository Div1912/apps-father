import type { AskTool } from "./AskTool";
import type { AskContext } from "./AskContext";
export declare class PlatformHelpAskTool implements AskTool {
    name: string;
    definition: {
        type: string;
        function: {
            name: string;
            description: string;
            parameters: {
                type: string;
                properties: {
                    topic: {
                        type: string;
                        description: string;
                    };
                };
                additionalProperties: boolean;
            };
        };
    };
    execute(args: Record<string, any>, _ctx: AskContext): Promise<string>;
    private _loadOverview;
}
//# sourceMappingURL=PlatformHelpAskTool.d.ts.map