"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const express_2 = __importDefault(require("express"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const crypto_1 = __importDefault(require("crypto"));
const db_1 = require("../../db");
const config_1 = require("../../config");
const runtime_config_service_1 = require("../../services/runtime-config.service");
const library_1 = require("@prisma/client/runtime/library");
const admin_queries_service_1 = require("../../services/admin-queries.service");
const commit_service_1 = require("../../services/commit.service");
const chat_service_1 = require("../../services/chat.service");
const logs_routes_1 = require("./logs.routes");
const crypto_service_1 = require("../../services/crypto.service");
const features_service_1 = require("../../services/features.service");
const child_process_1 = require("child_process");
const router = (0, express_1.Router)();
const PROJECTS_DIR = path_1.default.join(process.cwd(), "projects");
// Project root (resolves correctly whether running from src/ via ts-node or
// from compiled dist/web/routes — both end up two `..` away from project root).
const ADMIN_DIR = path_1.default.join(__dirname, "..", "..", "..", "admin");
const activeTokens = new Set();
function generateToken() {
    const token = crypto_1.default.randomBytes(32).toString("hex");
    activeTokens.add(token);
    return token;
}
function authMiddleware(req, res, next) {
    // Accept the token from either an Authorization header (preferred — used by
    // the SPA's fetch calls) or a `?token=` query string (needed for plain
    // anchor downloads such as /admin/api/projects/:id/download.zip).
    const headerToken = req.headers.authorization?.replace("Bearer ", "");
    const queryToken = typeof req.query.token === "string" ? req.query.token : undefined;
    const token = headerToken || queryToken;
    if (!token || !activeTokens.has(token)) {
        res.status(401).json({ error: "Unauthorized" });
        return;
    }
    next();
}
// --- Auth ---
router.post("/api/login", (req, res) => {
    const { password } = req.body;
    if (password !== config_1.config.adminPassword) {
        res.status(401).json({ error: "Invalid password" });
        return;
    }
    const token = generateToken();
    res.json({ token });
});
// All API routes below require auth
router.use("/api", authMiddleware);
// --- Dashboard Stats ---
router.get("/api/stats", async (req, res) => {
    try {
        const from = parseIsoQuery(req.query.from);
        const to = parseIsoQuery(req.query.to);
        // Build a `createdAt` filter that we can reuse for everything below.
        const createdAtFilter = {};
        if (from)
            createdAtFilter.gte = from;
        if (to)
            createdAtFilter.lte = to;
        const dateWhere = (from || to) ? { createdAt: createdAtFilter } : {};
        const [userCount, projectCount, totalSpent, totalTopups, paymentCount] = await Promise.all([
            db_1.prisma.user.count({ where: dateWhere }),
            db_1.prisma.project.count({ where: dateWhere }),
            db_1.prisma.usageLog.aggregate({ _sum: { costUsd: true }, where: dateWhere }),
            db_1.prisma.payment.aggregate({
                _sum: { amountUsd: true },
                where: { status: "confirmed", ...dateWhere },
            }),
            db_1.prisma.payment.count({ where: { status: "confirmed", ...dateWhere } }),
        ]);
        // Recent activity always shows the latest 20 — date range applies to KPIs
        // only, like a typical analytics dashboard.
        const recentUsage = await db_1.prisma.usageLog.findMany({
            orderBy: { createdAt: "desc" },
            take: 20,
            where: (from || to) ? { createdAt: createdAtFilter } : undefined,
            include: { user: { select: { username: true, firstName: true } }, project: { select: { name: true } } },
        });
        res.json({
            from: from ? from.toISOString() : null,
            to: to ? to.toISOString() : null,
            userCount,
            projectCount,
            totalSpent: Number(totalSpent._sum.costUsd || 0),
            totalTopups: Number(totalTopups._sum.amountUsd || 0),
            paymentCount,
            recentUsage: recentUsage.map(u => ({
                id: u.id,
                username: u.user.username || u.user.firstName || `User ${u.userId}`,
                project: u.project?.name || "-",
                operation: u.operation,
                inputTokens: u.inputTokens,
                outputTokens: u.outputTokens,
                cost: Number(u.costUsd),
                createdAt: u.createdAt,
            })),
        });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// --- Users ---
// All user endpoints are backed by src/services/admin-queries.service.ts so
// the legacy Mini-App admin and the new browser CRM share identical logic.
router.get("/api/users", async (req, res) => {
    try {
        const result = await (0, admin_queries_service_1.listUsers)({
            q: typeof req.query.q === "string" ? req.query.q : undefined,
            filter: req.query.filter,
            sort: req.query.sort,
            page: req.query.page ? parseInt(String(req.query.page), 10) : undefined,
            pageSize: req.query.pageSize ? parseInt(String(req.query.pageSize), 10) : undefined,
        });
        res.json(result);
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.get("/api/users/:id", async (req, res) => {
    try {
        const userId = parseInt(req.params.id, 10);
        const user = await (0, admin_queries_service_1.getUserDetail)(userId);
        if (!user) {
            res.status(404).json({ error: "User not found" });
            return;
        }
        res.json(user);
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.patch("/api/users/:id", async (req, res) => {
    try {
        const userId = parseInt(req.params.id, 10);
        const updated = await (0, admin_queries_service_1.patchUser)(userId, req.body || {});
        res.json(updated);
    }
    catch (err) {
        res.status(400).json({ error: err.message });
    }
});
router.post("/api/users/:id/balance", async (req, res) => {
    try {
        const userId = parseInt(req.params.id, 10);
        const action = req.body?.action;
        const amount = parseFloat(req.body?.amount);
        if (action !== "set" && action !== "add") {
            res.status(400).json({ error: "action must be 'set' or 'add'" });
            return;
        }
        const result = await (0, admin_queries_service_1.setUserBalance)(userId, action, amount);
        res.json(result);
    }
    catch (err) {
        res.status(400).json({ error: err.message });
    }
});
router.post("/api/users/:id/credits", async (req, res) => {
    try {
        const userId = parseInt(req.params.id, 10);
        const action = req.body?.action;
        const credits = parseFloat(req.body?.credits);
        if (action !== "set" && action !== "add") {
            res.status(400).json({ error: "action must be 'set' or 'add'" });
            return;
        }
        const result = await (0, admin_queries_service_1.setUserCredits)(userId, action, credits);
        res.json(result);
    }
    catch (err) {
        res.status(400).json({ error: err.message });
    }
});
router.post("/api/users/:id/partner", async (req, res) => {
    try {
        const userId = parseInt(req.params.id, 10);
        const result = await (0, admin_queries_service_1.updateUserPartner)(userId, req.body || {});
        res.json(result);
    }
    catch (err) {
        res.status(400).json({ error: err.message });
    }
});
router.post("/api/users/:id/tags", async (req, res) => {
    try {
        const userId = parseInt(req.params.id, 10);
        const tags = Array.isArray(req.body?.tags) ? req.body.tags : [];
        const result = await (0, admin_queries_service_1.setUserTags)(userId, tags);
        res.json(result);
    }
    catch (err) {
        res.status(400).json({ error: err.message });
    }
});
router.get("/api/users/:id/notes", async (req, res) => {
    try {
        const userId = parseInt(req.params.id, 10);
        res.json({ notes: await (0, admin_queries_service_1.listUserNotes)(userId) });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.post("/api/users/:id/notes", async (req, res) => {
    try {
        const userId = parseInt(req.params.id, 10);
        const note = await (0, admin_queries_service_1.addUserNote)(userId, req.body?.body || "", req.body?.authorTag);
        res.json(note);
    }
    catch (err) {
        res.status(400).json({ error: err.message });
    }
});
router.delete("/api/users/:id/notes/:noteId", async (req, res) => {
    try {
        const userId = parseInt(req.params.id, 10);
        const noteId = parseInt(req.params.noteId, 10);
        await (0, admin_queries_service_1.deleteUserNote)(userId, noteId);
        res.json({ ok: true });
    }
    catch (err) {
        res.status(400).json({ error: err.message });
    }
});
router.delete("/api/users/:id/data", async (req, res) => {
    try {
        const userId = parseInt(req.params.id, 10);
        const deleted = await (0, admin_queries_service_1.wipeUserData)(userId);
        console.log(`[Admin CRM] Wiped data for user ${userId}:`, deleted);
        res.json({ ok: true, deleted });
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.delete("/api/users/:id/full", async (req, res) => {
    try {
        const userId = parseInt(req.params.id, 10);
        const deleted = await (0, admin_queries_service_1.fullResetUser)(userId);
        console.log(`[Admin CRM] Full reset for user ${userId}:`, deleted);
        res.json({ ok: true, deleted });
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
// --- Projects ---
router.get("/api/projects", async (req, res) => {
    try {
        const result = await (0, admin_queries_service_1.listProjects)({
            q: typeof req.query.q === "string" ? req.query.q : undefined,
            filter: req.query.filter,
            sort: req.query.sort,
            page: req.query.page ? parseInt(String(req.query.page), 10) : undefined,
            pageSize: req.query.pageSize ? parseInt(String(req.query.pageSize), 10) : undefined,
        });
        res.json(result);
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.get("/api/projects/:id", async (req, res) => {
    try {
        const project = await (0, admin_queries_service_1.getProjectDetail)(req.params.id);
        if (!project) {
            res.status(404).json({ error: "Not found" });
            return;
        }
        res.json(project);
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.patch("/api/projects/:id", async (req, res) => {
    try {
        const updated = await (0, admin_queries_service_1.patchProject)(req.params.id, req.body || {});
        res.json(updated);
    }
    catch (err) {
        res.status(400).json({ error: err.message });
    }
});
// The PAID_FEATURES catalog (id, label, price, description) so the App
// detail page can render its Features sub-tab as a true checklist instead
// of the raw JSON blob that the Settings tab still exposes for power users.
router.get("/api/features-catalog", (_req, res) => {
    res.json({ features: features_service_1.PAID_FEATURES });
});
router.get("/api/projects/:id/files", (req, res) => {
    const projectId = req.params.id;
    const devDir = path_1.default.join(PROJECTS_DIR, projectId, "development");
    if (!fs_1.default.existsSync(devDir)) {
        res.json({ files: [] });
        return;
    }
    res.json({ files: walkDir(devDir, devDir) });
});
router.get("/api/projects/:id/file", (req, res) => {
    const projectId = req.params.id;
    const filePath = String(req.query.path || "");
    if (!filePath || filePath.includes("..")) {
        res.status(400).json({ error: "Invalid path" });
        return;
    }
    const devDir = path_1.default.join(PROJECTS_DIR, projectId, "development");
    const fullPath = path_1.default.join(devDir, filePath);
    if (!fullPath.startsWith(devDir)) {
        res.status(403).json({ error: "Forbidden" });
        return;
    }
    if (!fs_1.default.existsSync(fullPath)) {
        res.status(404).json({ error: "Not found" });
        return;
    }
    // Block obvious binaries; cap response to ~1MB.
    const stat = fs_1.default.statSync(fullPath);
    if (stat.size > 1_000_000) {
        res.status(413).json({ error: "File too large to view in browser (>1MB)" });
        return;
    }
    const buf = fs_1.default.readFileSync(fullPath);
    // Heuristic: if NUL byte appears in first 4KB, treat as binary.
    if (buf.subarray(0, Math.min(4096, buf.length)).includes(0)) {
        res.json({ content: "[binary file omitted]", binary: true, size: stat.size });
        return;
    }
    res.json({ content: buf.toString("utf-8"), size: stat.size });
});
router.get("/api/projects/:id/reveal", (req, res) => {
    const projectId = req.params.id;
    const projectDir = path_1.default.join(PROJECTS_DIR, projectId);
    const devDir = path_1.default.join(projectDir, "development");
    res.json({
        projectDir,
        developmentDir: fs_1.default.existsSync(devDir) ? devDir : null,
    });
});
router.post("/api/projects/:id/status", async (req, res) => {
    try {
        const projectId = req.params.id;
        const { status } = req.body;
        await db_1.prisma.project.update({ where: { id: projectId }, data: { status } });
        res.json({ ok: true });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// --- Project chat (read-only history + admin system note) -------------------
router.get("/api/projects/:id/chat", (req, res) => {
    try {
        const projectId = req.params.id;
        const before = req.query.before ? Number(req.query.before) : undefined;
        const limit = req.query.limit ? Number(req.query.limit) : 100;
        const messages = chat_service_1.chatService.getHistory(projectId, before, limit);
        res.json({ messages });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.post("/api/projects/:id/chat/send", (req, res) => {
    try {
        const projectId = req.params.id;
        const text = String(req.body?.text || "").trim();
        if (!text) {
            res.status(400).json({ error: "Empty message" });
            return;
        }
        // Admin-side messages are appended as a system note so the project owner
        // sees them in their chat. Triggering a full agent run is out of scope
        // for the read-only CRM viewer.
        const msg = chat_service_1.chatService.addMessage(projectId, {
            role: "system",
            type: "text",
            content: `[Admin] ${text}`,
        });
        res.json({ message: msg });
    }
    catch (err) {
        res.status(400).json({ error: err.message });
    }
});
// --- Project commits / logs -------------------------------------------------
router.get("/api/projects/:id/logs", async (req, res) => {
    try {
        const projectId = req.params.id;
        const versions = await commit_service_1.commitService.getCommits(projectId);
        const commitsRoot = path_1.default.join(PROJECTS_DIR, projectId, "commits");
        const items = versions.map((v) => {
            const num = Number(v.version);
            let sizeBytes = 0;
            const logFile = path_1.default.join(commitsRoot, String(num), "agent.log");
            if (fs_1.default.existsSync(logFile)) {
                try {
                    sizeBytes = fs_1.default.statSync(logFile).size;
                }
                catch { }
            }
            return {
                commit: num,
                version: v.version,
                changelog: v.changelog,
                createdAt: v.createdAt,
                sizeBytes,
                hasLog: sizeBytes > 0,
            };
        });
        res.json({ commits: items });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.get("/api/projects/:id/logs/:commit", (req, res) => {
    try {
        const projectId = req.params.id;
        const commitNum = parseInt(req.params.commit, 10);
        if (!Number.isFinite(commitNum)) {
            res.status(400).json({ error: "Invalid commit" });
            return;
        }
        const logPath = commit_service_1.commitService.getLogPath(projectId, commitNum);
        if (!logPath) {
            res.status(404).json({ error: "No log for that commit" });
            return;
        }
        const stat = fs_1.default.statSync(logPath);
        if (stat.size > 5_000_000) {
            // Tail the last 5MB if huge
            const fd = fs_1.default.openSync(logPath, "r");
            const buf = Buffer.alloc(5_000_000);
            fs_1.default.readSync(fd, buf, 0, 5_000_000, stat.size - 5_000_000);
            fs_1.default.closeSync(fd);
            res.json({
                truncated: true,
                size: stat.size,
                entries: parseLogText(buf.toString("utf-8")),
            });
            return;
        }
        const text = fs_1.default.readFileSync(logPath, "utf-8");
        res.json({ size: stat.size, entries: parseLogText(text) });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
function parseLogText(text) {
    const out = [];
    for (const line of text.split(/\r?\n/)) {
        const trimmed = line.trim();
        if (!trimmed)
            continue;
        try {
            out.push(JSON.parse(trimmed));
        }
        catch {
            out.push({ raw: trimmed });
        }
    }
    return out;
}
// --- Sources / Funnel ---
function parseIsoQuery(raw) {
    if (typeof raw !== "string" || !raw)
        return null;
    const d = new Date(raw);
    return isNaN(d.getTime()) ? null : d;
}
router.get("/api/stats/sources", async (req, res) => {
    try {
        const result = await (0, admin_queries_service_1.getSourcesStats)({
            from: parseIsoQuery(req.query.from),
            to: parseIsoQuery(req.query.to),
            // Avatar resolution intentionally skipped here — the browser CRM
            // renders gradient initials for partners/referrers (cheap & offline).
        });
        res.json(result);
    }
    catch (err) {
        console.error("[Admin CRM] Sources stats error:", err);
        res.status(500).json({ error: err.message });
    }
});
function parseAppLogQuery(req) {
    const q = {
        limit: Math.max(10, Math.min(2000, parseInt(String(req.query.limit ?? "300"), 10) || 300)),
    };
    const projectId = typeof req.query.projectId === "string" ? req.query.projectId.trim() : "";
    if (projectId) {
        if (projectId === "__system__")
            q.projectId = "__system__"; // sentinel
        else
            q.projectId = projectId;
    }
    const cat = typeof req.query.category === "string" ? req.query.category.trim() : "";
    if (cat && cat !== "all")
        q.category = cat;
    const lvl = typeof req.query.level === "string" ? req.query.level.trim() : "";
    if (lvl && lvl !== "all")
        q.level = lvl;
    const src = typeof req.query.source === "string" ? req.query.source.trim() : "";
    if (src && src !== "all")
        q.source = src;
    const text = typeof req.query.q === "string" ? req.query.q.trim() : "";
    if (text)
        q.q = text.slice(0, 200);
    const from = typeof req.query.from === "string" ? req.query.from : "";
    if (from) {
        const d = new Date(from);
        if (!isNaN(d.getTime()))
            q.from = d;
    }
    const to = typeof req.query.to === "string" ? req.query.to : "";
    if (to) {
        const d = new Date(to);
        if (!isNaN(d.getTime()))
            q.to = d;
    }
    const beforeId = typeof req.query.beforeId === "string" ? req.query.beforeId : "";
    if (beforeId && /^\d+$/.test(beforeId)) {
        try {
            q.beforeId = BigInt(beforeId);
        }
        catch { /* ignore */ }
    }
    return q;
}
function buildAppLogWhere(q) {
    const where = {};
    if (q.projectId === "__system__")
        where.projectId = null;
    else if (q.projectId)
        where.projectId = q.projectId;
    if (q.category)
        where.category = q.category;
    if (q.level)
        where.level = q.level;
    if (q.source)
        where.source = q.source;
    if (q.q)
        where.message = { contains: q.q, mode: "insensitive" };
    if (q.from || q.to) {
        where.ts = {};
        if (q.from)
            where.ts.gte = q.from;
        if (q.to)
            where.ts.lte = q.to;
    }
    if (q.beforeId) {
        where.id = { lt: q.beforeId };
    }
    return where;
}
router.get("/api/applogs", async (req, res) => {
    try {
        const q = parseAppLogQuery(req);
        const where = buildAppLogWhere(q);
        const rows = await db_1.prisma.appLog.findMany({
            where,
            orderBy: { id: "desc" },
            take: q.limit,
        });
        // Send oldest → newest so the UI can append-and-stick-to-bottom naturally.
        rows.reverse();
        const nextCursor = rows.length > 0 ? rows[0].id.toString() : null;
        res.json({
            lines: rows.map(r => ({
                id: r.id.toString(),
                ts: r.ts,
                projectId: r.projectId,
                category: r.category,
                level: r.level,
                source: r.source,
                message: r.message,
            })),
            nextCursor, // pass back as `beforeId` to fetch the previous page (older)
            hasMore: rows.length === q.limit,
        });
    }
    catch (err) {
        console.error("[Admin CRM] AppLogs query error:", err);
        res.status(500).json({ error: err?.message || String(err) });
    }
});
// Distinct categories present in the table — used to populate the dropdown.
// Cached in-process for 30s so we don't hammer Postgres every refresh tick.
let categoriesCache = null;
router.get("/api/applogs/categories", async (_req, res) => {
    try {
        if (categoriesCache && Date.now() - categoriesCache.ts < 30_000) {
            res.json({ categories: categoriesCache.data });
            return;
        }
        const rows = await db_1.prisma.appLog.findMany({
            select: { category: true },
            distinct: ["category"],
            orderBy: { category: "asc" },
            take: 200,
        });
        const data = rows.map(r => r.category).filter(Boolean);
        categoriesCache = { ts: Date.now(), data };
        res.json({ categories: data });
    }
    catch (err) {
        res.status(500).json({ error: err?.message || String(err) });
    }
});
// Per-project shorthand: same query as /applogs but pins projectId.
router.get("/api/projects/:id/applogs", async (req, res) => {
    try {
        req.query.projectId = req.params.id;
        const q = parseAppLogQuery(req);
        const where = buildAppLogWhere(q);
        const rows = await db_1.prisma.appLog.findMany({
            where,
            orderBy: { id: "desc" },
            take: q.limit,
        });
        rows.reverse();
        const nextCursor = rows.length > 0 ? rows[0].id.toString() : null;
        res.json({
            lines: rows.map(r => ({
                id: r.id.toString(),
                ts: r.ts,
                projectId: r.projectId,
                category: r.category,
                level: r.level,
                source: r.source,
                message: r.message,
            })),
            nextCursor,
            hasMore: rows.length === q.limit,
        });
    }
    catch (err) {
        console.error("[Admin CRM] Project AppLogs query error:", err);
        res.status(500).json({ error: err?.message || String(err) });
    }
});
// --- Recent process logs (legacy PM2 tail; kept for backward compatibility) -
router.get("/api/logs/recent", (req, res) => {
    try {
        const source = String(req.query.source || "out");
        const lines = Math.max(50, Math.min(5000, parseInt(String(req.query.lines || "500"), 10) || 500));
        let filePath = "";
        if (source === "out")
            filePath = (0, logs_routes_1.getOutLog)();
        else if (source === "err")
            filePath = (0, logs_routes_1.getErrLog)();
        else {
            res.status(400).json({ error: "Unknown source: use out|err" });
            return;
        }
        if (!filePath) {
            res.json({ source, file: null, lines: [] });
            return;
        }
        const text = (0, logs_routes_1.readTailLines)(filePath, lines);
        let size = 0;
        try {
            size = fs_1.default.statSync(filePath).size;
        }
        catch { }
        res.json({ source, file: filePath, size, lines: text });
    }
    catch (err) {
        res.status(500).json({ error: err?.message || String(err) });
    }
});
// --- Avatar resolution (cached, talks to Telegram on miss) ------------------
//
// The Mini-App fetches avatars on the fly via the project's own bot token; the
// browser CRM uses these dedicated endpoints so we can:
//   • cache the URL for 30 minutes (avatars rotate rarely),
//   • cache misses too (so we don't hammer Telegram for users with no photo),
//   • use the master Apps-Father bot token as a fallback for plain Telegram
//     IDs that don't belong to any project bot.
const AVATAR_TTL_MS = 30 * 60 * 1000;
const avatarCache = new Map();
function getCachedAvatar(key) {
    const e = avatarCache.get(key);
    if (!e)
        return null;
    if (Date.now() - e.ts > AVATAR_TTL_MS) {
        avatarCache.delete(key);
        return null;
    }
    return e;
}
function setCachedAvatar(key, url) {
    avatarCache.set(key, { url, ts: Date.now() });
}
async function fetchTelegramAvatarUrl(botToken, telegramUserId) {
    try {
        const photosRes = await fetch(`https://api.telegram.org/bot${botToken}/getUserProfilePhotos?user_id=${telegramUserId}&limit=1`);
        const photosData = await photosRes.json();
        if (!photosData.ok || !photosData.result?.photos?.length)
            return null;
        const photo = photosData.result.photos[0];
        const biggest = photo[photo.length - 1];
        const fileId = biggest.file_id;
        const fileRes = await fetch(`https://api.telegram.org/bot${botToken}/getFile?file_id=${fileId}`);
        const fileData = await fileRes.json();
        if (!fileData.ok || !fileData.result?.file_path)
            return null;
        return `https://api.telegram.org/file/bot${botToken}/${fileData.result.file_path}`;
    }
    catch {
        return null;
    }
}
router.get("/api/avatar/project/:id", async (req, res) => {
    const projectId = req.params.id;
    const cacheKey = `project:${projectId}`;
    const cached = getCachedAvatar(cacheKey);
    if (cached) {
        res.json({ url: cached.url, cached: true });
        return;
    }
    try {
        const project = await db_1.prisma.project.findUnique({
            where: { id: projectId },
            select: { botUserId: true, botTokenEncrypted: true },
        });
        if (!project || !project.botTokenEncrypted || !project.botUserId) {
            setCachedAvatar(cacheKey, null);
            res.json({ url: null });
            return;
        }
        const token = (0, crypto_service_1.decryptToken)(project.botTokenEncrypted);
        const url = await fetchTelegramAvatarUrl(token, String(project.botUserId));
        setCachedAvatar(cacheKey, url);
        res.json({ url });
    }
    catch (err) {
        res.status(500).json({ url: null, error: err.message || String(err) });
    }
});
router.get("/api/avatar/user/:telegramId", async (req, res) => {
    const tgId = String(req.params.telegramId || "").trim();
    if (!tgId || !/^\d+$/.test(tgId)) {
        res.status(400).json({ error: "Invalid telegramId" });
        return;
    }
    const cacheKey = `user:${tgId}`;
    const cached = getCachedAvatar(cacheKey);
    if (cached) {
        res.json({ url: cached.url, cached: true });
        return;
    }
    try {
        if (!config_1.config.botToken) {
            res.json({ url: null });
            return;
        }
        const url = await fetchTelegramAvatarUrl(config_1.config.botToken, tgId);
        setCachedAvatar(cacheKey, url);
        res.json({ url });
    }
    catch (err) {
        res.status(500).json({ url: null, error: err.message || String(err) });
    }
});
// --- Reveal in explorer (gated) ---------------------------------------------
router.post("/api/projects/:id/open-in-explorer", (req, res) => {
    try {
        if (!runtime_config_service_1.runtimeConfig.get().allowAdminShell) {
            res.status(403).json({ error: "Admin shell is disabled. Enable allowAdminShell in Configuration." });
            return;
        }
        const projectId = req.params.id;
        const which = String(req.body?.dir || "project");
        const base = which === "development"
            ? path_1.default.join(PROJECTS_DIR, projectId, "development")
            : path_1.default.join(PROJECTS_DIR, projectId);
        if (!fs_1.default.existsSync(base)) {
            res.status(404).json({ error: "Directory does not exist" });
            return;
        }
        // Detect headless Linux (no DISPLAY) up front and bail with a useful
        // message — there's no way to open a GUI explorer on a remote PM2 server,
        // so the admin should download the folder as a zip instead.
        if (process.platform === "linux" && !process.env.DISPLAY) {
            res.status(409).json({
                error: "Server is headless (no DISPLAY). Use 'Download ZIP' to inspect files locally, or 'Copy path' if you're SSH'd into the server.",
                path: base,
                headless: true,
            });
            return;
        }
        const cmd = process.platform === "win32"
            ? `start "" "${base}"`
            : process.platform === "darwin"
                ? `open "${base}"`
                : `xdg-open "${base}"`;
        // Wait for the exec to finish so we can report the *real* outcome rather
        // than always claiming success. Cap the wait at 4s to keep the request
        // snappy.
        let answered = false;
        const timeout = setTimeout(() => {
            if (answered)
                return;
            answered = true;
            res.json({ ok: true, path: base, async: true });
        }, 4000);
        (0, child_process_1.exec)(cmd, { windowsHide: true, timeout: 5000 }, (err) => {
            if (answered)
                return;
            answered = true;
            clearTimeout(timeout);
            if (err) {
                console.error("[Admin CRM] open-in-explorer failed:", err.message);
                res.status(500).json({ error: `Open command failed: ${err.message}`, path: base });
                return;
            }
            res.json({ ok: true, path: base });
        });
    }
    catch (err) {
        res.status(500).json({ error: err?.message || String(err) });
    }
});
// Download the project's development folder as a streaming zip. Useful on
// headless Linux deployments where Open-in-Explorer can't pop a window.
router.get("/api/projects/:id/download.zip", async (req, res) => {
    try {
        const projectId = req.params.id;
        const which = String(req.query.dir || "development");
        const base = which === "development"
            ? path_1.default.join(PROJECTS_DIR, projectId, "development")
            : path_1.default.join(PROJECTS_DIR, projectId);
        if (!fs_1.default.existsSync(base)) {
            res.status(404).json({ error: "Directory does not exist" });
            return;
        }
        let archiver;
        try {
            archiver = require("archiver");
        }
        catch {
            res.status(500).json({ error: "archiver module not installed on server" });
            return;
        }
        const safeName = `${projectId.slice(0, 8)}-${which}.zip`;
        res.setHeader("Content-Type", "application/zip");
        res.setHeader("Content-Disposition", `attachment; filename="${safeName}"`);
        const archive = archiver("zip", { zlib: { level: 6 } });
        archive.on("warning", (err) => console.warn("[Admin CRM] zip warning:", err?.message || err));
        archive.on("error", (err) => { console.error("[Admin CRM] zip error:", err); try {
            res.end();
        }
        catch { } });
        archive.pipe(res);
        archive.glob("**/*", { cwd: base, dot: true, ignore: ["node_modules/**", ".git/**"] });
        await archive.finalize();
    }
    catch (err) {
        if (!res.headersSent)
            res.status(500).json({ error: err?.message || String(err) });
    }
});
router.get("/api/timeseries", async (req, res) => {
    try {
        const metric = String(req.query.metric || "new_users");
        const interval = String(req.query.interval || "day");
        const result = await (0, admin_queries_service_1.getTimeseries)({
            metric,
            interval,
            from: parseIsoQuery(req.query.from),
            to: parseIsoQuery(req.query.to),
        });
        res.json(result);
    }
    catch (err) {
        res.status(400).json({ error: err.message });
    }
});
// Cost & token breakdown grouped by `usage_logs.operation`. Backs the
// Dashboard's "Cost by operation" / "Tokens by operation" panels so admins
// can see at-a-glance which agent step is burning the most spend.
router.get("/api/stats/operations", async (req, res) => {
    try {
        const rows = await (0, admin_queries_service_1.getOperationBreakdown)({
            from: parseIsoQuery(req.query.from),
            to: parseIsoQuery(req.query.to),
        });
        res.json({
            from: parseIsoQuery(req.query.from)?.toISOString() || null,
            to: parseIsoQuery(req.query.to)?.toISOString() || null,
            rows,
        });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// ── Tier stats and config ──
router.get("/api/stats/tiers", async (req, res) => {
    try {
        const from = parseIsoQuery(req.query.from);
        const to = parseIsoQuery(req.query.to);
        const where = {};
        if (from || to) {
            where.createdAt = {};
            if (from)
                where.createdAt.gte = from;
            if (to)
                where.createdAt.lte = to;
        }
        const rows = await db_1.prisma.usageLog.groupBy({
            by: ["operation"],
            where,
            _count: { id: true },
            _sum: { creditsCharged: true, costUsd: true },
        });
        const operationStats = {};
        for (const row of rows) {
            operationStats[row.operation] = {
                count: row._count.id,
                creditsCharged: row._sum.creditsCharged || 0,
                costUsd: Number(row._sum.costUsd || 0),
            };
        }
        // Session stats from new agent_sessions table
        const sessionRows = await db_1.prisma.agentSession.groupBy({
            by: ["type"],
            _count: { id: true },
            _sum: { creditsCharged: true, costUsd: true },
        });
        const sessionStats = {};
        for (const row of sessionRows) {
            sessionStats[row.type] = {
                count: row._count.id,
                creditsCharged: row._sum.creditsCharged || 0,
                costUsd: Number(row._sum.costUsd || 0),
            };
        }
        const creditSummary = await db_1.prisma.user.aggregate({ _sum: { credits: true } });
        const usageSum = await db_1.prisma.usageLog.aggregate({ where, _sum: { creditsCharged: true, costUsd: true } });
        res.json({
            operations: operationStats,
            sessions: sessionStats,
            totalCreditsOutstanding: creditSummary._sum.credits || 0,
            totalCreditsSpent: usageSum._sum.creditsCharged || 0,
            totalRealCostUsd: Number(usageSum._sum.costUsd || 0),
            from: from?.toISOString() || null,
            to: to?.toISOString() || null,
        });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// ── Agent Sessions ────────────────────────────────────────────────────────────
// Returns usage_logs grouped by task_id so the admin can see per-run cost/revenue.
// Rows with task_id = NULL are skipped (non-agent operations like avatar_generation).
router.get("/api/sessions", async (req, res) => {
    try {
        const page = Math.max(1, parseInt(String(req.query.page || "1"), 10));
        const limit = Math.min(100, Math.max(1, parseInt(String(req.query.limit || "50"), 10)));
        const skip = (page - 1) * limit;
        const projectIdFilter = typeof req.query.projectId === "string" ? req.query.projectId : undefined;
        const userIdFilter = typeof req.query.userId === "string" ? parseInt(req.query.userId, 10) : undefined;
        // Raw query: aggregate per task_id
        const whereClauses = ["ul.task_id IS NOT NULL"];
        if (projectIdFilter)
            whereClauses.push(`ul.project_id = '${projectIdFilter.replace(/'/g, "''")}'`);
        if (userIdFilter)
            whereClauses.push(`ul.user_id = ${userIdFilter}`);
        const whereStr = whereClauses.join(" AND ");
        const rows = await db_1.prisma.$queryRawUnsafe(`
      SELECT
        ul.task_id          AS "taskId",
        ul.project_id       AS "projectId",
        ul.user_id          AS "userId",
        p.name              AS "projectName",
        MIN(ul.created_at)  AS "startedAt",
        SUM(ul.input_tokens)    AS "inputTokens",
        SUM(ul.output_tokens)   AS "outputTokens",
        SUM(ul.cost_usd)        AS "costUsd",
        SUM(ul.credits_charged) AS "creditsCharged",
        COUNT(*)                AS "callCount"
      FROM usage_logs ul
      LEFT JOIN projects p ON p.id = ul.project_id
      WHERE ${whereStr}
      GROUP BY ul.task_id, ul.project_id, ul.user_id, p.name
      ORDER BY MIN(ul.created_at) DESC
      LIMIT ${limit} OFFSET ${skip}
    `);
        const countResult = await db_1.prisma.$queryRawUnsafe(`
      SELECT COUNT(DISTINCT ul.task_id) AS total FROM usage_logs ul WHERE ${whereStr}
    `);
        const total = Number(countResult[0]?.total || 0);
        // Credits-to-dollar rate from runtime config (default 50 credits = $1).
        // Revenue in USD = credits / creditsPerDollar.
        const creditsPerDollar = runtime_config_service_1.runtimeConfig.getCreditsPerDollar() || 50;
        const sessions = rows.map((r) => {
            const costUsd = Number(r.costUsd || 0);
            const credits = Number(r.creditsCharged || 0);
            const revenueUsd = credits / creditsPerDollar;
            const marginUsd = revenueUsd - costUsd;
            return {
                taskId: r.taskId,
                projectId: r.projectId,
                projectName: r.projectName || "Unknown",
                userId: r.userId,
                startedAt: r.startedAt,
                inputTokens: Number(r.inputTokens || 0),
                outputTokens: Number(r.outputTokens || 0),
                costUsd: parseFloat(costUsd.toFixed(6)),
                creditsCharged: credits,
                revenueUsd: parseFloat(revenueUsd.toFixed(4)),
                marginUsd: parseFloat(marginUsd.toFixed(4)),
                callCount: Number(r.callCount || 0),
            };
        });
        res.json({ sessions, total, page, limit, creditsPerDollar });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// ── Agent Sessions Explorer (reads from agent_sessions table) ────────────────
// Returns per-session rows with type, model, duration, cost, credits, success.
router.get("/api/agent-sessions", async (req, res) => {
    try {
        const page = Math.max(1, parseInt(String(req.query.page || "1"), 10));
        const limit = Math.min(100, Math.max(1, parseInt(String(req.query.limit || "50"), 10)));
        const skip = (page - 1) * limit;
        const typeFilter = typeof req.query.type === "string" ? req.query.type : undefined;
        const projectIdFilter = typeof req.query.projectId === "string" ? req.query.projectId.trim() || undefined : undefined;
        const userIdFilter = typeof req.query.userId === "string" ? parseInt(req.query.userId, 10) : undefined;
        const successFilter = typeof req.query.success === "string" ? req.query.success === "true" : undefined;
        const fromDate = typeof req.query.from === "string" ? new Date(req.query.from) : undefined;
        const toDate = typeof req.query.to === "string" ? new Date(req.query.to) : undefined;
        const where = {};
        if (typeFilter)
            where.type = typeFilter;
        if (projectIdFilter)
            where.projectId = projectIdFilter;
        if (!isNaN(userIdFilter))
            where.userId = userIdFilter;
        if (successFilter !== undefined)
            where.success = successFilter;
        if (fromDate || toDate) {
            where.createdAt = {};
            if (fromDate && !isNaN(fromDate.getTime()))
                where.createdAt.gte = fromDate;
            if (toDate && !isNaN(toDate.getTime()))
                where.createdAt.lte = toDate;
        }
        const [rows, total] = await Promise.all([
            db_1.prisma.agentSession.findMany({
                where,
                orderBy: { createdAt: "desc" },
                skip,
                take: limit,
                include: { project: { select: { name: true } } },
            }),
            db_1.prisma.agentSession.count({ where }),
        ]);
        const creditsPerDollar = runtime_config_service_1.runtimeConfig.getCreditsPerDollar() || 50;
        const sessions = rows.map((s) => {
            const costUsd = Number(s.costUsd || 0);
            const costUsdInput = s.costUsdInput != null ? Number(s.costUsdInput) : null;
            const costUsdOutput = s.costUsdOutput != null ? Number(s.costUsdOutput) : null;
            const credits = Number(s.creditsCharged || 0);
            const revenueUsd = credits / creditsPerDollar;
            const marginUsd = revenueUsd - costUsd;
            return {
                id: s.id,
                type: s.type,
                projectId: s.projectId,
                projectName: s.project?.name || "Unknown",
                userId: s.userId,
                model: s.model,
                input: (s.input || "").substring(0, 120),
                creditsCharged: credits,
                costUsd: parseFloat(costUsd.toFixed(6)),
                // Input/output split — null when the row is older than the OR
                // usage-accounting wiring. Frontend hides the breakdown row in that
                // case rather than showing $0.000000 for both.
                costUsdInput: costUsdInput != null ? parseFloat(costUsdInput.toFixed(6)) : null,
                costUsdOutput: costUsdOutput != null ? parseFloat(costUsdOutput.toFixed(6)) : null,
                revenueUsd: parseFloat(revenueUsd.toFixed(4)),
                marginUsd: parseFloat(marginUsd.toFixed(4)),
                inputTokens: s.inputTokens,
                outputTokens: s.outputTokens,
                durationMs: s.durationMs,
                success: s.success,
                createdAt: s.createdAt,
                complexity: s.complexity ?? null,
                isMaxMode: !!s.isMaxMode,
            };
        });
        res.json({ sessions, total, page, limit, creditsPerDollar });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// DELETE a single agent session log entry by id.
router.delete("/api/agent-sessions/:id", async (req, res) => {
    try {
        const id = String(req.params.id || "").trim();
        if (!id) {
            res.status(400).json({ error: "id is required" });
            return;
        }
        await db_1.prisma.agentSession.delete({ where: { id } });
        res.json({ ok: true });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// ── App Store moderation ─────────────────────────────────────────────────────
// Browser admin (bearer auth via /admin/api) endpoints. All listing/token
// access goes through appStoreService so DB integrity stays in one place.
router.get("/api/listings", async (req, res) => {
    try {
        const status = req.query.status || undefined;
        const { appStoreService } = await Promise.resolve().then(() => __importStar(require("../../services/app-store.service")));
        const items = await appStoreService.listForReview(status);
        res.json({
            items: items.map((row) => ({
                id: row.id,
                projectId: row.projectId,
                projectName: row.project?.name,
                botUsername: row.project?.botUsername,
                ownerTg: row.project?.user?.telegramId?.toString(),
                ownerUsername: row.project?.user?.username,
                ownerFirstName: row.project?.user?.firstName,
                status: row.status,
                shortDescription: row.shortDescription,
                longDescription: row.longDescription,
                category: row.category,
                socials: row.socials,
                screenshots: row.screenshots,
                publishFeeTxHash: row.publishFeeTxHash,
                submittedAt: row.submittedAt,
                approvedAt: row.approvedAt,
                publishedAt: row.publishedAt,
                rejectedReason: row.rejectedReason,
                hidden: row.hidden,
                token: row.token ? {
                    id: row.token.id,
                    name: row.token.name,
                    symbol: row.token.symbol,
                    logoFilename: row.token.logoFilename,
                    status: row.token.status,
                    jettonMasterAddress: row.token.jettonMasterAddress,
                    deployTxHash: row.token.deployTxHash,
                } : null,
            })),
        });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.post("/api/listings/:id/approve", async (req, res) => {
    try {
        const { appStoreService } = await Promise.resolve().then(() => __importStar(require("../../services/app-store.service")));
        // Admin user id 0 → not a real user, but appStoreService.approve only
        // stores it in approvedBy. The browser admin doesn't have a paired User
        // row by default, so 0 is a sentinel "browser admin".
        const result = await appStoreService.approve(req.params.id, 0);
        res.json(result);
    }
    catch (err) {
        res.status(400).json({ error: err.message });
    }
});
router.post("/api/listings/:id/reject", async (req, res) => {
    try {
        const reason = String(req.body?.reason || "rejected");
        const { appStoreService } = await Promise.resolve().then(() => __importStar(require("../../services/app-store.service")));
        const result = await appStoreService.reject(req.params.id, reason);
        res.json(result);
    }
    catch (err) {
        res.status(400).json({ error: err.message });
    }
});
router.post("/api/listings/:id/hide", async (req, res) => {
    try {
        const hidden = req.body?.hidden !== false;
        const { appStoreService } = await Promise.resolve().then(() => __importStar(require("../../services/app-store.service")));
        const result = await appStoreService.setHidden(req.params.id, hidden);
        res.json(result);
    }
    catch (err) {
        res.status(400).json({ error: err.message });
    }
});
// DELETE all usage_log rows for a given agent session (task_id).
// Used by Admin → Sessions to purge a single run from the table.
router.delete("/api/sessions/:taskId", async (req, res) => {
    try {
        const taskId = String(req.params.taskId || "").trim();
        if (!taskId) {
            res.status(400).json({ error: "taskId is required" });
            return;
        }
        const result = await db_1.prisma.usageLog.deleteMany({ where: { taskId } });
        res.json({ ok: true, deleted: result.count });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// GET agent session configurations and pricing.
// `pricing` returns the complexity matrix:
//   { build: { trivial, small, medium, large, huge },
//     update: {...}, "update-plan": {...},
//     "update-plan-per-item": {...}, "bug-fix": {...} }
router.get("/api/config/sessions", async (_req, res) => {
    res.json({
        sessions: runtime_config_service_1.runtimeConfig.getAllSessionConfigs(),
        pricing: runtime_config_service_1.runtimeConfig.getAgentPricing(),
    });
});
// POST update agent session configuration and pricing
router.post("/api/config/sessions", async (req, res) => {
    try {
        const { sessions, pricing } = req.body;
        const update = {};
        if (sessions && typeof sessions === "object")
            update.agentSessions = sessions;
        if (pricing && typeof pricing === "object")
            update.agentPricing = pricing;
        if (Object.keys(update).length === 0) {
            res.status(400).json({ error: "sessions or pricing required" });
            return;
        }
        runtime_config_service_1.runtimeConfig.update(update);
        res.json({ ok: true, sessions: runtime_config_service_1.runtimeConfig.getAllSessionConfigs(), pricing: runtime_config_service_1.runtimeConfig.get().agentPricing });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.get("/api/stats/sources/users", async (req, res) => {
    try {
        const result = await (0, admin_queries_service_1.listSourceUsers)({
            from: parseIsoQuery(req.query.from),
            to: parseIsoQuery(req.query.to),
            kind: String(req.query.kind || "all"),
            key: typeof req.query.key === "string" ? req.query.key : "",
        });
        res.json(result);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
// --- Runtime Config ---
router.get("/api/config", (_req, res) => {
    res.json(runtime_config_service_1.runtimeConfig.get());
});
router.post("/api/config", (req, res) => {
    try {
        runtime_config_service_1.runtimeConfig.update(req.body);
        res.json(runtime_config_service_1.runtimeConfig.get());
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// --- Vouchers ---
router.get("/api/vouchers", async (_req, res) => {
    try {
        const vouchers = await db_1.prisma.voucher.findMany({
            orderBy: { createdAt: "desc" },
            include: { _count: { select: { redemptions: true } } },
        });
        res.json(vouchers.map(v => ({
            id: v.id,
            code: v.code,
            amountUsd: Number(v.amountUsd),
            credits: v.credits,
            maxUses: v.maxUses,
            usedCount: v.usedCount,
            active: v.active,
            createdAt: v.createdAt,
            link: `https://t.me/apps_father_bot?start=${v.code}`,
        })));
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.post("/api/vouchers", async (req, res) => {
    try {
        const { credits, maxUses } = req.body;
        const cr = parseInt(credits, 10);
        const uses = parseInt(maxUses, 10);
        if (isNaN(cr) || cr <= 0) {
            res.status(400).json({ error: "Invalid credits" });
            return;
        }
        if (isNaN(uses) || uses <= 0) {
            res.status(400).json({ error: "Invalid maxUses" });
            return;
        }
        const code = "v_" + crypto_1.default.randomBytes(4).toString("hex");
        const voucher = await db_1.prisma.voucher.create({
            data: {
                code,
                amountUsd: new library_1.Decimal("0"),
                credits: cr,
                maxUses: uses,
            },
        });
        res.json({
            id: voucher.id,
            code: voucher.code,
            amountUsd: Number(voucher.amountUsd),
            credits: voucher.credits,
            maxUses: voucher.maxUses,
            usedCount: 0,
            active: true,
            createdAt: voucher.createdAt,
            link: `https://t.me/apps_father_bot?start=${voucher.code}`,
        });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.put("/api/vouchers/:id", async (req, res) => {
    try {
        const id = parseInt(req.params.id, 10);
        const data = {};
        if (req.body.amount !== undefined)
            data.amountUsd = new library_1.Decimal(parseFloat(req.body.amount).toFixed(4));
        if (req.body.maxUses !== undefined)
            data.maxUses = parseInt(req.body.maxUses, 10);
        if (req.body.active !== undefined)
            data.active = Boolean(req.body.active);
        const voucher = await db_1.prisma.voucher.update({ where: { id }, data });
        res.json({ id: voucher.id, amountUsd: Number(voucher.amountUsd), maxUses: voucher.maxUses, active: voucher.active });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.delete("/api/vouchers/:id", async (req, res) => {
    try {
        const id = parseInt(req.params.id, 10);
        await db_1.prisma.voucherRedemption.deleteMany({ where: { voucherId: id } });
        await db_1.prisma.voucher.delete({ where: { id } });
        res.json({ ok: true });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// --- Helpers ---
function walkDir(dir, base) {
    const results = [];
    if (!fs_1.default.existsSync(dir))
        return results;
    for (const entry of fs_1.default.readdirSync(dir, { withFileTypes: true })) {
        const fullPath = path_1.default.join(dir, entry.name);
        const relPath = path_1.default.relative(base, fullPath).replace(/\\/g, "/");
        if (entry.name === "node_modules" || entry.name === ".git")
            continue;
        if (entry.isDirectory()) {
            results.push(...walkDir(fullPath, base));
        }
        else {
            results.push({ path: relPath, name: entry.name });
        }
    }
    return results;
}
// --- Serve the SPA for any non-API path under /admin ---
// Static assets: admin/css/*, admin/js/*, etc.
router.use(express_2.default.static(ADMIN_DIR, { fallthrough: true, index: false }));
// SPA fallback: anything that isn't /api/* falls back to index.html so the
// vanilla-JS router on the client can take over.
// Proxy the OpenRouter model catalog so the Models admin page can show live pricing.
router.get("/api/openrouter/models", authMiddleware, async (_req, res) => {
    const key = runtime_config_service_1.runtimeConfig.getOpenRouterApiKey() || config_1.config.openrouterApiKey;
    if (!key) {
        res.status(400).json({ error: "OpenRouter API key not configured" });
        return;
    }
    try {
        const r = await fetch("https://openrouter.ai/api/v1/models", {
            headers: { Authorization: `Bearer ${key}` },
        });
        const data = await r.json();
        res.json(data);
    }
    catch (err) {
        res.status(502).json({ error: `Failed to fetch OpenRouter models: ${err.message}` });
    }
});
router.get("/api/openrouter/models/:author/:slug/endpoints", authMiddleware, async (req, res) => {
    const key = runtime_config_service_1.runtimeConfig.getOpenRouterApiKey() || config_1.config.openrouterApiKey;
    if (!key) {
        res.status(400).json({ error: "OpenRouter API key not configured" });
        return;
    }
    const author = String(req.params.author || "");
    const slug = String(req.params.slug || "");
    try {
        const r = await fetch(`https://openrouter.ai/api/v1/models/${encodeURIComponent(author)}/${encodeURIComponent(slug)}/endpoints`, {
            headers: { Authorization: `Bearer ${key}` },
        });
        if (!r.ok) {
            res.status(r.status).json({ error: `OpenRouter returned ${r.status}` });
            return;
        }
        const data = await r.json();
        res.json(data);
    }
    catch (err) {
        res.status(502).json({ error: `Failed to fetch endpoints: ${err.message}` });
    }
});
// ── Bundles CRUD ─────────────────────────────────────────────────────────────
router.get("/api/bundles", async (_req, res) => {
    try {
        const bundles = await db_1.prisma.bundle.findMany({ orderBy: { sortOrder: "asc" } });
        res.json(bundles.map((b) => ({
            id: b.id,
            name: b.name,
            credits: b.credits,
            bonusCredits: b.bonusCredits,
            priceUsd: Number(b.priceUsd),
            discount: b.discount,
            isLimited: b.isLimited,
            limitTotal: b.limitTotal,
            purchaseCount: b.purchaseCount,
            isActive: b.isActive,
            sortOrder: b.sortOrder,
            createdAt: b.createdAt,
        })));
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.post("/api/bundles", async (req, res) => {
    try {
        const { name, credits, bonusCredits, priceUsd, discount, isLimited, limitTotal, isActive, sortOrder } = req.body;
        if (!name || !credits || !priceUsd) {
            res.status(400).json({ error: "name, credits, and priceUsd are required" });
            return;
        }
        const id = `bundle_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
        const bundle = await db_1.prisma.bundle.create({
            data: {
                id,
                name: String(name),
                credits: parseInt(credits, 10),
                bonusCredits: parseInt(bonusCredits || 0, 10),
                priceUsd: new library_1.Decimal(Number(priceUsd).toFixed(4)),
                discount: parseInt(discount || 0, 10),
                isLimited: Boolean(isLimited),
                limitTotal: isLimited && limitTotal ? parseInt(limitTotal, 10) : null,
                isActive: isActive !== false,
                sortOrder: parseInt(sortOrder || 0, 10),
            },
        });
        res.json(bundle);
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.put("/api/bundles/:id", async (req, res) => {
    try {
        const { name, credits, bonusCredits, priceUsd, discount, isLimited, limitTotal, isActive, sortOrder } = req.body;
        const bundle = await db_1.prisma.bundle.update({
            where: { id: req.params.id },
            data: {
                ...(name !== undefined && { name: String(name) }),
                ...(credits !== undefined && { credits: parseInt(credits, 10) }),
                ...(bonusCredits !== undefined && { bonusCredits: parseInt(bonusCredits, 10) }),
                ...(priceUsd !== undefined && { priceUsd: new library_1.Decimal(Number(priceUsd).toFixed(4)) }),
                ...(discount !== undefined && { discount: parseInt(discount, 10) }),
                ...(isLimited !== undefined && { isLimited: Boolean(isLimited) }),
                ...(limitTotal !== undefined && { limitTotal: isLimited && limitTotal ? parseInt(limitTotal, 10) : null }),
                ...(isActive !== undefined && { isActive: Boolean(isActive) }),
                ...(sortOrder !== undefined && { sortOrder: parseInt(sortOrder, 10) }),
            },
        });
        res.json(bundle);
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.delete("/api/bundles/:id", async (req, res) => {
    try {
        await db_1.prisma.bundle.update({
            where: { id: req.params.id },
            data: { isActive: false },
        });
        res.json({ ok: true });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.post("/api/bundles/:id/reset-count", async (req, res) => {
    try {
        const bundle = await db_1.prisma.bundle.update({
            where: { id: req.params.id },
            data: { purchaseCount: 0 },
        });
        res.json({ ok: true, purchaseCount: bundle.purchaseCount });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// ── Tasks CRUD ──────────────────────────────────────────────────────────────
const TASK_UPLOADS_DIR = path_1.default.join(ADMIN_DIR, "uploads", "tasks");
if (!fs_1.default.existsSync(TASK_UPLOADS_DIR))
    fs_1.default.mkdirSync(TASK_UPLOADS_DIR, { recursive: true });
const taskImageStorage = require("multer").diskStorage({
    destination: (_req, _file, cb) => cb(null, TASK_UPLOADS_DIR),
    filename: (_req, file, cb) => {
        const ext = path_1.default.extname(file.originalname) || ".jpg";
        cb(null, `${Date.now()}-${crypto_1.default.randomBytes(4).toString("hex")}${ext}`);
    },
});
const taskImageUpload = require("multer")({ storage: taskImageStorage, limits: { fileSize: 5 * 1024 * 1024 } });
router.post("/api/tasks/upload-image", taskImageUpload.single("image"), async (req, res) => {
    try {
        if (!req.file) {
            res.status(400).json({ error: "No file" });
            return;
        }
        const url = `/admin/uploads/tasks/${req.file.filename}`;
        res.json({ url });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.get("/api/tasks", async (_req, res) => {
    try {
        const tasks = await db_1.prisma.task.findMany({
            orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
        });
        const counts = await db_1.prisma.taskCompletion.groupBy({
            by: ["taskId"],
            _count: { taskId: true },
        });
        const countMap = new Map(counts.map(c => [c.taskId, c._count.taskId]));
        res.json(tasks.map(t => ({ ...t, _completionCount: countMap.get(t.id) ?? 0 })));
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.post("/api/tasks", async (req, res) => {
    try {
        const { title, description, imageUrl, reward, link, type, payload, targeting, delaySeconds, isActive, sortOrder } = req.body;
        const task = await db_1.prisma.task.create({
            data: {
                title: title || { en: "", ru: "", uk: "" },
                description: description || { en: "", ru: "", uk: "" },
                imageUrl: imageUrl || null,
                reward: Number(reward) || 0,
                link: link || "",
                type: type || "open_link",
                payload: payload || null,
                targeting: targeting || "all",
                delaySeconds: Number(delaySeconds) || 5,
                isActive: isActive !== false,
                sortOrder: Number(sortOrder) || 0,
            },
        });
        res.json(task);
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.put("/api/tasks/:id", async (req, res) => {
    try {
        const id = parseInt(req.params.id, 10);
        const { title, description, imageUrl, reward, link, type, payload, targeting, delaySeconds, isActive, sortOrder } = req.body;
        const task = await db_1.prisma.task.update({
            where: { id },
            data: {
                ...(title !== undefined && { title }),
                ...(description !== undefined && { description }),
                ...(imageUrl !== undefined && { imageUrl: imageUrl || null }),
                ...(reward !== undefined && { reward: Number(reward) }),
                ...(link !== undefined && { link }),
                ...(type !== undefined && { type }),
                ...(payload !== undefined && { payload: payload || null }),
                ...(targeting !== undefined && { targeting }),
                ...(delaySeconds !== undefined && { delaySeconds: Number(delaySeconds) }),
                ...(isActive !== undefined && { isActive }),
                ...(sortOrder !== undefined && { sortOrder: Number(sortOrder) }),
            },
        });
        res.json(task);
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.delete("/api/tasks/:id", async (req, res) => {
    try {
        const id = parseInt(req.params.id, 10);
        await db_1.prisma.task.delete({ where: { id } });
        res.json({ ok: true });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// Serve uploaded task images
router.use("/uploads/tasks", express_2.default.static(TASK_UPLOADS_DIR));
// ── Agent Lessons & Code Patches (training knowledge) ──────────────────────
//
// Two stores share one Import/Export pipeline:
//   * agent-lessons  — text rules, runtime-injected when enabled.
//   * agent-patches  — text suggestions for editing agent code, never auto-applied.
// See agent-lessons.service.ts for per-env semantics.
const agentKnowledge = __importStar(require("../../services/agent-lessons.service"));
// In-memory upload storage for the import preview/apply endpoints (small JSON files).
const knowledgeImportUpload = require("multer")({
    storage: require("multer").memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024 },
});
// --- Lessons CRUD ---
router.get("/api/agent-lessons", async (req, res) => {
    try {
        const enabled = req.query.enabled === "true" ? true : req.query.enabled === "false" ? false : undefined;
        const tag = typeof req.query.tag === "string" ? req.query.tag : undefined;
        const q = typeof req.query.q === "string" ? req.query.q : undefined;
        const lessons = await agentKnowledge.listLessons({ enabled, tag, q });
        res.json(lessons);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.post("/api/agent-lessons", async (req, res) => {
    try {
        const lesson = await agentKnowledge.createLesson(req.body || {});
        res.json(lesson);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.get("/api/agent-lessons/:id", async (req, res) => {
    try {
        const lesson = await agentKnowledge.getLesson(req.params.id);
        if (!lesson) {
            res.status(404).json({ error: "Lesson not found" });
            return;
        }
        res.json(lesson);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.patch("/api/agent-lessons/:id", async (req, res) => {
    try {
        const lesson = await agentKnowledge.updateLesson(req.params.id, req.body || {});
        res.json(lesson);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.delete("/api/agent-lessons/:id", async (req, res) => {
    try {
        await agentKnowledge.deleteLesson(req.params.id);
        res.json({ ok: true });
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.post("/api/agent-lessons/:id/enable", async (req, res) => {
    try {
        const lesson = await agentKnowledge.setLessonEnabled(req.params.id, true);
        res.json(lesson);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.post("/api/agent-lessons/:id/disable", async (req, res) => {
    try {
        const lesson = await agentKnowledge.setLessonEnabled(req.params.id, false);
        res.json(lesson);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.post("/api/agent-lessons/bulk-enable", async (req, res) => {
    try {
        const ids = Array.isArray(req.body?.ids) ? req.body.ids.map(String) : [];
        const result = await agentKnowledge.bulkSetLessonEnabled(ids, true);
        res.json({ ok: true, count: result.count });
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.post("/api/agent-lessons/bulk-disable", async (req, res) => {
    try {
        const ids = Array.isArray(req.body?.ids) ? req.body.ids.map(String) : [];
        const result = await agentKnowledge.bulkSetLessonEnabled(ids, false);
        res.json({ ok: true, count: result.count });
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
// --- Code Patches CRUD ---
router.get("/api/agent-patches", async (req, res) => {
    try {
        const status = typeof req.query.status === "string" ? req.query.status : undefined;
        const tag = typeof req.query.tag === "string" ? req.query.tag : undefined;
        const q = typeof req.query.q === "string" ? req.query.q : undefined;
        const patches = await agentKnowledge.listPatches({ status, tag, q });
        res.json(patches);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.post("/api/agent-patches", async (req, res) => {
    try {
        const patch = await agentKnowledge.createPatch(req.body || {});
        res.json(patch);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.get("/api/agent-patches/:id", async (req, res) => {
    try {
        const patch = await agentKnowledge.getPatch(req.params.id);
        if (!patch) {
            res.status(404).json({ error: "Patch not found" });
            return;
        }
        res.json(patch);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.patch("/api/agent-patches/:id", async (req, res) => {
    try {
        const patch = await agentKnowledge.updatePatch(req.params.id, req.body || {});
        res.json(patch);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.delete("/api/agent-patches/:id", async (req, res) => {
    try {
        await agentKnowledge.deletePatch(req.params.id);
        res.json({ ok: true });
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.post("/api/agent-patches/:id/mark-applied", async (req, res) => {
    try {
        const commit = typeof req.body?.commit === "string" ? req.body.commit : undefined;
        const patch = await agentKnowledge.setPatchStatus(req.params.id, "applied", { commit });
        res.json(patch);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.post("/api/agent-patches/:id/mark-rejected", async (req, res) => {
    try {
        const patch = await agentKnowledge.setPatchStatus(req.params.id, "rejected");
        res.json(patch);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.post("/api/agent-patches/:id/reopen", async (req, res) => {
    try {
        const patch = await agentKnowledge.setPatchStatus(req.params.id, "proposed");
        res.json(patch);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
// --- Unified Export / Import (one file, both kinds) ---
router.get("/api/agent-knowledge/export", async (req, res) => {
    try {
        const includeRaw = typeof req.query.include === "string" ? req.query.include : undefined;
        const include = includeRaw
            ? includeRaw.split(",").map((s) => s.trim()).filter(Boolean)
            : undefined;
        const { json, filename } = await agentKnowledge.exportKnowledge({ include });
        res.setHeader("Content-Type", "application/json; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
        res.send(json);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.post("/api/agent-knowledge/import/preview", knowledgeImportUpload.single("file"), async (req, res) => {
    try {
        const raw = req.file?.buffer?.toString("utf-8");
        if (!raw) {
            res.status(400).json({ error: "No file uploaded" });
            return;
        }
        const diff = await agentKnowledge.previewImport(raw);
        res.json(diff);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.post("/api/agent-knowledge/import/apply", async (req, res) => {
    try {
        const { json, lessonActions, patchActions, enableNewLessons } = req.body || {};
        if (typeof json !== "string" || !json.trim()) {
            res.status(400).json({ error: "Missing 'json' string in body" });
            return;
        }
        const result = await agentKnowledge.applyImport(json, {
            lessonActions: lessonActions || {},
            patchActions: patchActions || {},
            enableNewLessons: !!enableNewLessons,
        });
        res.json(result);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
// ── Agent Feedback (cashback issues) — review & analysis ────────────────────
//
// Admin reviews cases collected by the mini app, then either:
//   1. Clicks "Run Analysis" → fires LLM in background (status: learning)
//   2. After result_ready, clicks "Apply" → creates AgentLesson / AgentCodePatch
//      rows from the LLM's suggestions.
const agentFeedbackService = __importStar(require("../../services/agent-feedback.service"));
router.get("/api/agent-feedback", async (req, res) => {
    try {
        const status = typeof req.query.status === "string" ? req.query.status : undefined;
        const q = typeof req.query.q === "string" ? req.query.q : undefined;
        const where = {};
        if (status && status !== "all")
            where.analysisStatus = status;
        if (q) {
            where.OR = [
                { userPrompt: { contains: q, mode: "insensitive" } },
                { userDescription: { contains: q, mode: "insensitive" } },
            ];
        }
        // Guard against orphaned rows (project deleted after feedback was created).
        // Prisma throws "got null instead" for required relations, so we pre-filter.
        where.project = { id: { not: "" } };
        const items = await db_1.prisma.agentFeedback.findMany({
            where,
            orderBy: { createdAt: "desc" },
            take: 200,
            include: {
                user: { select: { id: true, telegramId: true, username: true, firstName: true } },
                project: { select: { id: true, name: true, botUsername: true } },
            },
        });
        // Convert BigInt telegramId for JSON.
        const safe = items.map((it) => ({
            ...it,
            user: it.user
                ? { ...it.user, telegramId: it.user.telegramId ? String(it.user.telegramId) : null }
                : null,
        }));
        res.json(safe);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.get("/api/agent-feedback/:id", async (req, res) => {
    try {
        const fb = await db_1.prisma.agentFeedback.findFirst({
            where: { id: req.params.id, project: { id: { not: "" } } },
            include: {
                user: { select: { id: true, telegramId: true, username: true, firstName: true } },
                project: { select: { id: true, name: true, botUsername: true } },
            },
        });
        if (!fb) {
            res.status(404).json({ error: "Not found" });
            return;
        }
        // Lazy-load the parsed agent log only on the detail endpoint to keep the
        // list payload light.
        const logEntries = agentFeedbackService.readAgentLogEntries(fb.projectId, fb.commitNumAfter);
        res.json({
            ...fb,
            user: fb.user
                ? { ...fb.user, telegramId: fb.user.telegramId ? String(fb.user.telegramId) : null }
                : null,
            logEntries,
        });
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.post("/api/agent-feedback/:id/analyze", async (req, res) => {
    try {
        const fb = await db_1.prisma.agentFeedback.findUnique({ where: { id: req.params.id } });
        if (!fb) {
            res.status(404).json({ error: "Not found" });
            return;
        }
        if (fb.analysisStatus === "learning") {
            res.status(409).json({ error: "already_learning" });
            return;
        }
        // Fire-and-forget: respond immediately so admin UI can poll for status.
        // Errors are caught + recorded to analysisError on the row.
        agentFeedbackService.analyzeCase(req.params.id).catch((err) => {
            console.warn(`[Admin] analyzeCase background failure: ${err?.message || err}`);
        });
        res.json({ ok: true, status: "learning" });
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.post("/api/agent-feedback/:id/apply", async (req, res) => {
    try {
        const fb = await db_1.prisma.agentFeedback.findUnique({ where: { id: req.params.id } });
        if (!fb) {
            res.status(404).json({ error: "Not found" });
            return;
        }
        if (fb.analysisStatus !== "result_ready") {
            res.status(409).json({ error: "not_ready" });
            return;
        }
        const result = fb.analysisResult || {};
        const lessons = Array.isArray(result.suggestedLessons) ? result.suggestedLessons : [];
        const patches = Array.isArray(result.suggestedPatches) ? result.suggestedPatches : [];
        // Optional: caller can specify which suggestions to apply. Default = all.
        const lessonPicks = Array.isArray(req.body?.lessonIndexes)
            ? req.body.lessonIndexes.map((n) => Number(n)).filter((n) => Number.isFinite(n))
            : lessons.map((_, i) => i);
        const patchPicks = Array.isArray(req.body?.patchIndexes)
            ? req.body.patchIndexes.map((n) => Number(n)).filter((n) => Number.isFinite(n))
            : patches.map((_, i) => i);
        const createdLessonIds = [];
        for (const idx of lessonPicks) {
            const l = lessons[idx];
            if (!l || !l.rule)
                continue;
            const created = await agentKnowledge.createLesson({
                rule: String(l.rule),
                context: l.context ? String(l.context) : null,
                tags: Array.isArray(l.tags) ? l.tags.map(String) : [],
                notes: l.notes ? String(l.notes) : `From feedback case ${fb.id}`,
            });
            createdLessonIds.push(created.id);
        }
        const createdPatchIds = [];
        for (const idx of patchPicks) {
            const p = patches[idx];
            if (!p || !p.title || !p.problem || !p.suggestion || !p.cursorPrompt)
                continue;
            const created = await agentKnowledge.createPatch({
                title: String(p.title),
                problem: String(p.problem),
                targetFiles: Array.isArray(p.targetFiles) ? p.targetFiles.map(String) : [],
                suggestion: String(p.suggestion),
                cursorPrompt: String(p.cursorPrompt),
                tags: Array.isArray(p.tags) ? p.tags.map(String) : [],
                notes: p.notes ? String(p.notes) : `From feedback case ${fb.id}`,
            });
            createdPatchIds.push(created.id);
        }
        const updated = await db_1.prisma.agentFeedback.update({
            where: { id: fb.id },
            data: {
                analysisStatus: "applied",
                appliedAt: new Date(),
                appliedLessonIds: createdLessonIds,
                appliedPatchIds: createdPatchIds,
            },
        });
        res.json({
            ok: true,
            createdLessons: createdLessonIds.length,
            createdPatches: createdPatchIds.length,
            feedback: updated,
        });
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.patch("/api/agent-feedback/:id", async (req, res) => {
    try {
        const status = typeof req.body?.analysisStatus === "string" ? req.body.analysisStatus : undefined;
        const allowed = new Set(["pending", "learning", "result_ready", "applied", "skipped"]);
        if (!status || !allowed.has(status)) {
            res.status(400).json({ error: "Invalid analysisStatus" });
            return;
        }
        const data = { analysisStatus: status };
        if (status === "skipped")
            data.appliedAt = new Date();
        if (status === "pending")
            data.analysisError = null;
        const updated = await db_1.prisma.agentFeedback.update({ where: { id: req.params.id }, data });
        res.json(updated);
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.delete("/api/agent-feedback/:id", async (req, res) => {
    try {
        await db_1.prisma.agentFeedback.delete({ where: { id: req.params.id } });
        res.json({ ok: true });
    }
    catch (err) {
        res.status(err.status || 500).json({ error: err.message });
    }
});
router.get(/^\/(?!api(\/|$)).*/, (_req, res) => {
    const indexPath = path_1.default.join(ADMIN_DIR, "index.html");
    if (!fs_1.default.existsSync(indexPath)) {
        res.status(500).type("text/plain").send("admin/ folder not built \u2014 missing index.html");
        return;
    }
    res.sendFile(indexPath);
});
exports.default = router;
//# sourceMappingURL=admin.routes.js.map