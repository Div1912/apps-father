/**
 * Agent training knowledge — lessons (runtime rules) and code patches (manual IDE fixes).
 *
 * Two storage models share one import/export pipeline:
 *   - AgentLesson    — text rule injected into buildSystemPrompt() when enabled.
 *   - AgentCodePatch — text suggestion for editing agent.service.ts / agent_knowledge/*.md.
 *                      Never applied automatically; admin copies cursorPrompt to IDE.
 *
 * Per-env state (enabled flag, status transitions, timestamps, importedFrom, sourceCaseId,
 * appliedCommit) is preserved on the local environment and never overwritten by import.
 */
export type LessonAction = "create" | "update" | "skip";
export type PatchAction = "create" | "update" | "skip";
export interface LessonInput {
    rule: string;
    context?: string | null;
    tags?: string[];
    notes?: string | null;
}
export interface PatchInput {
    title: string;
    problem: string;
    targetFiles?: string[];
    suggestion: string;
    cursorPrompt: string;
    tags?: string[];
    notes?: string | null;
}
export interface ExportedLesson {
    id: string;
    rule: string;
    context: string | null;
    tags: string[];
    notes: string | null;
    contentHash: string;
}
export interface ExportedPatch {
    id: string;
    title: string;
    problem: string;
    targetFiles: string[];
    suggestion: string;
    cursorPrompt: string;
    tags: string[];
    notes: string | null;
    contentHash: string;
}
export interface ExportFile {
    exportVersion: 1;
    exportedAt: string;
    exportedFrom: string;
    counts: {
        lessons: number;
        patches: number;
    };
    lessons: ExportedLesson[];
    patches: ExportedPatch[];
}
export interface ImportDiff {
    exportedFrom: string;
    exportedAt: string;
    lessons: {
        new: ExportedLesson[];
        updated: Array<{
            local: any;
            incoming: ExportedLesson;
            fieldsChanged: string[];
        }>;
        identical: ExportedLesson[];
        localOnly: any[];
    };
    patches: {
        new: ExportedPatch[];
        updated: Array<{
            local: any;
            incoming: ExportedPatch;
            fieldsChanged: string[];
        }>;
        identical: ExportedPatch[];
        localOnly: any[];
    };
}
export declare function invalidateCache(): void;
export declare function listLessons(filter?: {
    enabled?: boolean;
    tag?: string;
    q?: string;
}): Promise<{
    context: string | null;
    id: string;
    createdAt: Date;
    updatedAt: Date;
    notes: string | null;
    enabled: boolean;
    rule: string;
    tags: string[];
    sourceCaseId: string | null;
    contentHash: string;
    enabledAt: Date | null;
    disabledAt: Date | null;
    importedFrom: string | null;
}[]>;
export declare function getLesson(id: string): Promise<{
    context: string | null;
    id: string;
    createdAt: Date;
    updatedAt: Date;
    notes: string | null;
    enabled: boolean;
    rule: string;
    tags: string[];
    sourceCaseId: string | null;
    contentHash: string;
    enabledAt: Date | null;
    disabledAt: Date | null;
    importedFrom: string | null;
} | null>;
export declare function createLesson(input: LessonInput): Promise<{
    context: string | null;
    id: string;
    createdAt: Date;
    updatedAt: Date;
    notes: string | null;
    enabled: boolean;
    rule: string;
    tags: string[];
    sourceCaseId: string | null;
    contentHash: string;
    enabledAt: Date | null;
    disabledAt: Date | null;
    importedFrom: string | null;
}>;
export declare function updateLesson(id: string, patch: Partial<LessonInput>): Promise<{
    context: string | null;
    id: string;
    createdAt: Date;
    updatedAt: Date;
    notes: string | null;
    enabled: boolean;
    rule: string;
    tags: string[];
    sourceCaseId: string | null;
    contentHash: string;
    enabledAt: Date | null;
    disabledAt: Date | null;
    importedFrom: string | null;
}>;
export declare function deleteLesson(id: string): Promise<void>;
export declare function setLessonEnabled(id: string, enabled: boolean): Promise<{
    context: string | null;
    id: string;
    createdAt: Date;
    updatedAt: Date;
    notes: string | null;
    enabled: boolean;
    rule: string;
    tags: string[];
    sourceCaseId: string | null;
    contentHash: string;
    enabledAt: Date | null;
    disabledAt: Date | null;
    importedFrom: string | null;
}>;
export declare function bulkSetLessonEnabled(ids: string[], enabled: boolean): Promise<import("@prisma/client").Prisma.BatchPayload>;
export declare function listPatches(filter?: {
    status?: string;
    tag?: string;
    q?: string;
}): Promise<{
    id: string;
    createdAt: Date;
    status: string;
    updatedAt: Date;
    notes: string | null;
    tags: string[];
    sourceCaseId: string | null;
    contentHash: string;
    importedFrom: string | null;
    cursorPrompt: string;
    suggestion: string;
    problem: string;
    title: string;
    targetFiles: string[];
    appliedAt: Date | null;
    rejectedAt: Date | null;
    appliedCommit: string | null;
}[]>;
export declare function getPatch(id: string): Promise<{
    id: string;
    createdAt: Date;
    status: string;
    updatedAt: Date;
    notes: string | null;
    tags: string[];
    sourceCaseId: string | null;
    contentHash: string;
    importedFrom: string | null;
    cursorPrompt: string;
    suggestion: string;
    problem: string;
    title: string;
    targetFiles: string[];
    appliedAt: Date | null;
    rejectedAt: Date | null;
    appliedCommit: string | null;
} | null>;
export declare function createPatch(input: PatchInput): Promise<{
    id: string;
    createdAt: Date;
    status: string;
    updatedAt: Date;
    notes: string | null;
    tags: string[];
    sourceCaseId: string | null;
    contentHash: string;
    importedFrom: string | null;
    cursorPrompt: string;
    suggestion: string;
    problem: string;
    title: string;
    targetFiles: string[];
    appliedAt: Date | null;
    rejectedAt: Date | null;
    appliedCommit: string | null;
}>;
export declare function updatePatch(id: string, patch: Partial<PatchInput>): Promise<{
    id: string;
    createdAt: Date;
    status: string;
    updatedAt: Date;
    notes: string | null;
    tags: string[];
    sourceCaseId: string | null;
    contentHash: string;
    importedFrom: string | null;
    cursorPrompt: string;
    suggestion: string;
    problem: string;
    title: string;
    targetFiles: string[];
    appliedAt: Date | null;
    rejectedAt: Date | null;
    appliedCommit: string | null;
}>;
export declare function deletePatch(id: string): Promise<void>;
export declare function setPatchStatus(id: string, status: "proposed" | "applied" | "rejected", opts?: {
    commit?: string;
}): Promise<{
    id: string;
    createdAt: Date;
    status: string;
    updatedAt: Date;
    notes: string | null;
    tags: string[];
    sourceCaseId: string | null;
    contentHash: string;
    importedFrom: string | null;
    cursorPrompt: string;
    suggestion: string;
    problem: string;
    title: string;
    targetFiles: string[];
    appliedAt: Date | null;
    rejectedAt: Date | null;
    appliedCommit: string | null;
}>;
export interface ExportOptions {
    include?: Array<"lessons" | "patches">;
}
export declare function exportKnowledge(opts?: ExportOptions): Promise<{
    json: string;
    filename: string;
}>;
export declare function previewImport(rawJson: string): Promise<ImportDiff>;
export interface ApplyImportOptions {
    /**
     * Per-id action ("create" / "update" / "skip"). Missing ids default to "skip"
     * for new/updated rows so the admin must opt in deliberately.
     */
    lessonActions?: Record<string, LessonAction>;
    patchActions?: Record<string, PatchAction>;
    /** When true, newly imported lessons land enabled. Default: false. */
    enableNewLessons?: boolean;
}
export interface ApplyImportResult {
    lessons: {
        created: number;
        updated: number;
        skipped: number;
    };
    patches: {
        created: number;
        updated: number;
        skipped: number;
    };
}
export declare function applyImport(rawJson: string, options?: ApplyImportOptions): Promise<ApplyImportResult>;
/**
 * Returns a formatted block for inclusion in the agent's system prompt.
 * Empty string when no lessons are enabled. Cached in memory until any
 * mutation calls invalidateCache().
 */
export declare function getEnabledLessonsBlock(): Promise<string>;
//# sourceMappingURL=agent-lessons.service.d.ts.map