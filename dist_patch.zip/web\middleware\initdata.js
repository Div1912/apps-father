"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyInitData = verifyInitData;
const crypto_1 = __importDefault(require("crypto"));
const project_service_1 = require("../../services/project.service");
const crypto_service_1 = require("../../services/crypto.service");
async function verifyInitData(req, res, next) {
    const rawHeader = req.headers["x-telegram-init-data"] ||
        req.headers["authorization"]?.replace("Bearer ", "") || "";
    const initData = Array.isArray(rawHeader) ? rawHeader[0] : rawHeader;
    const projectId = String(req.params.projectId);
    if (!projectId) {
        res.status(400).json({ error: "Missing project ID" });
        return;
    }
    req.projectId = projectId;
    // If no initData at all — allow through, but no user context.
    if (!initData) {
        next();
        return;
    }
    // Always parse the user out of initData so req.telegramUser is populated
    // even when we cannot verify the signature (no bot token yet, dev mode, etc.)
    // HMAC verification is still attempted and logged, but never blocks the request.
    const parsedUser = parseInitDataUser(initData);
    if (parsedUser) {
        req.telegramUser = parsedUser;
    }
    try {
        const project = await project_service_1.projectService.getProject(projectId);
        if (!project?.botTokenEncrypted) {
            // No bot token configured yet — user is set from raw initData above.
            next();
            return;
        }
        const botToken = (0, crypto_service_1.decryptToken)(project.botTokenEncrypted);
        const isValid = validateTelegramInitData(initData, botToken);
        if (!isValid) {
            console.log(`[InitData] Hash mismatch for project ${projectId} — allowing with unverified user`);
        }
        else {
            // Full parse when hash is valid (includes all fields, not just user).
            const parsed = parseInitData(initData);
            req.telegramUser = parsed.user;
        }
        next();
    }
    catch (err) {
        console.error("[InitData] Verification error:", err);
        next();
    }
}
function validateTelegramInitData(initData, botToken) {
    try {
        const params = new URLSearchParams(initData);
        const hash = params.get("hash");
        if (!hash)
            return false;
        params.delete("hash");
        const entries = Array.from(params.entries());
        entries.sort(([a], [b]) => a.localeCompare(b));
        const dataCheckString = entries.map(([k, v]) => `${k}=${v}`).join("\n");
        const secretKey = crypto_1.default
            .createHmac("sha256", "WebAppData")
            .update(botToken)
            .digest();
        const computedHash = crypto_1.default
            .createHmac("sha256", secretKey)
            .update(dataCheckString)
            .digest("hex");
        return computedHash === hash;
    }
    catch {
        return false;
    }
}
function parseInitData(initData) {
    const params = new URLSearchParams(initData);
    const result = {};
    for (const [key, value] of params.entries()) {
        try {
            result[key] = JSON.parse(value);
        }
        catch {
            result[key] = value;
        }
    }
    return result;
}
// Fast extraction of just the `user` object from initData — no crypto, used as
// an unverified fallback when the project has no bot token configured yet.
function parseInitDataUser(initData) {
    try {
        const params = new URLSearchParams(initData);
        const userStr = params.get("user");
        if (!userStr)
            return null;
        return JSON.parse(userStr);
    }
    catch {
        return null;
    }
}
//# sourceMappingURL=initdata.js.map