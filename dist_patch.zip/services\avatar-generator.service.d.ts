/**
 * Step 1 — ask Haiku to draft a Nano-Banana logo prompt for this app.
 * Returns just the raw prompt string (no markdown wrappers).
 */
export declare function buildLogoPrompt(appDescription: string, appName?: string): Promise<string>;
/**
 * End-to-end: description → Haiku prompt → ApiPass image URL.
 * Throws on any upstream failure or timeout.
 */
export declare function generateAvatarUrl(appDescription: string, appName?: string): Promise<{
    imageUrl: string;
    prompt: string;
}>;
//# sourceMappingURL=avatar-generator.service.d.ts.map