/**
 * Agent Feedback analysis pipeline (Investigator).
 *
 * The analyzer is itself an LLM agent: instead of a single fat prompt we give
 * it READ-ONLY tools and let it gather evidence iteratively, then submit a
 * structured analysis via the terminal `submit_analysis` tool.
 *
 * Available tools (server-side execution):
 *   - list_instructions / read_instruction
 *   - list_agent_sources / read_agent_source
 *   - list_commit_files / read_commit_file
 *   - read_commit_diff
 *   - read_agent_log_window
 *   - submit_analysis           (terminal — produces AnalysisResult)
 *
 * Uses a SEPARATE OpenRouter API key + optional provider routing
 * (runtimeConfig.getTrainingApiKey / getTrainingProvider) so training spend
 * is isolated from production user runs.
 */
export interface SuggestedLesson {
    rule: string;
    context?: string | null;
    tags?: string[];
    notes?: string | null;
}
export interface SuggestedPatch {
    title: string;
    problem: string;
    targetFiles: string[];
    suggestion: string;
    cursorPrompt: string;
    tags?: string[];
    notes?: string | null;
}
export interface InvestigationStep {
    iter: number;
    tool: string;
    args: Record<string, any>;
    resultPreview: string;
    resultLength: number;
    ok: boolean;
}
export interface AnalysisUsage {
    input: number;
    output: number;
    cacheRead: number;
    cacheWrite: number;
}
export interface AnalysisResult {
    summary: string;
    rootCause?: string;
    suggestedLessons: SuggestedLesson[];
    suggestedPatches: SuggestedPatch[];
    investigationLog?: InvestigationStep[];
    iterations?: number;
    truncated?: boolean;
    usage?: AnalysisUsage;
}
interface CaseContext {
    feedbackId: string;
    projectId: string;
    commitNumBefore: number | null;
    commitNumAfter: number | null;
    /** Pre-parsed agent log entries (full, not truncated). */
    agentLogEntries: any[];
}
interface AnalysisInputs {
    userPrompt: string;
    isCorrect: boolean;
    qualityScore: number;
    speedScore: number;
    userDescription: string | null | undefined;
    ctx: CaseContext;
    instructionsList: string[];
    hasBeforeCommit: boolean;
    hasAfterCommit: boolean;
}
/**
 * Build the system + user messages for the analysis call. Exported for
 * tests / future reuse.
 */
export declare function buildAnalysisPrompt(inputs: AnalysisInputs): {
    system: string;
    user: string;
};
export declare function analyzeCase(feedbackId: string): Promise<void>;
export declare function readAgentLogEntries(projectId: string, commitNum: number | null | undefined): any[];
export declare function readInstructionFile(name: string): string;
export {};
//# sourceMappingURL=agent-feedback.service.d.ts.map