export interface AgentToolDefinition {
    name: string;
    description: string;
    input_schema: Record<string, any>;
}
//# sourceMappingURL=types.d.ts.map