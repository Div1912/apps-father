import type { AgentTool } from "../AgentTool";
/**
 * All agent tool instances. Each exposes renderDefinition() (OpenAI schema)
 * and execute(args, ctx) (implementation). The AgentRunner builds the dispatch
 * map from these at run time.
 */
export declare const AGENT_TOOL_INSTANCES: AgentTool[];
/** OpenRouter server tools — executed transparently by OpenRouter. */
export declare const SERVER_TOOLS: any[];
//# sourceMappingURL=registry.d.ts.map