"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentLogger = void 0;
exports.parseAgentLog = parseAgentLog;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const PROJECTS_DIR = path_1.default.join(process.cwd(), "projects");
class AgentLogger {
    logPath;
    stream;
    startTime;
    currentIteration = 0;
    constructor(projectId) {
        const logsDir = path_1.default.join(PROJECTS_DIR, projectId, "logs");
        fs_1.default.mkdirSync(logsDir, { recursive: true });
        const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
        this.logPath = path_1.default.join(logsDir, `agent-${timestamp}.log`);
        this.stream = fs_1.default.createWriteStream(this.logPath, { flags: "a" });
        this.startTime = Date.now();
    }
    elapsed() {
        return Date.now() - this.startTime;
    }
    write(entry) {
        const full = {
            ts: new Date().toISOString(),
            elapsed: this.elapsed(),
            ...entry,
        };
        this.stream.write(JSON.stringify(full) + "\n");
    }
    header(model, prompt) {
        this.write({
            type: "header",
            model,
            prompt,
            startedAt: new Date().toISOString(),
        });
    }
    iteration(num, model) {
        this.currentIteration = num;
        this.write({ type: "iteration", iteration: num, model });
    }
    thinking(text) {
        if (!text.trim())
            return;
        this.write({ type: "thinking", iteration: this.currentIteration, text });
    }
    claudeMessage(text) {
        if (!text.trim())
            return;
        this.write({ type: "text", iteration: this.currentIteration, text });
    }
    toolCall(name, args) {
        this.write({
            type: "tool_call",
            iteration: this.currentIteration,
            tool: name,
            args,
        });
    }
    toolResult(name, result) {
        this.write({
            type: "tool_result",
            iteration: this.currentIteration,
            tool: name,
            result,
            resultLength: result.length,
        });
    }
    tokens(totalInput, totalOutput, totalCacheRead, totalCacheWrite, iterInput, iterOutput, iterCacheRead, iterCacheWrite, costUsd) {
        this.write({
            type: "tokens",
            iteration: this.currentIteration,
            total: { input: totalInput, output: totalOutput, cacheRead: totalCacheRead, cacheWrite: totalCacheWrite },
            iter: iterInput != null ? { input: iterInput, output: iterOutput, cacheRead: iterCacheRead, cacheWrite: iterCacheWrite } : undefined,
            costUsd,
        });
    }
    done(summary, iterations, totalInput, totalOutput) {
        this.write({
            type: "done",
            iterations,
            totalInput,
            totalOutput,
            summary,
            durationMs: this.elapsed(),
        });
    }
    error(message) {
        this.write({ type: "error", iteration: this.currentIteration, message });
    }
    close() {
        try {
            this.stream.end();
        }
        catch { }
    }
    getLogPath() {
        return this.logPath;
    }
    getRelativeLogPath(projectId) {
        return path_1.default.relative(path_1.default.join(PROJECTS_DIR, projectId), this.logPath);
    }
}
exports.AgentLogger = AgentLogger;
/**
 * Parse a JSONL agent log file into an array of entries.
 * Handles both new JSONL format and old plain-text format (returns raw text as a single entry).
 */
function parseAgentLog(logPath) {
    const content = fs_1.default.readFileSync(logPath, "utf-8");
    const lines = content.split("\n").filter(l => l.trim());
    if (lines.length === 0)
        return [];
    // Detect format: if the first line is valid JSON, it's JSONL
    try {
        JSON.parse(lines[0]);
    }
    catch {
        // Old plain-text format — wrap in a single entry
        return [{
                ts: new Date().toISOString(),
                elapsed: 0,
                type: "text",
                text: content,
                legacy: true,
            }];
    }
    const entries = [];
    for (const line of lines) {
        try {
            entries.push(JSON.parse(line));
        }
        catch { }
    }
    return entries;
}
//# sourceMappingURL=agent-logger.js.map