"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BUNDLE_CREDITS_PRICE = exports.BUNDLE_PRICE = exports.BUNDLE_FEATURES = exports.PAID_FEATURES = void 0;
exports.getBundleFullPrice = getBundleFullPrice;
exports.getBundleFullCreditsPrice = getBundleFullCreditsPrice;
exports.getBundleQuote = getBundleQuote;
exports.getFeatureById = getFeatureById;
exports.getProjectFeatures = getProjectFeatures;
exports.hasFeature = hasFeature;
exports.purchaseFeature = purchaseFeature;
exports.purchaseBundle = purchaseBundle;
const db_1 = require("../db");
const library_1 = require("@prisma/client/runtime/library");
// 1 USD ≈ 50 credits by default; creditsPrice = price * 50
exports.PAID_FEATURES = [
    { id: "stars_payment", label: "Stars Payment System", price: 15, creditsPrice: 750, description: "Enable Telegram Stars payment integration in your app" },
    { id: "ton_payment", label: "TON Payment System", price: 25, creditsPrice: 1250, description: "Enable TON blockchain payment integration in your app" },
    { id: "admin_panel", label: "Admin Panel", price: 30, creditsPrice: 1500, description: "Unlock the Admin Panel for your app" },
    { id: "disable_splash", label: "Disable Splash", price: 10, creditsPrice: 500, description: "Remove the 'Made by Apps Father' splash screen" },
    { id: "get_code", label: "Get Code", price: 50, creditsPrice: 2500, description: "Access and edit the source code of your app" },
];
const FEATURE_MAP = new Map(exports.PAID_FEATURES.map(f => [f.id, f]));
// "Get Everything" bundle — sold once per project at a flat discounted price.
// Includes every paid feature except admin_panel (which is hidden in the UI
// and managed separately).
exports.BUNDLE_FEATURES = [
    "stars_payment",
    "ton_payment",
    "disable_splash",
    "get_code",
];
exports.BUNDLE_PRICE = 50;
exports.BUNDLE_CREDITS_PRICE = 2000; // discounted bundle in credits
function getBundleFullPrice() {
    return exports.BUNDLE_FEATURES.reduce((sum, id) => sum + (FEATURE_MAP.get(id)?.price || 0), 0);
}
function getBundleFullCreditsPrice() {
    return exports.BUNDLE_FEATURES.reduce((sum, id) => sum + (FEATURE_MAP.get(id)?.creditsPrice || 0), 0);
}
/**
 * Quote the bundle for a given owned-features list.
 *
 * Behaviour:
 *  - If everything in BUNDLE_FEATURES is already owned → not available.
 *  - Otherwise the bundle covers only the still-missing features at a flat
 *    50% discount of their regular total. This way the offer keeps making
 *    sense even after the user bought one or two features individually
 *    (it's always a strictly better deal than buying the rest one by one).
 *  - When the bundle covers the full set we keep the headline price at the
 *    canonical $50 (in case rounding ever drifts), so the marketing
 *    "Get Everything for $50, save $50" still holds.
 */
function getBundleQuote(owned) {
    const missingIds = exports.BUNDLE_FEATURES.filter(id => !owned.includes(id));
    const fullPrice = missingIds.reduce((s, id) => s + (FEATURE_MAP.get(id)?.price || 0), 0);
    const isFullSet = missingIds.length === exports.BUNDLE_FEATURES.length;
    let bundlePrice = isFullSet ? exports.BUNDLE_PRICE : Math.round(fullPrice / 2);
    if (bundlePrice >= fullPrice)
        bundlePrice = Math.max(1, fullPrice - 1);
    const saveAmount = Math.max(0, fullPrice - bundlePrice);
    const fullCreditsPrice = missingIds.reduce((s, id) => s + (FEATURE_MAP.get(id)?.creditsPrice || 0), 0);
    let bundleCreditsPrice = isFullSet ? exports.BUNDLE_CREDITS_PRICE : Math.round(fullCreditsPrice / 2);
    if (bundleCreditsPrice >= fullCreditsPrice)
        bundleCreditsPrice = Math.max(1, fullCreditsPrice - 1);
    const saveCredits = Math.max(0, fullCreditsPrice - bundleCreditsPrice);
    return {
        missingIds,
        fullPrice,
        bundlePrice,
        saveAmount,
        fullCreditsPrice,
        bundleCreditsPrice,
        saveCredits,
        available: missingIds.length > 0,
    };
}
function getFeatureById(featureId) {
    return FEATURE_MAP.get(featureId);
}
async function getProjectFeatures(projectId) {
    const project = await db_1.prisma.project.findUnique({
        where: { id: projectId },
        select: { features: true },
    });
    if (!project?.features)
        return [];
    try {
        return JSON.parse(project.features);
    }
    catch {
        return [];
    }
}
async function hasFeature(projectId, featureId) {
    const features = await getProjectFeatures(projectId);
    return features.includes(featureId);
}
async function purchaseFeature(userId, projectId, featureId, payWith = "credits") {
    const feature = FEATURE_MAP.get(featureId);
    if (!feature)
        throw new Error("Unknown feature");
    const existing = await getProjectFeatures(projectId);
    if (existing.includes(featureId))
        throw new Error("Feature already purchased");
    const user = await db_1.prisma.user.findUnique({ where: { id: userId }, select: { balance: true, credits: true } });
    if (!user)
        throw new Error("User not found");
    const updated = [...existing, featureId];
    if (payWith === "credits") {
        if (user.credits < feature.creditsPrice)
            throw new Error("Insufficient credits");
        const result = await db_1.prisma.$transaction(async (tx) => {
            const updatedUser = await tx.user.update({
                where: { id: userId },
                data: { credits: { decrement: feature.creditsPrice } },
            });
            await tx.project.update({ where: { id: projectId }, data: { features: JSON.stringify(updated) } });
            return { newBalance: Number(updatedUser.balance), newCredits: updatedUser.credits };
        });
        return result;
    }
    else {
        if (Number(user.balance) < feature.price)
            throw new Error("Insufficient balance");
        const result = await db_1.prisma.$transaction(async (tx) => {
            const updatedUser = await tx.user.update({
                where: { id: userId },
                data: { balance: { decrement: new library_1.Decimal(feature.price.toFixed(4)) } },
            });
            await tx.project.update({ where: { id: projectId }, data: { features: JSON.stringify(updated) } });
            return { newBalance: Number(updatedUser.balance) };
        });
        return result;
    }
}
/**
 * Purchase the "Get Everything" bundle.
 *
 * Rules:
 *  - The bundle stays available until ALL bundle features are owned.
 *  - When some features are already owned, the bundle covers only the missing
 *    ones at the 50%-off price returned by getBundleQuote().
 *  - All missing BUNDLE_FEATURES are granted atomically; previously-owned
 *    features are kept untouched.
 */
async function purchaseBundle(userId, projectId, payWith = "credits") {
    const existing = await getProjectFeatures(projectId);
    const quote = getBundleQuote(existing);
    if (!quote.available || quote.missingIds.length === 0) {
        throw new Error("All bundle features already owned");
    }
    const user = await db_1.prisma.user.findUnique({ where: { id: userId }, select: { balance: true, credits: true } });
    if (!user)
        throw new Error("User not found");
    const updated = Array.from(new Set([...existing, ...quote.missingIds]));
    if (payWith === "credits") {
        if (user.credits < quote.bundleCreditsPrice)
            throw new Error("Insufficient credits");
        const result = await db_1.prisma.$transaction(async (tx) => {
            const updatedUser = await tx.user.update({
                where: { id: userId },
                data: { credits: { decrement: quote.bundleCreditsPrice } },
            });
            await tx.project.update({ where: { id: projectId }, data: { features: JSON.stringify(updated) } });
            return { newBalance: Number(updatedUser.balance), newCredits: updatedUser.credits, granted: quote.missingIds.slice(), charged: quote.bundleCreditsPrice };
        });
        return result;
    }
    else {
        if (Number(user.balance) < quote.bundlePrice)
            throw new Error("Insufficient balance");
        const result = await db_1.prisma.$transaction(async (tx) => {
            const updatedUser = await tx.user.update({
                where: { id: userId },
                data: { balance: { decrement: new library_1.Decimal(quote.bundlePrice.toFixed(4)) } },
            });
            await tx.project.update({ where: { id: projectId }, data: { features: JSON.stringify(updated) } });
            return { newBalance: Number(updatedUser.balance), granted: quote.missingIds.slice(), charged: quote.bundlePrice };
        });
        return result;
    }
}
//# sourceMappingURL=features.service.js.map