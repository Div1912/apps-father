import { Request, Response, NextFunction } from "express";
export declare function verifyInitData(req: Request, res: Response, next: NextFunction): Promise<void>;
//# sourceMappingURL=initdata.d.ts.map