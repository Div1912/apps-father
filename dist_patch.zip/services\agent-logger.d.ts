export interface LogEntry {
    ts: string;
    elapsed: number;
    type: "header" | "iteration" | "thinking" | "text" | "tool_call" | "tool_result" | "tokens" | "done" | "error";
    [key: string]: any;
}
export declare class AgentLogger {
    private logPath;
    private stream;
    private startTime;
    private currentIteration;
    constructor(projectId: string);
    private elapsed;
    private write;
    header(model: string, prompt: string): void;
    iteration(num: number, model: string): void;
    thinking(text: string): void;
    claudeMessage(text: string): void;
    toolCall(name: string, args: any): void;
    toolResult(name: string, result: string): void;
    tokens(totalInput: number, totalOutput: number, totalCacheRead: number, totalCacheWrite: number, iterInput?: number, iterOutput?: number, iterCacheRead?: number, iterCacheWrite?: number, costUsd?: number): void;
    done(summary: string, iterations: number, totalInput: number, totalOutput: number): void;
    error(message: string): void;
    close(): void;
    getLogPath(): string;
    getRelativeLogPath(projectId: string): string;
}
/**
 * Parse a JSONL agent log file into an array of entries.
 * Handles both new JSONL format and old plain-text format (returns raw text as a single entry).
 */
export declare function parseAgentLog(logPath: string): LogEntry[];
//# sourceMappingURL=agent-logger.d.ts.map