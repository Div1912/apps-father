"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.signDesktopToken = signDesktopToken;
exports.verifyDesktopToken = verifyDesktopToken;
const crypto_1 = __importDefault(require("crypto"));
const config_1 = require("../config");
const DESKTOP_TOKEN_SECRET = crypto_1.default.createHmac("sha256", "DesktopAuth").update(config_1.config.botToken).digest();
function signDesktopToken(payload) {
    const data = Buffer.from(JSON.stringify(payload)).toString("base64url");
    const sig = crypto_1.default.createHmac("sha256", DESKTOP_TOKEN_SECRET).update(data).digest("base64url");
    return `${data}.${sig}`;
}
function verifyDesktopToken(token) {
    try {
        const [data, sig] = token.split(".");
        if (!data || !sig)
            return { valid: false };
        const expected = crypto_1.default.createHmac("sha256", DESKTOP_TOKEN_SECRET).update(data).digest("base64url");
        if (sig !== expected)
            return { valid: false };
        const payload = JSON.parse(Buffer.from(data, "base64url").toString());
        if (!payload.telegramId)
            return { valid: false };
        return { valid: true, telegramId: payload.telegramId, username: payload.username, firstName: payload.firstName };
    }
    catch {
        return { valid: false };
    }
}
//# sourceMappingURL=desktop-auth.js.map