import { BotContext } from "../../types";
export declare function newProjectCommand(ctx: BotContext): Promise<void>;
//# sourceMappingURL=newproject.d.ts.map