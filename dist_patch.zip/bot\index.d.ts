import { Bot } from "grammy";
import { BotContext } from "../types";
export declare function createBot(): Bot<BotContext>;
//# sourceMappingURL=index.d.ts.map