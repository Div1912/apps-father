import { type AgentComplexity } from "./runtime-config.service";
import { type AgentResult, type AgentProgress } from "./agent.service";
import { type RouterChatHooks } from "./agent/tools/impl/router";
interface SessionLogOpts {
    type: string;
    projectId?: string | null;
    userId?: number | null;
    model: string;
    input: string;
    output?: string;
    creditsCharged?: number;
    /** Authoritative aggregate cost (sum of OR `usage.cost` per iteration). */
    costUsd?: number;
    /** Input slice of costUsd (sum of upstream_inference_prompt_cost). */
    costUsdInput?: number;
    /** Output slice of costUsd (sum of upstream_inference_completions_cost). */
    costUsdOutput?: number;
    inputTokens?: number;
    outputTokens?: number;
    durationMs?: number;
    success?: boolean;
    complexity?: string | null;
    isMaxMode?: boolean;
}
/**
 * Optional extras that propagate from the proposal card into the session.
 * Threaded as a single object so we don't grow the positional arg list every
 * time we add a new piece of metadata to log.
 */
export interface SessionExtras {
    creditsCharged?: number;
    maxMode?: boolean;
    complexity?: AgentComplexity | string | null;
}
declare class AgentSessionService {
    session_router(projectId: string, userMessage: string, hooks: RouterChatHooks, conversationHistory?: {
        role: "user" | "assistant";
        content: string;
    }[], lang?: string, onToolCall?: (toolName: string) => void): Promise<{
        proposed: boolean;
        text: string;
        inputTokens: number;
        outputTokens: number;
        modelId: string;
        isFirstMessage: boolean;
    }>;
    session_answer(projectId: string, question: string, onChunk: (text: string, fullText: string) => void, lastUpdate?: string, appDescription?: string, conversationHistory?: {
        role: "user" | "assistant";
        content: string;
    }[], lang?: string): Promise<{
        text: string;
        inputTokens: number;
        outputTokens: number;
    }>;
    session_suggestions(projectId: string, lang?: string): Promise<{
        title: string;
        description: string;
    }[]>;
    session_build(projectId: string, buildArgs: {
        name?: string;
        description?: string;
        brief?: string;
        userPrompt?: string;
    } | string, onProgress?: (p: AgentProgress) => Promise<void>, onAskUser?: (question: string, options: string[]) => Promise<string>, lang?: string, userBalance?: number, attachments?: {
        localPath: string;
        projectPath: string;
        originalName: string;
        caption?: string;
    }[], extras?: SessionExtras | number): Promise<AgentResult>;
    session_update(projectId: string, updateDescription: string, onProgress?: (p: AgentProgress) => Promise<void>, attachments?: {
        localPath: string;
        projectPath: string;
        originalName: string;
        caption?: string;
    }[], onAskUser?: (question: string, options: string[]) => Promise<string>, lang?: string, userBalance?: number, extras?: SessionExtras | number): Promise<AgentResult>;
    compactContext(projectId: string, commitDir: string, doneSummary: string, commitNum: number, description?: string, plan?: string, contextDiff?: string): Promise<string>;
    regenerateContext(projectId: string): Promise<string>;
    /**
     * Wrapper around `logSession` that fills in `costUsd` from the static
     * model-pricing catalog when callers don't pass an authoritative one.
     * If the caller already has the OpenRouter-reported cost (preferred)
     * pass it via `opts.costUsd` and we skip the catalog lookup entirely.
     */
    private _logWithCost;
    logSession(opts: SessionLogOpts): Promise<void>;
    private _runCoreAgent;
    private _generatePassport;
    private _appendPassportDelta;
    private _bustCache;
    private _getProjectCode;
}
export declare const agentSessionService: AgentSessionService;
export {};
//# sourceMappingURL=agent-session.service.d.ts.map