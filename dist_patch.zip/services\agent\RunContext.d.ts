import type { AgentLogger } from "../agent-logger";
import type { AgentMode } from "./types";
import type { AgentProgress, AgentResult, AgentStepKind } from "../agent.service";
export interface RunContextParams {
    projectId: string;
    projectDir: string;
    projectRootDir: string;
    commitDir: string;
    commitNum: number;
    mode: AgentMode;
    botToken: string;
    tierConfig: any;
    taskId: string;
    selectedWorkflow: string;
    logger: AgentLogger;
    onAskUser?: (question: string, options: string[]) => Promise<string>;
    rawProgress: (p: AgentProgress) => Promise<void>;
}
export declare class RunContext {
    readonly projectId: string;
    readonly projectDir: string;
    readonly projectRootDir: string;
    readonly commitDir: string;
    readonly commitNum: number;
    readonly mode: AgentMode;
    readonly botToken: string;
    readonly tierConfig: any;
    readonly taskId: string;
    readonly selectedWorkflow: string;
    readonly logger: AgentLogger;
    readonly onAskUser?: (question: string, options: string[]) => Promise<string>;
    private readonly _rawProgress;
    wroteFiles: boolean;
    deployed: boolean;
    finished: boolean;
    configuredApp: boolean;
    deployCount: number;
    deployLocked: boolean;
    technicalPlan: any;
    technicalPlanSubmitted: boolean;
    testsRun: {
        telegram: boolean;
        api: boolean;
        ws: boolean;
    };
    wsCoverage: {
        types: Set<string>;
        scenarios: Set<string>;
    };
    loadedSkills: Set<string>;
    validatorResults: Array<{
        stage: string;
        ok: boolean;
        message?: string;
    }>;
    testResults: Array<{
        tool: string;
        ok: boolean;
        detail: string;
    }>;
    lastWsFailureSignature: string;
    repeatedWsFailureCount: number;
    summary: string;
    shortSummary: string;
    contextDiff: string;
    consecutiveNoWrite: number;
    totalInputTokens: number;
    totalOutputTokens: number;
    totalCacheWriteTokens: number;
    totalCacheReadTokens: number;
    liveCostUsd: number;
    /**
     * Authoritative USD cost reported by OpenRouter (sum of `usage.cost`
     * across iterations). Preferred over the token×price-table estimate when
     * non-zero. Filled when the request opts into usage accounting via
     * `extra_body.usage = { include: true }`.
     */
    totalCostUsd: number;
    /** Sum of `usage.cost_details.upstream_inference_prompt_cost`. */
    totalCostUsdInput: number;
    /** Sum of `usage.cost_details.upstream_inference_completions_cost`. */
    totalCostUsdOutput: number;
    readonly startBalance: number;
    currentPercent: number | undefined;
    readonly runStartMs: number;
    stepCounter: number;
    /** Set by FinishTool to stop the runner loop and return this result. */
    terminalResult: AgentResult | null;
    detailedEntries: Array<{
        iteration: number;
        timestamp: string;
        request: any;
        response: any;
    }>;
    constructor(params: RunContextParams, userBalance?: number);
    progress(p: AgentProgress): Promise<void>;
    newStepId(prefix: string): string;
    emitStepStart(kind: AgentStepKind, title: string, toolName: string, target?: AgentProgress["target"]): Promise<string>;
    emitStepEnd(stepId: string, status: "ok" | "error", meta?: Record<string, any>): Promise<void>;
    emitNarrationStart(stepId: string): Promise<void>;
    emitNarrationChunk(stepId: string, delta: string, text: string): Promise<void>;
    emitNarrationEnd(stepId: string): Promise<void>;
    emitWritingChunk(stepId: string, toolName: string, argsDelta: string, argsFull: string): Promise<void>;
    /** Called by FinishTool to stop the runner loop. */
    terminate(result: AgentResult): void;
    writeDetailedLog(reason: string): void;
}
//# sourceMappingURL=RunContext.d.ts.map