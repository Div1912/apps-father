"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentRunner = void 0;
const openrouter_service_1 = require("../openrouter.service");
const processing_1 = require("../../bot/processing");
const agent_service_1 = require("../agent.service");
const TOOL_DISPLAY = {
    list_files: { kind: "searching", title: "Scanning files" },
    read_file: { kind: "reading", title: "Reading", targetKey: "path", targetField: "file" },
    write_file: { kind: "writing", title: "Writing", targetKey: "path", targetField: "file" },
    edit_file: { kind: "editing", title: "Editing", targetKey: "path", targetField: "file" },
    grep: { kind: "searching", title: "Searching", targetKey: "pattern", targetField: "key" },
    shell: { kind: "shell", title: "Running command", targetKey: "command", targetField: "key" },
    fetch_url: { kind: "fetch", title: "Fetching URL", targetKey: "url", targetField: "url" },
    db: { kind: "db", title: "Database", targetKey: "key", targetField: "key" },
    deploy_to_dev: { kind: "deploying", title: "Deploying to dev" },
    load_skill: { kind: "skill", title: "Loading skill", targetKey: "name", targetField: "key" },
    ask_user: { kind: "ask", title: "Waiting for your answer" },
    technical_plan: { kind: "thinking", title: "Technical plan", targetKey: "kind", targetField: "key" },
    configure_app: { kind: "configuring", title: "Configuring app" },
    finish: { kind: "done", title: "Finishing" },
    server_logs: { kind: "searching", title: "Reading logs" },
    simulate_telegram: { kind: "telegram", title: "Simulating bot message" },
    simulate_api: { kind: "fetch", title: "Simulating API call" },
    simulate_ws: { kind: "shell", title: "Simulating WebSocket" },
    visual_test: { kind: "visual", title: "Visual test", targetKey: "path", targetField: "url" },
    image_generate: { kind: "visual", title: "Generating image", targetKey: "filename", targetField: "file" },
};
function buildToolStepTarget(toolName, args) {
    const cfg = TOOL_DISPLAY[toolName];
    if (!cfg?.targetKey)
        return undefined;
    const raw = args?.[cfg.targetKey];
    if (typeof raw !== "string" || !raw)
        return undefined;
    const trimmed = raw.length > 200 ? raw.slice(0, 197) + "..." : raw;
    const field = cfg.targetField || "file";
    return { [field]: trimmed };
}
function summarizeToolArgs(toolName, args) {
    switch (toolName) {
        case "list_files": return "";
        case "read_file": return args.offset ? `${args.path}:${args.offset}-${args.offset + (args.limit || 0)}` : args.path;
        case "write_file": return `${args.path}, ${(args.content || "").length} chars`;
        case "edit_file": return `${args.path}, "${(args.old_string || "").substring(0, 40)}..." -> "${(args.new_string || "").substring(0, 40)}..."`;
        case "grep": return `"${args.pattern}"${args.path ? ` in ${args.path}` : ""}${args.include ? ` (${args.include})` : ""}`;
        case "shell": return args.command?.substring(0, 80) || "";
        case "fetch_url": return args.url || "";
        case "db": return `${args.operation}(${args.key || ""})${args.value ? ", " + JSON.stringify(args.value).substring(0, 60) : ""}`;
        case "load_skill": return args.name || "";
        case "ask_user": return (args.question || "").substring(0, 60);
        case "technical_plan": return `${args.kind || "app"}: ${(args.summary || "").substring(0, 80)}`;
        case "configure_app": return args.name || "";
        case "server_logs": return `${args.lines || 50} lines`;
        case "simulate_telegram": return args.update?.message?.text || args.update?.callback_query?.data || "update";
        case "simulate_api": return `${args.method || "GET"} ${args.path}`;
        case "simulate_ws": return args.scenarioId || `${Array.isArray(args.messages) ? args.messages.length : 0} message(s)`;
        case "deploy_to_dev": return "";
        case "visual_test": return args.path || "/";
        case "finish": return (args.shortSummary || args.summary || "").substring(0, 80);
        default: return JSON.stringify(args).substring(0, 80);
    }
}
class AgentRunner {
    _ctx;
    _systemPrompt = "";
    _tools = [];
    _rawToolDefs = [];
    _messages = [];
    setContext(ctx) {
        this._ctx = ctx;
        return this;
    }
    setSystemPrompt(p) {
        this._systemPrompt = p;
        return this;
    }
    setTools(tools) {
        this._tools = tools;
        return this;
    }
    setMessages(msgs) {
        this._messages = msgs;
        return this;
    }
    /** Extra OpenAI-format tool definitions to append (e.g. SERVER_TOOLS). */
    setRawToolDefs(defs) {
        this._rawToolDefs = defs;
        return this;
    }
    async run() {
        const ctx = this._ctx;
        const { tierConfig } = ctx;
        // Build a fast name→tool dispatch map from renderDefinition().function.name
        const toolMap = new Map();
        const openAiTools = [];
        for (const t of this._tools) {
            const def = t.renderDefinition();
            const name = def.function?.name;
            toolMap.set(name, t);
            openAiTools.push(def);
        }
        // Append raw tool definitions (e.g. OpenRouter server tools)
        const allTools = [...openAiTools, ...this._rawToolDefs];
        const maxIterations = tierConfig.maxIterations ?? 60;
        let iterations = 0;
        while (iterations < maxIterations) {
            // ── Abort check ───────────────────────────────────────────────────────
            if (processing_1.abortedProjects.has(ctx.projectId)) {
                processing_1.abortedProjects.delete(ctx.projectId);
                ctx.logger.done("ABORTED by user", iterations, ctx.totalInputTokens, ctx.totalOutputTokens);
                ctx.writeDetailedLog("aborted");
                console.log(`[Agent] ⛔ Aborted by user after ${iterations} iterations | in=${ctx.totalInputTokens} out=${ctx.totalOutputTokens}`);
                throw new agent_service_1.AgentAbortedError(tierConfig.modelId, ctx.totalInputTokens, ctx.totalOutputTokens, ctx.totalCacheWriteTokens, ctx.totalCacheReadTokens);
            }
            iterations++;
            // ── Build request payload ─────────────────────────────────────────────
            const thinkingBudget = tierConfig.thinkingBudget ?? 0;
            const reasoningBudget = tierConfig.reasoningBudget ?? 0;
            const agentTelegramId = ctx._telegramId;
            const requestMessages = this._applyCacheBreakpoint(tierConfig.modelId, this._systemPrompt, this._messages);
            const requestPayload = {
                model: tierConfig.modelId,
                max_tokens: tierConfig.maxTokens,
                messages: requestMessages,
                tools: allTools,
                tool_choice: "auto",
                ...(agentTelegramId ? { user: agentTelegramId } : {}),
                extra_body: {
                    session_id: ctx.taskId,
                    // Ask OpenRouter to attach `usage.cost` and `usage.cost_details` to
                    // every response. Without this the response.usage block only carries
                    // token counts, and we'd have to reconstruct the price from the
                    // catalog (which goes stale and misses cache-read discounts).
                    usage: { include: true },
                    ...(thinkingBudget > 0 ? { thinking: { type: "enabled", budget_tokens: thinkingBudget } } : {}),
                },
                ...(this._getProviderRouting(tierConfig.modelId, tierConfig.provider)
                    ? { provider: this._getProviderRouting(tierConfig.modelId, tierConfig.provider) }
                    : {}),
                ...(reasoningBudget > 0 ? { reasoning: { max_tokens: reasoningBudget } } : {}),
            };
            // ── Stream / call ─────────────────────────────────────────────────────
            const streamingEnabled = tierConfig.streaming !== false;
            const iterStepId = `iter-${iterations}-${Date.now().toString(36)}`;
            let narrationOpen = false;
            let response;
            try {
                if (streamingEnabled) {
                    try {
                        await ctx.emitNarrationStart(iterStepId);
                        narrationOpen = true;
                        let narrationAccum = "";
                        response = await this._streamAgentCall(requestPayload, {
                            onTextDelta: (delta) => {
                                narrationAccum += delta;
                                void ctx.emitNarrationChunk(iterStepId, delta, narrationAccum);
                            },
                            onReasoningDelta: (delta) => {
                                narrationAccum += delta;
                                void ctx.emitNarrationChunk(iterStepId, delta, narrationAccum);
                            },
                            onToolArgsDelta: (toolName, argsDelta, argsFull) => {
                                void ctx.emitWritingChunk(iterStepId, toolName, argsDelta, argsFull);
                            },
                        });
                        await ctx.emitNarrationEnd(iterStepId);
                        narrationOpen = false;
                        if (this._isEmptyResponse(response)) {
                            console.warn(`[Agent] stream returned empty response, falling back to non-stream`);
                            response = await this._callWithRetry(requestPayload);
                        }
                    }
                    catch (streamErr) {
                        if (narrationOpen) {
                            await ctx.emitNarrationEnd(iterStepId);
                            narrationOpen = false;
                        }
                        console.warn(`[Agent] stream failed (${streamErr?.message}), falling back to non-stream`);
                        // Brief pause before fallback — gives the network a moment to stabilize
                        await new Promise(r => setTimeout(r, 1500));
                        response = await this._callWithRetry(requestPayload);
                    }
                }
                else {
                    response = await this._callWithRetry(requestPayload);
                }
            }
            catch (apiErr) {
                if (narrationOpen) {
                    try {
                        await ctx.emitNarrationEnd(iterStepId);
                    }
                    catch { }
                }
                try {
                    ctx.detailedEntries.push({
                        iteration: iterations,
                        timestamp: new Date().toISOString(),
                        request: this._cloneSafe(requestPayload),
                        response: { error: { name: apiErr?.name, message: apiErr?.message, status: apiErr?.status, body: apiErr?.error || apiErr?.response } },
                    });
                }
                catch { }
                ctx.writeDetailedLog("api_error");
                throw apiErr;
            }
            // ── Record detailed entry ─────────────────────────────────────────────
            try {
                ctx.detailedEntries.push({
                    iteration: iterations,
                    timestamp: new Date().toISOString(),
                    request: this._cloneSafe(requestPayload),
                    response: this._cloneSafe(response),
                });
            }
            catch (err) {
                console.warn(`[Agent] detailed-log clone failed at iter ${iterations}: ${err.message}`);
            }
            // ── Token accounting ──────────────────────────────────────────────────
            const usage = response.usage;
            const iterIn = usage?.prompt_tokens || 0;
            const iterOut = usage?.completion_tokens || 0;
            const cached = usage?.prompt_tokens_details?.cached_tokens || 0;
            ctx.totalInputTokens += iterIn - cached;
            ctx.totalOutputTokens += iterOut;
            ctx.totalCacheReadTokens += cached;
            // Authoritative cost from OpenRouter — when the model returns it,
            // this is the dollar amount actually charged by upstream and is what
            // we want to show in admin Sessions. Falls back to the token×catalog
            // estimate below when the response didn't include cost (e.g. older
            // providers that ignore the `usage.include` flag).
            const iterCost = Number(usage?.cost) || 0;
            const iterCostIn = Number(usage?.cost_details?.upstream_inference_prompt_cost) || 0;
            const iterCostOut = Number(usage?.cost_details?.upstream_inference_completions_cost) || 0;
            ctx.totalCostUsd += iterCost;
            ctx.totalCostUsdInput += iterCostIn;
            ctx.totalCostUsdOutput += iterCostOut;
            const pricing = ctx._agentPricing;
            ctx.liveCostUsd = ctx.totalCostUsd > 0
                ? ctx.totalCostUsd
                : (ctx.totalInputTokens * pricing.input +
                    ctx.totalOutputTokens * pricing.output +
                    ctx.totalCacheWriteTokens * pricing.cache_write +
                    ctx.totalCacheReadTokens * pricing.cache_read);
            // ── Parse assistant message ───────────────────────────────────────────
            const assistantMsg = response.choices?.[0]?.message;
            const assistantToolCalls = assistantMsg?.tool_calls || [];
            const assistantText = assistantMsg?.content || "";
            const reasoning = assistantMsg?.reasoning_content || assistantMsg?.reasoning || "";
            this._messages.push({
                role: "assistant",
                content: assistantText,
                tool_calls: assistantToolCalls.length > 0 ? assistantToolCalls : undefined,
            });
            ctx.logger.iteration(iterations, tierConfig.modelId);
            ctx.logger.tokens(ctx.totalInputTokens, ctx.totalOutputTokens, ctx.totalCacheReadTokens, ctx.totalCacheWriteTokens, iterIn, iterOut, cached, 0, ctx.liveCostUsd);
            if (reasoning?.trim()) {
                ctx.logger.thinking(reasoning);
                console.log(`[Agent] 🧠 Thinking: ${reasoning.substring(0, 300).replace(/\n/g, " ")}${reasoning.length > 300 ? "..." : ""}`);
            }
            if (assistantText?.trim()) {
                ctx.logger.claudeMessage(assistantText);
                console.log(`[Agent] 💬 Claude says: ${assistantText.substring(0, 500)}`);
            }
            if (assistantToolCalls.length > 0) {
                const toolNames = assistantToolCalls.map((tc) => tc.function?.name).join(", ");
                console.log(`[Agent] 🔧 Iteration ${iterations} | Tools: [${toolNames}] | in=${ctx.totalInputTokens} out=${ctx.totalOutputTokens} | finish=${response.choices?.[0]?.finish_reason}`);
            }
            // ── No tool calls ─────────────────────────────────────────────────────
            if (assistantToolCalls.length === 0) {
                if (ctx.mode === "new" && (!ctx.technicalPlanSubmitted || !ctx.wroteFiles || !ctx.deployed)) {
                    ctx.consecutiveNoWrite++;
                    const needed = [
                        !ctx.technicalPlanSubmitted ? "call technical_plan first" : "",
                        !ctx.wroteFiles ? "write the required project files with write_file/edit_file" : "",
                        !ctx.deployed ? "call deploy_to_dev after writing files" : "",
                    ].filter(Boolean).join(", ");
                    const corrective = `You responded with text only, but this is a build run and text does not create files. Continue now with tool calls only: ${needed}. Do not finish until validators pass and required simulate_* tests are done.`;
                    this._messages.push({ role: "user", content: corrective });
                    ctx.writeDetailedLog("end_turn_no_tools_retry");
                    console.warn(`[Agent] no-tool turn during new build; injected corrective prompt (${ctx.consecutiveNoWrite})`);
                    continue;
                }
                if (assistantText)
                    ctx.summary = assistantText;
                ctx.logger.done(ctx.summary, iterations, ctx.totalInputTokens, ctx.totalOutputTokens);
                ctx.writeDetailedLog("end_turn_no_tools");
                console.log(`[Agent] ⏹️ Agent finished after ${iterations} iterations | in=${ctx.totalInputTokens} out=${ctx.totalOutputTokens}`);
                break;
            }
            // ── Process tool calls ────────────────────────────────────────────────
            const TERMINAL_TOOLS = new Set(["done", "finish"]);
            const orderedToolCalls = [
                ...assistantToolCalls.filter((tc) => !TERMINAL_TOOLS.has(tc.function?.name)),
                ...assistantToolCalls.filter((tc) => TERMINAL_TOOLS.has(tc.function?.name)),
            ];
            const toolResults = [];
            for (const toolCall of orderedToolCalls) {
                const id = toolCall.id;
                let name = toolCall.function?.name;
                let args;
                let argsTruncated = false;
                const rawArgs = toolCall.function?.arguments || "{}";
                try {
                    args = JSON.parse(rawArgs);
                }
                catch {
                    // JSON truncated by max_tokens — pass empty args and let the tool handle it
                    args = {};
                    argsTruncated = true;
                }
                // Canonicalize inline-argument calls (e.g. load_skill("frontend"))
                const inlineArgMatch = name?.match(/^(\w+)\("([^"]+)"\)$/);
                if (inlineArgMatch) {
                    const [, baseName, inlineArg] = inlineArgMatch;
                    if (baseName === "load_skill" && !args.name) {
                        name = "load_skill";
                        args = { ...args, name: inlineArg };
                    }
                }
                // OpenRouter server tools are executed transparently; skip gracefully
                if (name && name.startsWith("openrouter:")) {
                    this._messages.push({ role: "tool", tool_call_id: id, content: `OK: server tool ${name} handled by OpenRouter.` });
                    continue;
                }
                const argsSummary = summarizeToolArgs(name, args);
                ctx.logger.toolCall(name, args);
                const stepKindCfg = TOOL_DISPLAY[name] || { kind: "thinking", title: name };
                const stepTarget = buildToolStepTarget(name, args);
                const stepId = await ctx.emitStepStart(stepKindCfg.kind, stepKindCfg.title, name, stepTarget);
                let result = "";
                try {
                    const tool = toolMap.get(name);
                    if (!tool) {
                        result = `Error: Unknown tool ${name}`;
                    }
                    else {
                        result = await tool.execute(args, ctx);
                    }
                }
                catch (err) {
                    result = `Error: ${err.message}`;
                    console.error(`[Agent] ❌ Tool ${name} error:`, err.message);
                }
                ctx.logger.toolResult(name, result);
                console.log(`[Agent] 📥 ${name}(${argsSummary}) -> ${result.substring(0, 200).replace(/\n/g, "\\n")}${result.length > 200 ? "..." : ""}`);
                toolResults.push({ role: "tool", tool_call_id: id, content: result });
                // Compute step metadata for the step_end event
                const tool = toolMap.get(name);
                let stepMeta = {};
                try {
                    if (tool?.getStepMeta) {
                        stepMeta = tool.getStepMeta(args, result);
                    }
                    else {
                        stepMeta = this._defaultStepMeta(name, args, ctx);
                    }
                    if (result.startsWith("Error")) {
                        stepMeta.error = result.replace(/^Error:?\s*/i, "").slice(0, 200);
                    }
                }
                catch { }
                const stepStatus = result.startsWith("Error") ? "error" : "ok";
                await ctx.emitStepEnd(stepId, stepStatus, Object.keys(stepMeta).length ? stepMeta : undefined);
                // If finish() called ctx.terminate(), push remaining results and return
                if (ctx.terminalResult) {
                    toolResults.push(...toolResults.splice(0)); // flush into array (already there)
                    for (const tr of toolResults)
                        this._messages.push(tr);
                    return ctx.terminalResult;
                }
            }
            for (const tr of toolResults)
                this._messages.push(tr);
            const msgSize = JSON.stringify(this._messages).length;
            const estimatedTokens = Math.round(msgSize / 4);
            console.log(`[Agent] 📊 Iter ${iterations} | Messages: ${this._messages.length} | ~${estimatedTokens} tokens | Cost: $${ctx.liveCostUsd.toFixed(4)}`);
        }
        // Iteration limit reached — return without finish()
        return null;
    }
    // ── Private helpers ───────────────────────────────────────────────────────
    _getProviderRouting(modelId, provider) {
        const sel = provider?.trim();
        if (sel)
            return { only: [sel], allow_fallbacks: false };
        return undefined;
    }
    _isClaudeModel(modelId) {
        return /(?:^|\/)claude/i.test(modelId) || /anthropic\/claude/i.test(modelId);
    }
    _isEmptyResponse(response) {
        const choices = Array.isArray(response?.choices) ? response.choices : [];
        const msg = choices[0]?.message;
        const toolCalls = msg?.tool_calls || [];
        const content = typeof msg?.content === "string" ? msg.content : "";
        const reasoning = msg?.reasoning_content || msg?.reasoning || "";
        const completionTokens = response.usage?.completion_tokens || 0;
        return choices.length === 0 || (toolCalls.length === 0 && !content.trim() && !String(reasoning || "").trim() && completionTokens === 0);
    }
    _invalidResponseReason(response) {
        if (!response || typeof response !== "object")
            return "response is not an object";
        if (!Array.isArray(response.choices))
            return "response.choices is missing or not an array";
        if (response.choices.length === 0)
            return "response.choices is empty";
        if (!response.choices[0]?.message)
            return "response.choices[0].message is missing";
        return null;
    }
    async _callWithRetry(params, maxRetries = 3) {
        const client = (0, openrouter_service_1.getOpenRouterClient)();
        for (let attempt = 0; attempt <= maxRetries; attempt++) {
            try {
                const response = await client.chat.completions.create(params);
                const invalidReason = this._invalidResponseReason(response);
                if (invalidReason && attempt < maxRetries) {
                    const delay = Math.min(1000 * Math.pow(2, attempt), 8000);
                    console.warn(`[Agent] Malformed model response (${invalidReason}). Retry ${attempt + 1}/${maxRetries} after ${delay}ms`);
                    await new Promise(r => setTimeout(r, delay));
                    continue;
                }
                if (invalidReason)
                    throw new Error(`Malformed model response from ${params.model}: ${invalidReason}`);
                if (this._isEmptyResponse(response) && attempt < maxRetries) {
                    const delay = Math.min(1000 * Math.pow(2, attempt), 8000);
                    console.warn(`[Agent] Empty model response. Retry ${attempt + 1}/${maxRetries} after ${delay}ms`);
                    await new Promise(r => setTimeout(r, delay));
                    continue;
                }
                if (this._isEmptyResponse(response))
                    throw new Error(`Empty model response from ${params.model}`);
                return response;
            }
            catch (err) {
                const status = err?.status || err?.error?.status;
                const msg = String(err?.message || "");
                const isNetworkOrParseError = !status && (err instanceof SyntaxError ||
                    /truncated|parse error|unexpected end|network|connection|ECONNRESET|ETIMEDOUT|fetch failed|socket/i.test(msg));
                if (status === 429 && attempt < maxRetries) {
                    const retryAfter = parseInt(err?.headers?.["retry-after"] || "0", 10);
                    const delay = retryAfter > 0 ? retryAfter * 1000 : Math.min(2000 * Math.pow(2, attempt), 30000);
                    console.log(`[Agent] Rate limited (429). Retry ${attempt + 1}/${maxRetries} after ${delay}ms`);
                    await new Promise(r => setTimeout(r, delay));
                    continue;
                }
                if (isNetworkOrParseError && attempt < maxRetries) {
                    const delay = Math.min(2000 * Math.pow(2, attempt), 16000);
                    console.warn(`[Agent] Network/parse error (${msg.substring(0, 80)}). Retry ${attempt + 1}/${maxRetries} after ${delay}ms`);
                    await new Promise(r => setTimeout(r, delay));
                    continue;
                }
                throw err;
            }
        }
        throw new Error("Max retries exceeded");
    }
    async _streamAgentCall(params, opts = {}) {
        const client = (0, openrouter_service_1.getOpenRouterClient)();
        const stream = (await client.chat.completions.create({ ...params, stream: true, stream_options: { include_usage: true } }));
        let assistantText = "";
        let reasoning = "";
        const toolCallAcc = new Map();
        let usage;
        let finishReason = null;
        let modelEcho;
        let id;
        for await (const chunk of stream) {
            if (!chunk)
                continue;
            if (chunk.id)
                id = chunk.id;
            if (chunk.model)
                modelEcho = chunk.model;
            if (chunk.usage)
                usage = chunk.usage;
            const choice = chunk.choices?.[0];
            if (!choice)
                continue;
            const delta = choice.delta || {};
            if (typeof delta.content === "string" && delta.content.length > 0) {
                assistantText += delta.content;
                try {
                    opts.onTextDelta?.(delta.content, assistantText);
                }
                catch { }
            }
            const reasonDelta = delta.reasoning_content || delta.reasoning;
            if (typeof reasonDelta === "string" && reasonDelta.length > 0) {
                reasoning += reasonDelta;
                try {
                    opts.onReasoningDelta?.(reasonDelta, reasoning);
                }
                catch { }
            }
            if (Array.isArray(delta.tool_calls)) {
                for (const tc of delta.tool_calls) {
                    const idx = typeof tc.index === "number" ? tc.index : 0;
                    const acc = toolCallAcc.get(idx) || { name: "", args: "" };
                    if (tc.id)
                        acc.id = tc.id;
                    if (tc.function?.name)
                        acc.name = (acc.name || "") + tc.function.name;
                    if (tc.function?.arguments) {
                        acc.args += tc.function.arguments;
                        try {
                            opts.onToolArgsDelta?.(acc.name, tc.function.arguments, acc.args);
                        }
                        catch { }
                    }
                    toolCallAcc.set(idx, acc);
                }
            }
            if (choice.finish_reason)
                finishReason = choice.finish_reason;
        }
        const tool_calls = [...toolCallAcc.entries()]
            .sort((a, b) => a[0] - b[0])
            .map(([idx, v]) => ({ id: v.id || `call_${idx}`, type: "function", function: { name: v.name || "", arguments: v.args || "{}" } }));
        const fakeMessage = { role: "assistant", content: assistantText };
        if (tool_calls.length > 0)
            fakeMessage.tool_calls = tool_calls;
        if (reasoning)
            fakeMessage.reasoning_content = reasoning;
        return {
            id: id || "stream",
            object: "chat.completion",
            created: Math.floor(Date.now() / 1000),
            model: modelEcho || params.model,
            choices: [{
                    index: 0,
                    message: fakeMessage,
                    finish_reason: (finishReason || (tool_calls.length > 0 ? "tool_calls" : "stop")),
                    logprobs: null,
                }],
            usage,
        };
    }
    _attachCacheControlToContent(content) {
        const cacheControl = { type: "ephemeral" };
        if (typeof content === "string") {
            const text = content.trim();
            if (!text)
                return content;
            return [{ type: "text", text: content, cache_control: cacheControl }];
        }
        if (!Array.isArray(content))
            return content;
        const blocks = content.map((block) => ({ ...block }));
        for (let i = blocks.length - 1; i >= 0; i--) {
            const block = blocks[i];
            if (block?.type === "text" && typeof block.text === "string" && block.text.trim()) {
                blocks[i] = { ...block, cache_control: cacheControl };
                return blocks;
            }
        }
        return content;
    }
    _applyCacheBreakpoint(modelId, systemPrompt, messages) {
        if (!this._isClaudeModel(modelId)) {
            return [{ role: "system", content: systemPrompt }, ...messages];
        }
        const requestMessages = [
            { role: "system", content: this._attachCacheControlToContent(systemPrompt) },
            ...messages.map(msg => ({
                ...msg,
                content: Array.isArray(msg?.content)
                    ? msg.content.map((block) => ({ ...block }))
                    : msg?.content,
            })),
        ];
        let remainingBreakpoints = 3;
        const newestCacheableIndex = requestMessages.length - 4;
        for (let i = newestCacheableIndex; i >= 1 && remainingBreakpoints > 0; i--) {
            const msg = requestMessages[i];
            if (!msg?.content)
                continue;
            const cachedContent = this._attachCacheControlToContent(msg.content);
            if (cachedContent === msg.content)
                continue;
            msg.content = cachedContent;
            remainingBreakpoints--;
        }
        return requestMessages;
    }
    _defaultStepMeta(name, args, ctx) {
        const meta = {};
        if (name === "write_file" && typeof args?.content === "string") {
            meta.lines = args.content.split("\n").length;
            meta.bytes = Buffer.byteLength(args.content, "utf-8");
        }
        else if (name === "edit_file") {
            meta.added = typeof args?.new_string === "string" ? args.new_string.split("\n").length : 0;
            meta.removed = typeof args?.old_string === "string" ? args.old_string.split("\n").length : 0;
            if (args?.replace_all)
                meta.replaceAll = true;
        }
        else if (name === "deploy_to_dev") {
            meta.deployCount = ctx.deployCount;
        }
        else if (name === "shell" && typeof args?.command === "string") {
            meta.command = args.command.length > 120 ? args.command.slice(0, 117) + "…" : args.command;
        }
        else if (name === "db") {
            meta.op = args?.operation;
            if (args?.key)
                meta.key = args.key;
        }
        else if (name === "fetch_url" && typeof args?.url === "string") {
            meta.url = args.url;
        }
        else if (name === "load_skill") {
            meta.name = args?.name;
        }
        return meta;
    }
    _cloneSafe(v) {
        try {
            return typeof structuredClone === "function" ? structuredClone(v) : JSON.parse(JSON.stringify(v));
        }
        catch {
            return undefined;
        }
    }
}
exports.AgentRunner = AgentRunner;
//# sourceMappingURL=AgentRunner.js.map