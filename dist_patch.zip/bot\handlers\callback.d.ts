import { Bot } from "grammy";
import { BotContext } from "../../types";
export declare function registerCallbackHandlers(bot: Bot<BotContext>): void;
//# sourceMappingURL=callback.d.ts.map