"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ListFilesTool = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const config_1 = require("../../../config");
class ListFilesTool {
    renderDefinition() {
        return {
            type: "function",
            function: {
                name: "list_files",
                description: "List all files in the project directory with sizes. Returns lines like 'frontend/app.js (340 lines, 12KB)'.",
                parameters: { type: "object", properties: {}, required: [] },
            },
        };
    }
    async execute(_args, ctx) {
        await ctx.progress({ action: "📂 Scanning files", detail: "", percent: ctx.currentPercent });
        const files = this._walkDir(ctx.projectDir, ctx.projectDir);
        return files.length > 0 ? files.join("\n") : "(empty project)";
    }
    _walkDir(dir, base) {
        const results = [];
        if (!fs_1.default.existsSync(dir))
            return results;
        for (const entry of fs_1.default.readdirSync(dir, { withFileTypes: true })) {
            const fullPath = path_1.default.join(dir, entry.name);
            if (config_1.SKIP_DIRS.has(entry.name))
                continue;
            if (entry.isDirectory()) {
                results.push(...this._walkDir(fullPath, base));
            }
            else {
                const ext = path_1.default.extname(entry.name).toLowerCase();
                const relPath = path_1.default.relative(base, fullPath).replace(/\\/g, "/");
                try {
                    const stat = fs_1.default.statSync(fullPath);
                    const sizeKB = (stat.size / 1024).toFixed(1);
                    if (config_1.BINARY_EXTS.has(ext) || config_1.SKIP_EXTS.has(ext)) {
                        results.push(`${relPath} (${sizeKB}KB, binary — do not read_file)`);
                        continue;
                    }
                    if (stat.size > config_1.READ_FILE_MAX_BYTES) {
                        results.push(`${relPath} (${sizeKB}KB, large — use grep / paged read_file)`);
                        continue;
                    }
                    const content = fs_1.default.readFileSync(fullPath, "utf-8");
                    results.push(`${relPath} (${content.split("\n").length} lines, ${sizeKB}KB)`);
                }
                catch {
                    results.push(relPath);
                }
            }
        }
        return results;
    }
}
exports.ListFilesTool = ListFilesTool;
//# sourceMappingURL=ListFilesTool.js.map