"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const bot_runner_service_1 = require("../../services/bot-runner.service");
const router = (0, express_1.Router)();
router.post("/:tokenHash", (req, res) => {
    const tokenHash = String(req.params.tokenHash);
    const handler = bot_runner_service_1.botRunnerService.getWebhookHandler(tokenHash);
    if (!handler) {
        res.status(404).json({ error: "Bot not found" });
        return;
    }
    handler(req, res, () => {
        res.status(200).end();
    });
});
exports.default = router;
//# sourceMappingURL=webhook.routes.js.map