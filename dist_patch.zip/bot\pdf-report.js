"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateReportPdf = generateReportPdf;
const pdfkit_1 = __importDefault(require("pdfkit"));
function generateReportPdf(title, summary, cost) {
    return new Promise((resolve, reject) => {
        const doc = new pdfkit_1.default({ margin: 40, size: "A4" });
        const chunks = [];
        doc.on("data", (chunk) => chunks.push(chunk));
        doc.on("end", () => resolve(Buffer.concat(chunks)));
        doc.on("error", reject);
        doc.fontSize(22).font("Helvetica-Bold").text(title, { align: "center" });
        doc.moveDown(0.5);
        doc.moveTo(40, doc.y).lineTo(555, doc.y).strokeColor("#cccccc").stroke();
        doc.moveDown(0.8);
        renderMarkdown(doc, summary);
        if (cost) {
            doc.moveDown(1);
            doc.moveTo(40, doc.y).lineTo(555, doc.y).strokeColor("#cccccc").stroke();
            doc.moveDown(0.4);
            doc.fontSize(10).font("Helvetica").fillColor("#666666").text(cost, { align: "right" });
        }
        doc.end();
    });
}
function renderMarkdown(doc, text) {
    const lines = text.split("\n");
    for (const line of lines) {
        const trimmed = line.trimEnd();
        if (!trimmed) {
            doc.moveDown(0.3);
            continue;
        }
        const h1 = trimmed.match(/^# (.+)/);
        if (h1) {
            doc.moveDown(0.3);
            doc.fontSize(18).font("Helvetica-Bold").fillColor("#000000").text(h1[1]);
            doc.moveDown(0.2);
            continue;
        }
        const h2 = trimmed.match(/^## (.+)/);
        if (h2) {
            doc.moveDown(0.3);
            doc.fontSize(15).font("Helvetica-Bold").fillColor("#000000").text(h2[1]);
            doc.moveDown(0.2);
            continue;
        }
        const h3 = trimmed.match(/^### (.+)/);
        if (h3) {
            doc.moveDown(0.2);
            doc.fontSize(13).font("Helvetica-Bold").fillColor("#000000").text(h3[1]);
            doc.moveDown(0.1);
            continue;
        }
        const bullet = trimmed.match(/^[-*]\s+(.+)/);
        if (bullet) {
            renderInlineFormatted(doc, `  \u2022  ${bullet[1]}`, 11);
            continue;
        }
        const numbered = trimmed.match(/^(\d+)\.\s+(.+)/);
        if (numbered) {
            renderInlineFormatted(doc, `  ${numbered[1]}. ${numbered[2]}`, 11);
            continue;
        }
        if (trimmed.startsWith("```")) {
            continue;
        }
        renderInlineFormatted(doc, trimmed, 11);
    }
}
function renderInlineFormatted(doc, text, size) {
    doc.fontSize(size).fillColor("#000000");
    const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*|_[^_]+_)/g);
    let first = true;
    for (const part of parts) {
        if (!part)
            continue;
        const boldMatch = part.match(/^\*\*(.+)\*\*$/);
        if (boldMatch) {
            doc.font("Helvetica-Bold").text(boldMatch[1], { continued: true });
            first = false;
            continue;
        }
        const codeMatch = part.match(/^`(.+)`$/);
        if (codeMatch) {
            doc.font("Courier").text(codeMatch[1], { continued: true });
            first = false;
            continue;
        }
        const italicMatch = part.match(/^\*(.+)\*$/) || part.match(/^_(.+)_$/);
        if (italicMatch) {
            doc.font("Helvetica-Oblique").text(italicMatch[1], { continued: true });
            first = false;
            continue;
        }
        doc.font("Helvetica").text(part, { continued: true });
        first = false;
    }
    if (!first) {
        doc.font("Helvetica").text("", { continued: false });
    }
}
//# sourceMappingURL=pdf-report.js.map