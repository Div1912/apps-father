export type AgentMode = "new" | "update";
//# sourceMappingURL=types.d.ts.map