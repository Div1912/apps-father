"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.chatService = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const crypto_1 = __importDefault(require("crypto"));
const PROJECTS_DIR = path_1.default.join(process.cwd(), "projects");
function historyPath(projectId) {
    return path_1.default.join(PROJECTS_DIR, projectId, "chat-history.json");
}
function readHistory(projectId) {
    const fp = historyPath(projectId);
    if (!fs_1.default.existsSync(fp))
        return [];
    try {
        return JSON.parse(fs_1.default.readFileSync(fp, "utf-8"));
    }
    catch {
        return [];
    }
}
function writeHistory(projectId, messages) {
    const fp = historyPath(projectId);
    const dir = path_1.default.dirname(fp);
    if (!fs_1.default.existsSync(dir))
        fs_1.default.mkdirSync(dir, { recursive: true });
    fs_1.default.writeFileSync(fp, JSON.stringify(messages, null, 2), "utf-8");
}
exports.chatService = {
    getHistory(projectId, before, limit = 50) {
        const all = readHistory(projectId);
        if (!before)
            return all.slice(-limit);
        const idx = all.findIndex(m => m.timestamp >= before);
        if (idx <= 0)
            return [];
        const start = Math.max(0, idx - limit);
        return all.slice(start, idx);
    },
    addMessage(projectId, msg) {
        const messages = readHistory(projectId);
        const now = Date.now();
        const full = {
            ...msg,
            id: crypto_1.default.randomBytes(8).toString("hex"),
            timestamp: now,
            createdAtUtc: msg.createdAtUtc ?? new Date(now).toISOString(),
        };
        messages.push(full);
        writeHistory(projectId, messages);
        return full;
    },
    updateMessage(projectId, msgId, partial) {
        const messages = readHistory(projectId);
        const idx = messages.findIndex(m => m.id === msgId);
        if (idx === -1)
            return null;
        messages[idx] = { ...messages[idx], ...partial, id: msgId };
        writeHistory(projectId, messages);
        return messages[idx];
    },
    removeMessage(projectId, msgId) {
        const messages = readHistory(projectId);
        const idx = messages.findIndex(m => m.id === msgId);
        if (idx === -1)
            return false;
        messages.splice(idx, 1);
        writeHistory(projectId, messages);
        return true;
    },
    removeMessages(projectId, msgIds) {
        const messages = readHistory(projectId);
        const idSet = new Set(msgIds);
        const filtered = messages.filter(m => !idSet.has(m.id));
        const removed = messages.length - filtered.length;
        if (removed > 0)
            writeHistory(projectId, filtered);
        return removed;
    },
    clearHistory(projectId) {
        const fp = historyPath(projectId);
        if (fs_1.default.existsSync(fp))
            fs_1.default.unlinkSync(fp);
    },
    /**
     * Recover dangling in-flight messages after a crash/restart.
     *
     * Heals EVERY `progress` (percent < 100) or `question` message anywhere in
     * the history — not just the last one. After a restart no agent can be
     * running, so any open progress/question is by definition orphaned. The old
     * "last message only" rule missed cases where the agent had appended a
     * follow-up question/answer/auto-fix progress on top of an in-flight build,
     * leaving the UI permanently showing "Working…".
     *
     * Returns the project IDs that had at least one message healed.
     */
    recoverDanglingProgress(reason) {
        const healed = [];
        if (!fs_1.default.existsSync(PROJECTS_DIR))
            return healed;
        let projectIds;
        try {
            projectIds = fs_1.default.readdirSync(PROJECTS_DIR);
        }
        catch {
            return healed;
        }
        for (const projectId of projectIds) {
            const result = this.healProject(projectId, reason);
            if (result > 0)
                healed.push(projectId);
        }
        return healed;
    },
    /**
     * Convert every dangling `progress` (percent < 100) or `question` message in
     * the given project to an `error`. Returns the number of messages healed.
     * Safe to call at any time; returns 0 if nothing needed healing.
     */
    healProject(projectId, reason) {
        const fp = historyPath(projectId);
        if (!fs_1.default.existsSync(fp))
            return 0;
        let messages;
        try {
            messages = JSON.parse(fs_1.default.readFileSync(fp, "utf-8"));
        }
        catch {
            return 0;
        }
        if (!Array.isArray(messages) || messages.length === 0)
            return 0;
        let healedCount = 0;
        const next = messages.map(m => {
            const isOpenProgress = m.type === "progress" && (m.percent ?? 0) < 100;
            const isOpenQuestion = m.type === "question";
            if (!isOpenProgress && !isOpenQuestion)
                return m;
            healedCount++;
            return {
                ...m,
                type: "error",
                content: `⚠️ ${reason}`,
                // Drop progress-only fields so the UI doesn't render a percent bar.
                percent: undefined,
                checklist: undefined,
            };
        });
        if (healedCount === 0)
            return 0;
        try {
            writeHistory(projectId, next);
            console.log(`[Recovery] Healed ${healedCount} dangling message(s) in project ${projectId}`);
            return healedCount;
        }
        catch (err) {
            console.warn(`[Recovery] Failed to heal ${projectId}: ${err.message}`);
            return 0;
        }
    },
};
//# sourceMappingURL=chat.service.js.map