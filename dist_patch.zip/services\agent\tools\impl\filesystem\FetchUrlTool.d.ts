import type OpenAI from "openai";
import type { AgentTool } from "../../../AgentTool";
import type { RunContext } from "../../../RunContext";
export declare class FetchUrlTool implements AgentTool {
    renderDefinition(): OpenAI.Chat.Completions.ChatCompletionTool;
    execute(args: Record<string, any>, ctx: RunContext): Promise<string>;
    getStepMeta(args: Record<string, any>): Record<string, any>;
}
//# sourceMappingURL=FetchUrlTool.d.ts.map