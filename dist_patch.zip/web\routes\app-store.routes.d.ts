/**
 * App Store — public endpoints (no auth required).
 *
 * All owner-authenticated endpoints (create draft, upload screenshots, submit,
 * trade) live in server.ts under /telegram-mini-app/api/store/* because they
 * need access to the shared validateAuth + getOrCreateUserFromReq helpers.
 *
 * Public surface:
 *   GET  /api/store/listings                   — browse (?tab=trending|new|top, ?q=, ?limit, ?offset)
 *   GET  /api/store/listings/:id               — single listing + token + trades + holders
 *   GET  /api/store/tokens/:id/metadata.json   — TIP-64 jetton metadata, served at the URL
 *                                                 stored in the on-chain master content cell
 *   GET  /api/store/tokens/:id/trades          — recent trade history for chart
 *   GET  /api/store/tokens/:id/quote           — buy/sell preview at current curve price
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=app-store.routes.d.ts.map