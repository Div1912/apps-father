export declare const ASK_TOOLS: ({
    type: string;
    function: {
        name: string;
        description: string;
        parameters: {
            type: string;
            properties: {
                path?: undefined;
                offset?: undefined;
                limit?: undefined;
                action?: undefined;
                key?: undefined;
                prefix?: undefined;
                topic?: undefined;
            };
            additionalProperties: boolean;
            required?: undefined;
        };
    };
} | {
    type: string;
    function: {
        name: string;
        description: string;
        parameters: {
            type: string;
            properties: {
                path: {
                    type: string;
                    description: string;
                };
                offset: {
                    type: string;
                    description: string;
                };
                limit: {
                    type: string;
                    description: string;
                };
                action?: undefined;
                key?: undefined;
                prefix?: undefined;
                topic?: undefined;
            };
            required: string[];
            additionalProperties: boolean;
        };
    };
} | {
    type: string;
    function: {
        name: string;
        description: string;
        parameters: {
            type: string;
            properties: {
                action: {
                    type: string;
                    enum: string[];
                    description: string;
                };
                key: {
                    type: string;
                    description: string;
                };
                prefix: {
                    type: string;
                    description: string;
                };
                limit: {
                    type: string;
                    description: string;
                };
                path?: undefined;
                offset?: undefined;
                topic?: undefined;
            };
            required: string[];
            additionalProperties: boolean;
        };
    };
} | {
    type: string;
    function: {
        name: string;
        description: string;
        parameters: {
            type: string;
            properties: {
                topic: {
                    type: string;
                    description: string;
                };
                path?: undefined;
                offset?: undefined;
                limit?: undefined;
                action?: undefined;
                key?: undefined;
                prefix?: undefined;
            };
            additionalProperties: boolean;
            required?: undefined;
        };
    };
})[];
//# sourceMappingURL=ask-tools.d.ts.map