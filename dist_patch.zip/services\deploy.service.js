"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deployService = exports.DeployService = void 0;
const grammy_1 = require("grammy");
const config_1 = require("../config");
const project_service_1 = require("./project.service");
const builder_service_1 = require("./builder.service");
const crypto_service_1 = require("./crypto.service");
class DeployService {
    async deployProject(projectId, app, onProgress) {
        const progress = onProgress || (async () => { });
        await progress("📁 Writing project files...");
        if (builder_service_1.builderService.projectExists(projectId)) {
            await builder_service_1.builderService.updateProject(projectId, app);
        }
        else {
            await builder_service_1.builderService.scaffoldProject(projectId, app);
        }
        await progress("🤖 Configuring bot...");
        await this.configureManagedBot(projectId, app);
        await project_service_1.projectService.storeGeneratedCode(projectId, JSON.stringify({
            frontend: app.frontend,
            backend: app.backend,
            schema: app.schema,
        }));
        const appUrl = `${config_1.config.baseUrl}/app/${projectId}/`;
        await progress(`✅ Deployed! Your app is live at:\n${appUrl}`);
        return appUrl;
    }
    async configureManagedBot(projectId, app) {
        const project = await project_service_1.projectService.getProject(projectId);
        if (!project?.botTokenEncrypted)
            return;
        const token = (0, crypto_service_1.decryptToken)(project.botTokenEncrypted);
        const bot = new grammy_1.Bot(token);
        try {
            if (app.botDescription) {
                await bot.api.setMyDescription(app.botDescription);
            }
            // if (app.botCommands && app.botCommands.length > 0) {
            //   await bot.api.setMyCommands(app.botCommands);
            // }
            const appUrl = `${config_1.config.baseUrl}/app/${projectId}/`;
            await bot.api.setChatMenuButton({
                menu_button: {
                    type: "web_app",
                    text: "Launch App",
                    web_app: { url: appUrl },
                },
            });
        }
        catch (err) {
            console.error(`[Deploy] Error configuring managed bot for ${projectId}:`, err);
        }
    }
}
exports.DeployService = DeployService;
exports.deployService = new DeployService();
//# sourceMappingURL=deploy.service.js.map