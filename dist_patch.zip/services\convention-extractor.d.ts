export declare class ConventionExtractor {
    extract(projectDir: string): {
        structure: string;
        conventions: string;
    };
    private extractStructure;
    private extractHtmlStructure;
    private extractCssStructure;
    private extractRoutesConventions;
    private extractFrontendConventions;
    private extractHtmlConventions;
    private extractCssConventions;
    private captureBlock;
}
//# sourceMappingURL=convention-extractor.d.ts.map