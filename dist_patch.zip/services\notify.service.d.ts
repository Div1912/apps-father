import { Lang } from "../bot/i18n";
export declare function notifyNewUser(telegramId: number, _username?: string, _firstName?: string, _referredBy?: number, _source?: string | null): void;
export declare function notifyReferralBonus(referrerTelegramId: number, referrerUsername: string | undefined, bonus: number, fromTelegramId: number): void;
export declare function notifyDeposit(telegramId: number, username: string | undefined, amountUsd: number, creditsGranted: number, bonusCredits: number, isFirstPurchase: boolean, method?: string, bundleName?: string, newCreditsBalance?: number): void;
export declare function notifyProcessDone(telegramId: number, appName: string, summary: string, kind: "build" | "update" | "fix", lang?: Lang): void;
//# sourceMappingURL=notify.service.d.ts.map