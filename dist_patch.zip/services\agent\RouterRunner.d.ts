import type { RouterTool } from "./tools/impl/router/RouterTool";
import type { RouterContext } from "./tools/impl/router/RouterContext";
export interface RouterRunnerOpts {
    modelCfg: any;
    systemPrompt: string;
    messages: any[];
    tools: RouterTool[];
    ctx: RouterContext;
    /** Streamed assistant text (for "thinking" UX bubble). */
    onChunk?: (delta: string, full: string) => void;
    /** Called when the router invokes a tool (before the result is available). */
    onToolCall?: (toolName: string) => void;
    telegramId?: string;
    sessionId?: string;
}
export interface RouterRunnerResult {
    /** Final free-text the model produced (used as "speak" answer when no proposal was emitted). */
    text: string;
    inputTokens: number;
    outputTokens: number;
    /** Sum of `usage.cost` across iterations. 0 if OR didn't return cost. */
    costUsd: number;
    costUsdInput: number;
    costUsdOutput: number;
    /** True iff `propose_action` was called (terminal tool). */
    proposed: boolean;
}
/**
 * Lightweight runner for the conversational router.
 *
 * Mirrors the AskRunner shape: a small tool-use loop on a cheap model.
 * The loop terminates when:
 *   - the model returns no tool calls (free-text answer), OR
 *   - the `propose_action` tool sets ctx.proposalEmitted = true, OR
 *   - we hit the maxIterations limit from modelCfg.
 */
export declare class RouterRunner {
    run(opts: RouterRunnerOpts): Promise<RouterRunnerResult>;
    private _getProviderRouting;
    private _streamCall;
}
//# sourceMappingURL=RouterRunner.d.ts.map