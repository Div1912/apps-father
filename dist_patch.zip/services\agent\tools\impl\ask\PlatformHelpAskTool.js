"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlatformHelpAskTool = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const paths_1 = require("../../../paths");
const ALLOWED_TOPICS = new Set(["payments", "referrals", "realtime", "bot", "billing", "tiers"]);
class PlatformHelpAskTool {
    name = "platform_help";
    definition = {
        type: "function",
        function: {
            name: "platform_help",
            description: "Look up Apps Father platform documentation aimed at owners. Use this when the owner asks about platform-wide features, pricing, payments, referrals, real-time, the bot side, etc.",
            parameters: {
                type: "object",
                properties: {
                    topic: { type: "string", description: "One of: payments, referrals, realtime, bot, billing, tiers. Omit for the high-level overview." },
                },
                additionalProperties: false,
            },
        },
    };
    async execute(args, _ctx) {
        const topic = (typeof args?.topic === "string" ? args.topic : "").toLowerCase().trim();
        const askDir = path_1.default.join(paths_1.KNOWLEDGE_DIR, "ask");
        if (!topic)
            return this._loadOverview();
        if (!ALLOWED_TOPICS.has(topic)) {
            return `Unknown topic. Available: ${[...ALLOWED_TOPICS].join(", ")}`;
        }
        const file = path_1.default.join(askDir, "topics", `${topic}.md`);
        if (!fs_1.default.existsSync(file))
            return `Topic '${topic}' has no doc yet.`;
        return fs_1.default.readFileSync(file, "utf-8");
    }
    _loadOverview() {
        try {
            const p = path_1.default.join(paths_1.KNOWLEDGE_DIR, "ask", "platform-overview.md");
            if (fs_1.default.existsSync(p))
                return fs_1.default.readFileSync(p, "utf-8");
        }
        catch { }
        return "(platform overview unavailable)";
    }
}
exports.PlatformHelpAskTool = PlatformHelpAskTool;
//# sourceMappingURL=PlatformHelpAskTool.js.map