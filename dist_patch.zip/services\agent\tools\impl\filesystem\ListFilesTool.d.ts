import type OpenAI from "openai";
import type { AgentTool } from "../../../AgentTool";
import type { RunContext } from "../../../RunContext";
export declare class ListFilesTool implements AgentTool {
    renderDefinition(): OpenAI.Chat.Completions.ChatCompletionTool;
    execute(_args: Record<string, any>, ctx: RunContext): Promise<string>;
    private _walkDir;
}
//# sourceMappingURL=ListFilesTool.d.ts.map