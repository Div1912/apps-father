"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.newProjectCommand = newProjectCommand;
const keyboards_1 = require("../keyboards");
const emoji_1 = require("../emoji");
async function newProjectCommand(ctx) {
    const from = ctx.from;
    if (!from)
        return;
    await ctx.reply(`${(0, emoji_1.ce)(emoji_1.EMOJI.add)} <b>Create New Project</b>\n\n` +
        `Tap the button below to create a bot for your new Mini App.\n` +
        `You'll set the bot's name and username in Telegram's interface.`, {
        parse_mode: "HTML",
        reply_markup: (0, keyboards_1.createBotKeyboard)(),
    });
}
//# sourceMappingURL=newproject.js.map