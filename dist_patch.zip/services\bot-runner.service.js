"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.botRunnerService = exports.BotRunnerService = void 0;
const grammy_1 = require("grammy");
const express_1 = require("express");
const config_1 = require("../config");
const project_service_1 = require("./project.service");
const crypto_service_1 = require("./crypto.service");
const console_tagger_service_1 = require("./console-tagger.service");
const db_1 = require("../db");
const i18n_1 = require("../bot/i18n");
const better_sqlite3_1 = __importDefault(require("better-sqlite3"));
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
/**
 * Apps Father's own bot username, picked per-environment so user-bot deep
 * links land on the correct mini-app instance. Dev server uses the dev bot
 * (its mini-app domain is dev.apps-father.com), prod uses the main bot.
 */
function getFatherBotUsername() {
    return config_1.config.domain.startsWith("dev.") ? "apps_father_dev_bot" : "apps_father_bot";
}
class BotRunnerService {
    bots = new Map();
    /**
     * Start (or re-start) the user's bot and register its webhook.
     *
     * @param sendOwnerWelcome When true, immediately push the "Good job, bot
     *   created" card to the owner via bot.api.sendMessage *after* the webhook
     *   is live. This covers the race where the user is bounced into their new
     *   bot by mobile Telegram and presses /start before our webhook is set —
     *   they'd otherwise get nothing. Pass `false` (the default) when restoring
     *   bots at server boot, or every old user would get spammed with the
     *   welcome card on every deploy.
     */
    async startBot(projectId, token, botUsername, sendOwnerWelcome = false) {
        if (this.bots.has(projectId)) {
            console.log(`[BotRunner] Bot for ${projectId} already running`);
            return;
        }
        const bot = new grammy_1.Bot(token);
        const appUrl = `${config_1.config.baseUrl}/app/${projectId}/`;
        bot.command("start", async (ctx) => {
            if (await this.hasCustomWebhook(projectId))
                return;
            // Decide which welcome to send based on (a) deploy status and
            // (b) whether the sender is the project owner. We deliberately fetch
            // fresh project + owner data on every /start because it's a low-volume
            // command and stale cache here would either show the "app not ready"
            // card after deploy, or leak the owner-only nudge to a friend who
            // pressed /start in someone else's bot.
            const project = await db_1.prisma.project.findUnique({
                where: { id: projectId },
                select: {
                    releaseCommit: true,
                    user: { select: { telegramId: true, language: true } },
                },
            });
            if (!project)
                return;
            const isReleased = project.releaseCommit !== null && project.releaseCommit !== undefined;
            const senderTelegramId = ctx.from?.id;
            const isOwner = !!senderTelegramId && BigInt(senderTelegramId) === project.user.telegramId;
            // Owner always gets the "back to Apps Father" nudge on /start —
            // they don't need a Launch App button in their own bot, they need
            // to get back into Apps Father to keep iterating on the app.
            // Under the new flow the project is already deployed when the bot
            // is linked, but the nudge is still the right surface for the owner.
            if (isOwner) {
                const lang = project.user.language || "en";
                const fatherBot = getFatherBotUsername();
                const backUrl = `https://t.me/${fatherBot}/app?startapp=open_dialog`;
                await ctx.reply(`<b>${(0, i18n_1.t)(lang, "user_bot_start_owner_title")}</b>\n${(0, i18n_1.t)(lang, "user_bot_start_owner_body")}`, {
                    parse_mode: "HTML",
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: (0, i18n_1.t)(lang, "user_bot_start_owner_button"), url: backUrl, style: "primary" }],
                        ],
                    },
                });
                return;
            }
            // Non-owner /start. If the app isn't deployed yet there's nothing
            // to launch, so stay silent. Otherwise hand them the standard
            // "Launch App" card.
            if (!isReleased)
                return;
            await ctx.reply(`Welcome! Tap the button below to launch the app.`, {
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "🚀 Launch App", web_app: { url: appUrl } }],
                    ],
                },
            });
        });
        // Handle pre_checkout_query — auto-approve all payments
        bot.on("pre_checkout_query", async (ctx) => {
            try {
                const query = ctx.preCheckoutQuery || ctx.update.pre_checkout_query;
                if (query) {
                    await ctx.answerPreCheckoutQuery(true);
                    console.log(`[BotRunner] Pre-checkout approved for ${botUsername}, payload: ${query.invoice_payload}`);
                }
            }
            catch (err) {
                console.error(`[BotRunner] Error answering pre_checkout_query:`, err);
                try {
                    await ctx.answerPreCheckoutQuery(false, { error_message: "Payment processing error" });
                }
                catch { }
            }
        });
        // Handle successful_payment — process the payment
        bot.on("message:successful_payment", async (ctx) => {
            try {
                const payment = ctx.message.successful_payment;
                const userId = ctx.from.id.toString();
                const invoicePayload = payment.invoice_payload;
                console.log(`[BotRunner] Payment received for ${botUsername}: user=${userId}, payload=${invoicePayload}, amount=${payment.total_amount} ${payment.currency}`);
                try {
                    const path = require("path");
                    const fs = require("fs");
                    const dataDir = path.join(process.cwd(), "projects", projectId, "release", "data");
                    if (fs.existsSync(path.join(dataDir, "app.db"))) {
                        const sqlite = new better_sqlite3_1.default(path.join(dataDir, "app.db"));
                        sqlite.pragma("journal_mode = WAL");
                        sqlite.exec("CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT)");
                        const getVal = (key) => {
                            const row = sqlite.prepare("SELECT value FROM kv WHERE key = ?").get(key);
                            return row ? JSON.parse(row.value) : null;
                        };
                        const setVal = (key, value) => {
                            sqlite.prepare("INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)").run(key, JSON.stringify(value));
                        };
                        const pending = getVal("pending_purchases") || [];
                        const purchase = pending.find((p) => p.invoiceId === invoicePayload && !p.processed);
                        if (purchase) {
                            const coinsToAdd = parseInt(purchase.coins) || 0;
                            const purchaseUserId = purchase.userId;
                            const users = getVal("users") || [];
                            const user = users.find((u) => u.telegramId === purchaseUserId || u.user_id === purchaseUserId);
                            if (user) {
                                user.coins = (user.coins || 0) + coinsToAdd;
                            }
                            setVal("users", users);
                            purchase.processed = true;
                            purchase.processedAt = new Date().toISOString();
                            setVal("pending_purchases", pending);
                            sqlite.close();
                            console.log(`[BotRunner] Payment processed: +${coinsToAdd} coins for user ${purchaseUserId}`);
                            await ctx.reply(`🎉 Payment successful! +${coinsToAdd} coins added to your account!`);
                        }
                        else {
                            sqlite.close();
                            console.log(`[BotRunner] No pending purchase found for payload: ${invoicePayload}`);
                            await ctx.reply(`✅ Payment received! Thank you.`);
                        }
                    }
                    else {
                        await ctx.reply(`✅ Payment received! Thank you.`);
                    }
                }
                catch (dbErr) {
                    console.error(`[BotRunner] DB error processing payment:`, dbErr);
                    await ctx.reply(`✅ Payment received! Your purchase will be processed shortly.`);
                }
            }
            catch (err) {
                console.error(`[BotRunner] Error handling successful_payment:`, err);
            }
        });
        bot.on("message:text", async (ctx) => {
            if (await this.hasCustomWebhook(projectId))
                return;
            // Same gating as /start: before deploy, only the owner gets a reply.
            // Without this, bots that aren't ready yet would noisily reply
            // "Tap the button below" and link to a /app/<id>/ URL that 404s.
            const project = await db_1.prisma.project.findUnique({
                where: { id: projectId },
                select: {
                    releaseCommit: true,
                    user: { select: { telegramId: true } },
                },
            });
            if (!project)
                return;
            const isReleased = project.releaseCommit !== null && project.releaseCommit !== undefined;
            if (!isReleased)
                return;
            await ctx.reply("Tap the button below to open the app!", {
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "🚀 Launch App", web_app: { url: appUrl } }],
                    ],
                },
            });
        });
        bot.catch((err) => {
            console.error(`[BotRunner] Error in bot @${botUsername}:`, err);
        });
        const grammyHandler = (0, grammy_1.webhookCallback)(bot, "express");
        const webhookHandler = (req, res, next) => {
            const body = req.body;
            grammyHandler(req, res);
            this.forwardToAppWebhook(projectId, token, botUsername, body).catch(err => {
                console.error(`[BotRunner] Forward error for @${botUsername}:`, err.message);
            });
        };
        this.bots.set(projectId, { bot, projectId, botUsername, webhookHandler });
        if (config_1.config.nodeEnv === "production") {
            const tokenHash = this.hashToken(token);
            const webhookUrl = `${config_1.config.webhookUrl}/${tokenHash}`;
            await bot.api.setWebhook(webhookUrl, {
                secret_token: config_1.config.webhookSecret,
            });
            console.log(`[BotRunner] Webhook set for ${botUsername} -> ${webhookUrl}`);
        }
        else {
            bot.start({
                onStart: () => console.log(`[BotRunner] Polling started for @${botUsername}`),
            });
        }
        console.log(`[BotRunner] Bot @${botUsername} started for project ${projectId}`);
        if (sendOwnerWelcome) {
            // Fire-and-forget so a failure to DM the owner (blocked the bot,
            // restricted account, etc.) never breaks the create-bot flow.
            this.sendOwnerWelcome(bot, projectId, botUsername).catch((err) => {
                console.error(`[BotRunner] sendOwnerWelcome failed for @${botUsername}:`, err?.message || err);
            });
        }
    }
    /**
     * Push the localized "Good job, bot created" card directly to the owner
     * the moment the webhook is live. This covers the mobile race where
     * Telegram bounces the user into their freshly created bot and they tap
     * /start before our webhook has been registered — without this, the
     * /start update is dropped on the floor and the user sees nothing.
     */
    async sendOwnerWelcome(bot, projectId, botUsername) {
        const project = await db_1.prisma.project.findUnique({
            where: { id: projectId },
            select: {
                releaseCommit: true,
                user: { select: { telegramId: true, language: true } },
            },
        });
        if (!project)
            return;
        // We deliberately push regardless of releaseCommit: under the new flow
        // (bot creation happens AFTER the first build) the project is already
        // deployed when the bot is linked, but the owner still needs the
        // "back to Apps Father" nudge to continue editing / managing the app.
        // The legacy assumption that "deployed = nothing to nudge about" no
        // longer holds.
        const lang = project.user.language || "en";
        const fatherBot = getFatherBotUsername();
        const backUrl = `https://t.me/${fatherBot}/app?startapp=open_dialog`;
        const ownerId = Number(project.user.telegramId);
        if (!ownerId)
            return;
        try {
            await bot.api.sendMessage(ownerId, `<b>${(0, i18n_1.t)(lang, "user_bot_start_owner_title")}</b>\n${(0, i18n_1.t)(lang, "user_bot_start_owner_body")}`, {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: (0, i18n_1.t)(lang, "user_bot_start_owner_button"), url: backUrl, style: "primary" }],
                    ],
                },
            });
            console.log(`[BotRunner] Owner welcome sent via @${botUsername} to ${ownerId}`);
        }
        catch (err) {
            // 403 "bot was blocked by the user" is expected for some users — log
            // at info level rather than error so it doesn't pollute alerts.
            const code = err?.error_code || err?.statusCode;
            const desc = err?.description || err?.message;
            if (code === 403) {
                console.log(`[BotRunner] Owner welcome skipped for @${botUsername}: ${desc}`);
            }
            else {
                throw err;
            }
        }
    }
    async stopBot(projectId) {
        const instance = this.bots.get(projectId);
        if (!instance)
            return;
        try {
            await instance.bot.stop();
        }
        catch (err) {
            console.error(`[BotRunner] Error stopping bot for ${projectId}:`, err);
        }
        this.bots.delete(projectId);
        console.log(`[BotRunner] Bot stopped for project ${projectId}`);
    }
    getWebhookHandler(tokenHash) {
        for (const instance of this.bots.values()) {
            const token = this.getTokenFromInstance(instance);
            if (token && this.hashToken(token) === tokenHash) {
                return instance.webhookHandler;
            }
        }
        return null;
    }
    async loadAllBots() {
        console.log("[BotRunner] Loading all active project bots...");
        const projects = await project_service_1.projectService.getAllActiveProjects();
        for (const project of projects) {
            if (!project.botTokenEncrypted || !project.botUsername)
                continue;
            try {
                const token = (0, crypto_service_1.decryptToken)(project.botTokenEncrypted);
                // Validate the token before spending resources on a full start.
                // An invalid / deleted token returns HTTP 401 from Telegram.
                try {
                    const probe = new grammy_1.Bot(token);
                    await probe.api.getMe();
                }
                catch (probeErr) {
                    const msg = String(probeErr?.message ?? probeErr).toLowerCase();
                    if (msg.includes("401") ||
                        msg.includes("unauthorized") ||
                        msg.includes("not found") ||
                        msg.includes("token")) {
                        console.warn(`[BotRunner] Token invalid for project ${project.id} (@${project.botUsername}) — unlinking bot from app.`);
                        try {
                            await project_service_1.projectService.unlinkBot(project.id);
                        }
                        catch { }
                        continue;
                    }
                    // Network hiccup or other transient error — don't unlink, just skip.
                    console.error(`[BotRunner] Could not validate token for project ${project.id}:`, probeErr);
                    continue;
                }
                await this.startBot(project.id, token, project.botUsername);
            }
            catch (err) {
                console.error(`[BotRunner] Failed to start bot for project ${project.id}:`, err);
            }
        }
        console.log(`[BotRunner] Loaded ${this.bots.size} bots`);
    }
    isRunning(projectId) {
        return this.bots.has(projectId);
    }
    getRunningCount() {
        return this.bots.size;
    }
    hashToken(token) {
        const crypto = require("crypto");
        return crypto.createHash("sha256").update(token).digest("hex").substring(0, 16);
    }
    getTokenFromInstance(instance) {
        try {
            return instance.bot.token;
        }
        catch {
            return null;
        }
    }
    /** Returns the webhook route path registered in routes.js, or null if none. */
    getCustomWebhookPath(projectId, deployment = "release") {
        const routesFile = path_1.default.join(process.cwd(), "projects", projectId, deployment, "backend", "routes.js");
        if (!fs_1.default.existsSync(routesFile))
            return null;
        try {
            const content = fs_1.default.readFileSync(routesFile, "utf-8");
            // Check for explicit bot-webhook first, then fall back to generic /webhook route
            if (content.includes("bot-webhook"))
                return "/bot-webhook";
            if (/router\s*\.\s*post\s*\(\s*['"`]\/webhook['"`]/.test(content))
                return "/webhook";
            return null;
        }
        catch {
            return null;
        }
    }
    async hasCustomWebhook(projectId) {
        return this.getCustomWebhookPath(projectId) !== null;
    }
    async forwardToAppWebhook(projectId, token, botUsername, body, options = {}) {
        const deployment = options.deployment || "release";
        const projectDir = path_1.default.join(process.cwd(), "projects", projectId);
        const routesFile = path_1.default.join(projectDir, deployment, "backend", "routes.js");
        if (!fs_1.default.existsSync(routesFile))
            return;
        const webhookPath = this.getCustomWebhookPath(projectId, deployment);
        if (!webhookPath)
            return;
        // Tag console output produced by the project's webhook handler with
        // `[app:<projectId>]` so the log viewer can filter by project.
        return (0, console_tagger_service_1.runWithProject)(projectId, async () => {
            let db = null;
            try {
                delete require.cache[require.resolve(routesFile)];
                const routeModule = require(routesFile);
                if (typeof routeModule !== "function")
                    return;
                const runtimeDir = path_1.default.join(projectDir, deployment);
                const backendDir = path_1.default.join(projectDir, deployment, "backend");
                const envFilePath = path_1.default.join(backendDir, ".env");
                const envVars = fs_1.default.existsSync(envFilePath)
                    ? dotenv_1.default.parse(fs_1.default.readFileSync(envFilePath))
                    : {};
                const dataDir = path_1.default.join(runtimeDir, "data");
                fs_1.default.mkdirSync(dataDir, { recursive: true });
                const sqlite = new better_sqlite3_1.default(path_1.default.join(dataDir, "app.db"));
                sqlite.pragma("journal_mode = WAL");
                sqlite.exec("CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT)");
                db = {
                    get(key) { const r = sqlite.prepare("SELECT value FROM kv WHERE key = ?").get(key); return r ? JSON.parse(r.value) : null; },
                    set(key, value) { sqlite.prepare("INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)").run(key, JSON.stringify(value)); },
                    getAll() { const rows = sqlite.prepare("SELECT key, value FROM kv").all(); const res = {}; for (const row of rows)
                        res[row.key] = JSON.parse(row.value); return res; },
                    delete(key) { sqlite.prepare("DELETE FROM kv WHERE key = ?").run(key); },
                    keys() { return sqlite.prepare("SELECT key FROM kv").all().map((r) => r.key); },
                    close() { try {
                        sqlite.close();
                    }
                    catch { } },
                    botToken: token,
                    botUsername,
                    projectId,
                };
                const projectRouter = (0, express_1.Router)();
                routeModule(projectRouter, db, projectId, envVars);
                const fakeReq = {
                    method: "POST",
                    url: webhookPath,
                    path: webhookPath,
                    headers: { "content-type": "application/json" },
                    body,
                    params: {},
                    query: {},
                    get: (h) => h === "content-type" ? "application/json" : undefined,
                };
                let fallbackResolve = null;
                let responseSent = false;
                const fakeRes = {
                    statusCode: 200,
                    _headers: {},
                    get headersSent() { return responseSent; },
                    setHeader(k, v) { this._headers[k] = v; },
                    status(code) { this.statusCode = code; return this; },
                    json(data) { responseSent = true; fallbackResolve?.(); return this; },
                    send(data) { responseSent = true; fallbackResolve?.(); return this; },
                    end() { responseSent = true; fallbackResolve?.(); return this; },
                    get: (h) => undefined,
                    set: (k, v) => fakeRes,
                    type: (t) => fakeRes,
                };
                const invokeHandler = (handler) => new Promise((resolve, reject) => {
                    let settled = false;
                    let timeout;
                    const done = (err) => {
                        if (settled)
                            return;
                        settled = true;
                        clearTimeout(timeout);
                        err ? reject(err) : resolve();
                    };
                    timeout = setTimeout(() => done(), 5000);
                    try {
                        const ret = handler(fakeReq, fakeRes, done);
                        if (ret && typeof ret.then === "function") {
                            ret.then(() => done()).catch(done);
                        }
                        else if (handler.length < 3) {
                            done();
                        }
                    }
                    catch (err) {
                        done(err);
                    }
                });
                const dispatchedDirectly = async () => {
                    const stack = (projectRouter.stack || []);
                    for (const layer of stack) {
                        const route = layer?.route;
                        const routePath = route?.path;
                        const matchesPath = Array.isArray(routePath)
                            ? routePath.includes(webhookPath)
                            : routePath === webhookPath;
                        if (!matchesPath || !route?.methods?.post)
                            continue;
                        const handlers = Array.isArray(route.stack)
                            ? route.stack.map((routeLayer) => routeLayer?.handle).filter(Boolean)
                            : [];
                        for (const handler of handlers) {
                            await invokeHandler(handler);
                        }
                        return true;
                    }
                    return false;
                };
                if (!await dispatchedDirectly()) {
                    await new Promise((resolve) => {
                        fallbackResolve = resolve;
                        projectRouter(fakeReq, fakeRes, () => resolve());
                        setTimeout(resolve, 5000);
                    });
                    // Express 4 does not await async handlers after res.json(); keep the DB
                    // open briefly for legacy/fallback dispatch paths.
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
                db.close();
            }
            catch (err) {
                if (db)
                    try {
                        db.close();
                    }
                    catch { }
                throw err;
            }
        });
    }
    /**
     * Simulate a Telegram update hitting the bot webhook without a real Telegram
     * account. All calls to api.telegram.org that the routes.js makes are
     * intercepted and returned as a captured list. Also logged via ALS so
     * server_logs can show them.
     */
    async simulateBotWebhook(projectId, update, options = {}) {
        const project = await db_1.prisma.project.findUnique({
            where: { id: projectId },
            select: { botTokenEncrypted: true, botUsername: true },
        });
        const token = project?.botTokenEncrypted
            ? (0, crypto_service_1.decryptToken)(project.botTokenEncrypted)
            : "SIMULATE_TOKEN";
        const botUsername = project?.botUsername || "simulate_bot";
        const captured = [];
        const origFetch = global.fetch;
        global.fetch = async (url, opts) => {
            if (String(url).includes("api.telegram.org")) {
                const method = String(url).split("/").pop() || "unknown";
                let body = {};
                try {
                    body = JSON.parse(opts?.body || "{}");
                }
                catch { }
                captured.push({ method, body });
                console.log(`[simulate] tg.${method}: ${JSON.stringify(body).slice(0, 300)}`);
                return { ok: true, json: async () => ({ ok: true, result: { message_id: 1 } }) };
            }
            if (origFetch)
                return origFetch(url, opts);
            throw new Error("fetch not available outside telegram.org simulation");
        };
        try {
            if (!update.update_id)
                update.update_id = Date.now();
            await this.forwardToAppWebhook(projectId, token, botUsername, update, {
                deployment: options.deployment || "development",
            });
        }
        finally {
            global.fetch = origFetch;
        }
        return captured;
    }
}
exports.BotRunnerService = BotRunnerService;
exports.botRunnerService = new BotRunnerService();
//# sourceMappingURL=bot-runner.service.js.map