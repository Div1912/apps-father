"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.projectsCommand = projectsCommand;
const project_service_1 = require("../../services/project.service");
const grammy_1 = require("grammy");
async function projectsCommand(ctx) {
    const from = ctx.from;
    if (!from)
        return;
    const { user } = await project_service_1.projectService.getOrCreateUser(from.id, from.username, from.first_name);
    const projects = await project_service_1.projectService.getProjectsByUser(user.id);
    if (projects.length === 0) {
        await ctx.reply("📂 You don't have any projects yet.\n\nUse /newproject to create your first Mini App!");
        return;
    }
    const keyboard = new grammy_1.InlineKeyboard();
    for (const p of projects) {
        const statusIcon = getStatusIcon(p.status);
        keyboard.text(`${statusIcon} ${p.name}`, `project:${p.id}`).row();
    }
    keyboard.text("➕ New Project", "new_project");
    await ctx.reply("📂 <b>Your Projects:</b>\n\nSelect a project to manage:", {
        parse_mode: "HTML",
        reply_markup: keyboard,
    });
}
function getStatusIcon(status) {
    const icons = {
        created: "🆕",
        planning: "📝",
        building: "🔨",
        deployed: "✅",
        released: "🚀",
        error: "❌",
    };
    return icons[status] || "❓";
}
//# sourceMappingURL=projects.js.map