import { WebSocketServer } from "ws";
export declare function broadcastToProject(projectId: string, data: any): void;
export declare function registerAnswerResolver(projectId: string, resolve: (answer: string) => void): void;
export declare function resolveAnswer(projectId: string, answer: string): boolean;
export declare function hasPendingAnswer(projectId: string): boolean;
export declare function setupMiniAppWebSocket(): WebSocketServer;
export declare function getMiniAppWss(): WebSocketServer | null;
//# sourceMappingURL=miniapp-ws.d.ts.map