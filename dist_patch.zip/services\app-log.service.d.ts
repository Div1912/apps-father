/**
 * Persistent runtime log capture.
 *
 * The console tagger (`console-tagger.service.ts`) calls `enqueueLog()` for
 * every line written to stdout/stderr. We buffer them in memory and flush in
 * batches to the `app_logs` Postgres table every `FLUSH_INTERVAL_MS`. This
 * lets us:
 *   - keep the hot logging path synchronous (no awaiting Prisma per write),
 *   - survive PM2 restarts (file logs rotate / are wiped; DB persists),
 *   - filter & query historically by (projectId, category, level, time, text).
 *
 * Categories are derived from the existing bracket prefix conventions:
 *   [Agent], [Context]                        -> "Agent"
 *   [Builder]                                 -> "Build"
 *   [BotRunner], [Bot]                        -> "Bot"
 *   [Commit]                                  -> "Commit"
 *   [API]                                     -> "API"
 *   [WS]                                      -> "WS"
 *   [Web], [MiniApp], [Admin], [Chat API]…    -> "Web"
 *   [DB]                                      -> "Database"
 *   [Recovery], [Shutdown], [Migration]       -> "Lifecycle"
 *   line tagged with [app:<id>] but no other tag -> "Backend"
 *   no project, no tag                        -> "System"
 *
 * IMPORTANT: never use `console.log` from inside this file — the tee would
 * recurse and re-enqueue our own diagnostic lines forever. Use
 * `process.stderr.write` directly with a sentinel byte if you really need
 * diagnostic output, but prefer keeping this file silent.
 */
/**
 * Push a single raw log line into the buffer. Called by the console tagger
 * for every line written to stdout/stderr. Must be cheap and non-blocking.
 */
export declare function enqueueLog(opts: {
    projectId: string | null;
    source: "stdout" | "stderr";
    rawLine: string;
}): void;
/** Start the periodic flush timer. Idempotent. */
export declare function startAppLogFlusher(): void;
/** Force-flush (used at shutdown). */
export declare function drainAppLogs(): Promise<void>;
/** Stop the flusher (no more flushes will be scheduled). Used at shutdown. */
export declare function stopAppLogFlusher(): void;
/** Disable the persistent sink at runtime (e.g. for tests). */
export declare function setAppLogEnabled(value: boolean): void;
//# sourceMappingURL=app-log.service.d.ts.map