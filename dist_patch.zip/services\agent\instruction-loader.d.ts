import { AgentMode } from "./types";
declare const TEMPLATE_KEYS: readonly ["domain", "baseUrl", "wsBaseUrl", "wsScheme"];
type TemplateKey = typeof TEMPLATE_KEYS[number];
export declare function buildTemplateVars(): Record<TemplateKey, string>;
export declare function renderTemplate(text: string, vars: Record<TemplateKey, string>): string;
export declare function buildSystemPrompt(mode: AgentMode): Promise<string>;
export declare function loadSkill(name: string): string;
export declare function getAvailableSkills(): string[];
export {};
//# sourceMappingURL=instruction-loader.d.ts.map