"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShellTool = void 0;
const child_process_1 = require("child_process");
const util_1 = require("util");
const config_1 = require("../../../config");
const execAsync = (0, util_1.promisify)(child_process_1.exec);
class ShellTool {
    renderDefinition() {
        return {
            type: "function",
            function: {
                name: "shell",
                description: "Run a shell command in the project directory. Use for package installation, file manipulation, or running scripts. Blocked: rm -rf /, shutdown, etc.",
                parameters: {
                    type: "object",
                    properties: {
                        command: { type: "string", description: "Shell command to execute" },
                    },
                    required: ["command"],
                },
            },
        };
    }
    async execute(args, ctx) {
        const cmd = args.command;
        if (config_1.BLOCKED_COMMANDS.some(b => cmd.includes(b))) {
            return "Error: Command blocked for safety";
        }
        if (config_1.BLOCKED_INFRA_SHELL_PATTERNS.some(re => re.test(cmd))) {
            return "Error: Platform infrastructure diagnostics are not allowed from project shell. Use deploy_to_dev, simulate_api, simulate_telegram, simulate_ws, and server_logs; fix project files based on those tool results.";
        }
        await ctx.progress({ action: "⚡ Running system commands...", detail: "", percent: ctx.currentPercent });
        try {
            const { stdout } = await execAsync(cmd, {
                cwd: ctx.projectDir,
                timeout: 30000,
                maxBuffer: 1024 * 1024,
                env: { ...process.env, HOME: ctx.projectDir, NODE_ENV: "development" },
            });
            return (stdout || "(no output)").substring(0, 10000);
        }
        catch (err) {
            const stderr = err.stderr || "";
            const stdout = err.stdout || "";
            return `Exit code ${err.code || 1}:\n${(stderr + stdout || err.message).substring(0, 5000)}`;
        }
    }
    getStepMeta(args) {
        const cmd = typeof args?.command === "string" ? args.command : "";
        return { command: cmd.length > 120 ? cmd.slice(0, 117) + "…" : cmd };
    }
}
exports.ShellTool = ShellTool;
//# sourceMappingURL=ShellTool.js.map