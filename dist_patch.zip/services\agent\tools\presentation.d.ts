export type ToolStepKind = "thinking" | "reading" | "writing" | "editing" | "searching" | "shell" | "fetch" | "db" | "telegram" | "deploying" | "configuring" | "skill" | "ask" | "done";
export type ToolTargetField = "file" | "url" | "key";
export interface ToolDisplayConfig {
    kind: ToolStepKind;
    title: string;
    targetKey?: string;
    targetField?: ToolTargetField;
}
export type ToolStepTarget = {
    file?: string;
    range?: string;
    url?: string;
    key?: string;
};
export declare const TOOL_DISPLAY: Record<string, ToolDisplayConfig>;
export declare function buildToolStepTarget(toolName: string, args: any): ToolStepTarget | undefined;
export declare function summarizeToolArgs(toolName: string, args: any): string;
//# sourceMappingURL=presentation.d.ts.map