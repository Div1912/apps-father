/**
 * Jetton TX builder — produces TonConnect-compatible message payloads so the
 * publisher's wallet (NOT our hot wallet) signs token deploys and liquidity
 * transactions.
 *
 *   Reference implementation: https://github.com/ton-blockchain/minter
 *   (the React frontend that powers https://minter.ton.org)
 *   Reference contract:        https://github.com/ton-blockchain/minter-contract
 *
 *   This file is a 1:1 port of the deploy logic from `src/lib/jetton-minter.ts`
 *   and `src/lib/contract-deployer.ts` of the minter repo, adapted to:
 *     • run server-side under Node (so `app-store.service.ts` can hand the
 *       browser a ready-to-sign TonConnect message),
 *     • emit `@ton/core` Cells instead of the legacy `ton` package types.
 *
 *   The compiled FunC contract hex is embedded inline (constants
 *   `JETTON_MINTER_CODE_HEX` / `JETTON_WALLET_CODE_HEX`) so deploys work
 *   without dropping any BoC files on the server.
 *
 *  Operations exposed to callers:
 *
 *  1) `buildDeployAndMintMessage` — the "deploy master + mint full supply
 *     to user" message that the user signs with their TonConnect wallet.
 *     After it lands, the master exists on-chain with `admin = userWallet`
 *     and the user's jetton wallet holds `amountToMint` Jettons. Single
 *     TonConnect message, mirrors `minter.ton.org`'s deploy flow exactly.
 *
 *  2) `deriveJettonWalletAddress` — deterministic `(master, owner) →
 *     jetton-wallet address`, same `data` layout as the audited contract.
 *
 *  3) `buildJettonTransferMessage` / `buildTonTransferMessage` — used by
 *     the LP-init flow to fund the platform vault, with text-comment
 *     forward payloads so the TON monitor can pair the two legs.
 *
 * Returns objects in the `{ address, amount, payload, stateInit? }` shape
 * expected by `tonConnectUI.sendTransaction(...).messages[]`. All numeric
 * fields are strings (TonConnect wire format).
 */
/**
 * Deploy gas budget, identical to minter.ton.org. Covers:
 *   • the deploy storage fees of the Jetton master,
 *   • forwarding 0.2 TON to the user's jetton wallet (deploy + mint).
 */
export declare const JETTON_DEPLOY_GAS_NANO: bigint;
export interface TonConnectMessage {
    address: string;
    amount: string;
    payload?: string;
    stateInit?: string;
}
export interface TonConnectTx {
    validUntil: number;
    messages: TonConnectMessage[];
}
/**
 * On-chain TIP-64 metadata fields. Only `name` and `symbol` are required.
 * `decimals` is stored as a *string* (per the TEP-64 spec). `image` should
 * be an HTTPS URL pointing to a 256×256 PNG; we fall back to no image if
 * the publisher hasn't uploaded a logo yet.
 */
export type JettonOnchainMetadata = {
    name: string;
    symbol: string;
    decimals?: string;
    description?: string;
    image?: string;
    image_data?: string;
};
/** Always true — contract code is embedded; no external BoCs to load. */
export declare function isJettonInfraReady(): boolean;
export interface BuildDeployAndMintParams {
    userWalletAddress: string;
    /**
     * On-chain TIP-64 metadata — stored inside the master contract itself
     * (no external HTTPS dependency). Wallets read this directly via
     * `get_jetton_data`. Minimum required: `name` + `symbol`.
     */
    metadata: JettonOnchainMetadata;
    /**
     * Total supply to mint to the publisher in atomic units (i.e. already
     * multiplied by `10 ** decimals`). The whole supply lands in the
     * publisher's jetton wallet immediately after deploy.
     */
    amountToMint: bigint;
    /** Optional override for the mint body queryId (default 0). */
    queryId?: bigint;
    /** Optional gas/value override (default = JETTON_DEPLOY_GAS_NANO). */
    attachedTonNano?: bigint;
}
export interface BuildDeployAndMintResult {
    jettonMasterAddress: string;
    message: TonConnectMessage;
    validUntil: number;
}
/**
 * Build the single TonConnect message that:
 *   1) Deploys the Jetton master with `admin = userWallet` and the embedded
 *      TIP-3 wallet code (same as minter.ton.org).
 *   2) Carries an inline mint body that pre-mints the entire `amountToMint`
 *      supply to the publisher's jetton wallet.
 *
 * The master address is deterministic (`contractAddress(0, {code, data})`),
 * so re-signing with the same `userWalletAddress` + metadata yields the
 * same address — re-deploys are idempotent.
 */
export declare function buildDeployAndMintMessage(params: BuildDeployAndMintParams): BuildDeployAndMintResult;
/**
 * Derive the deterministic Jetton wallet address for `(jettonMaster, owner)`.
 * Mirrors the on-chain `data` layout enforced by the audited wallet contract:
 *   { balance: Coins, owner: Address, master: Address, code: ^Cell }
 */
export declare function deriveJettonWalletAddress(opts: {
    jettonMasterAddress: string;
    ownerAddress: string;
}): {
    address: string;
    simulated: boolean;
};
export declare function buildJettonTransferMessage(opts: {
    userJettonWalletAddress: string;
    destinationOwnerAddress: string;
    amountAtomic: bigint;
    textComment: string;
    attachedTon?: string;
    forwardTon?: string;
}): TonConnectMessage;
export declare function buildTonTransferMessage(opts: {
    to: string;
    tonAmount: string;
    textComment?: string;
}): TonConnectMessage;
/** Convert TON whole-units to nanoTON BigInt. */
export declare function tonToNano(ton: number | string): bigint;
/** Address of the platform vault (collects fees + holds LP). */
export declare function platformVaultAddress(): string;
/** Public-facing config bundle for the publish flow. */
export declare function publishConfigSnapshot(): {
    publishFeeTon: number;
    initialLiquidityTon: number;
    initialLiquidityTokenShare: number;
    minInitialLiquidityTon: number;
    minInitialLiquidityTokenShare: number;
    tokenTotalSupply: number;
    vaultAddress: string;
    infraReady: boolean;
    tokenPreset: {
        decimals: number;
        defaultSupply: number;
        defaultDescription: string;
        mintMode: string;
        adminAddress: string;
        contractRepo: string;
        contractTemplate: string;
        deployGasTon: string;
        metadataMode: string;
    };
};
//# sourceMappingURL=jetton-tx-builder.service.d.ts.map