"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.runtimeConfig = exports.AGENT_COMPLEXITIES = exports.LINK_BOT_FEE_CREDITS = exports.PREVIEW_UNLOCK_FEE_CREDITS = exports.GAME_KIND_FEE_CREDITS = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const CONFIG_PATH = path_1.default.join(process.cwd(), "data", "runtime-config.json");
// One-time credit fees that aren't part of a per-action session price.
exports.GAME_KIND_FEE_CREDITS = 100;
exports.PREVIEW_UNLOCK_FEE_CREDITS = 20;
exports.LINK_BOT_FEE_CREDITS = 15;
exports.AGENT_COMPLEXITIES = ["trivial", "small", "medium", "large", "huge"];
// ── Default session configurations ───────────────────────────────────────────
const DEFAULT_AGENT_SESSIONS = {
    router: {
        model: "anthropic/claude-haiku-4-5",
        max_tokens: 1500,
        reasoning: false,
        thinking: 0,
        iterations: 8,
    },
    answer: {
        model: "anthropic/claude-haiku-4-5",
        max_tokens: 2000,
        reasoning: false,
        thinking: 0,
        iterations: 4,
    },
    build: {
        model: "anthropic/claude-sonnet-4-5",
        max_tokens: 32000,
        reasoning: false,
        thinking: 4000,
        iterations: 60,
    },
    update: {
        model: "anthropic/claude-sonnet-4-5",
        max_tokens: 32000,
        reasoning: false,
        thinking: 4000,
        iterations: 60,
    },
    "update-plan": {
        model: "anthropic/claude-sonnet-4-5",
        max_tokens: 32000,
        reasoning: false,
        thinking: 4000,
        iterations: 80,
    },
    "bug-fix": {
        model: "anthropic/claude-sonnet-4-5",
        max_tokens: 16000,
        reasoning: false,
        thinking: 2000,
        iterations: 40,
    },
    suggestions: {
        model: "anthropic/claude-haiku-4-5",
        max_tokens: 1000,
        reasoning: false,
        thinking: 0,
        iterations: 1,
    },
    context: {
        model: "anthropic/claude-haiku-4-5",
        max_tokens: 8000,
        reasoning: false,
        thinking: 0,
        iterations: 1,
    },
    // MAX MODE — top-tier model used when the user opts in. Same shape as any
    // other session config so admins can tune model, provider, tokens,
    // thinking budget, reasoning, and the iteration cap independently of the
    // standard build/update slots.
    "max-mode": {
        model: "anthropic/claude-opus-4-5",
        max_tokens: 32000,
        reasoning: false,
        thinking: 8000,
        iterations: 100,
    },
};
// Default credit prices. The medium column matches the previous flat rates so
// existing user expectations continue to hold while admins tune the rest.
const DEFAULT_AGENT_PRICING = {
    build: { trivial: 60, small: 80, medium: 100, large: 150, huge: 220 },
    update: { trivial: 25, small: 50, medium: 85, large: 130, huge: 200 },
    "update-plan": { trivial: 30, small: 50, medium: 80, large: 130, huge: 200 },
    "update-plan-per-item": { trivial: 10, small: 20, medium: 30, large: 45, huge: 65 },
    "bug-fix": { trivial: 10, small: 20, medium: 30, large: 50, huge: 80 },
};
/**
 * Normalise a possibly-legacy `agentPricing` blob from disk into the new
 * matrix shape. Two formats may appear:
 *  1. New shape — Record<type, Record<complexity, number>>. Pass through.
 *  2. Old shape — { build: number, update: number, "update-plan-base": number,
 *                   "update-plan-per-item": number, "bug-fix": number }. Map
 *     the flat number into the `medium` column and fan it out using ratios so
 *     existing prices stay roughly stable until admins re-edit them.
 *
 * Anything missing falls back to DEFAULT_AGENT_PRICING.
 */
function normalizeAgentPricing(raw) {
    if (!raw || typeof raw !== "object")
        return { ...DEFAULT_AGENT_PRICING };
    // Per-type ratio relative to medium for the legacy → matrix migration.
    const RATIO = {
        trivial: 0.4, small: 0.7, medium: 1.0, large: 1.5, huge: 2.2,
    };
    const fanOut = (mediumValue) => ({
        trivial: Math.max(1, Math.round(mediumValue * RATIO.trivial)),
        small: Math.max(1, Math.round(mediumValue * RATIO.small)),
        medium: Math.max(1, Math.round(mediumValue)),
        large: Math.max(1, Math.round(mediumValue * RATIO.large)),
        huge: Math.max(1, Math.round(mediumValue * RATIO.huge)),
    });
    const ensureRow = (key, legacyKey) => {
        const cell = raw[key];
        if (cell && typeof cell === "object" && !Array.isArray(cell)) {
            // Already matrix shape — merge missing complexities from defaults.
            return { ...DEFAULT_AGENT_PRICING[key], ...cell };
        }
        if (typeof cell === "number" && Number.isFinite(cell)) {
            return fanOut(cell);
        }
        if (legacyKey && typeof raw[legacyKey] === "number" && Number.isFinite(raw[legacyKey])) {
            return fanOut(raw[legacyKey]);
        }
        return { ...DEFAULT_AGENT_PRICING[key] };
    };
    return {
        build: ensureRow("build"),
        update: ensureRow("update"),
        "update-plan": ensureRow("update-plan", "update-plan-base"),
        "update-plan-per-item": ensureRow("update-plan-per-item"),
        "bug-fix": ensureRow("bug-fix"),
    };
}
const DEFAULTS = {
    creditsPerDollar: 50,
    slotPriceCredits: 30,
    minTopup: 2,
    maxAgentIterations: 60,
    firstTopupBonusPercent: 100,
    referralBonusPercent: 15,
    referralBonusUsd: 0,
    partnerDefaultPercent: 10,
    cashbackPercent: 50,
    cashbackEnabled: true,
    aiAvatarPriceUsd: 10,
    bundlePriceUsd: 50,
    defaultLanguage: "en",
    splashSecondsBeforeContinue: 3,
    agentTimeoutMs: 600_000,
    disableNewSignups: false,
    disableNewProjects: false,
    allowAdminShell: false,
    serviceMode: false,
    filesBrowserBaseUrl: process.env.NODE_ENV === "development" || process.env.DOMAIN === "dev.apps-father.com"
        ? "http://62.238.2.16:9090/files"
        : "http://204.168.219.20:9090/files",
    filesBrowserProjectsRoot: process.env.NODE_ENV === "development" || process.env.DOMAIN === "dev.apps-father.com"
        ? "/opt/apps-father-dev/projects"
        : "/opt/apps-father/projects",
    openrouterApiKey: "",
    trainingOpenrouterApiKey: "",
    trainingModel: "",
    trainingProvider: "",
    agentSessions: DEFAULT_AGENT_SESSIONS,
    agentPricing: DEFAULT_AGENT_PRICING,
    maxModeMultiplier: 3,
    appStore: {
        publishFeeTon: 0.5,
        tradingFeePercent: 1.0,
        creatorFeeShare: 0.40,
        // Default mirrors minter.ton.org — 1,000,000 tokens (precision 9).
        // Owners can change the supply via runtime config; the deploy + LP-init
        // flow always uses whatever is in `appStore.tokenTotalSupply`.
        tokenTotalSupply: 1_000_000,
        initialLiquidityTon: 5, // 5 TON locked into the pool by publisher
        initialLiquidityTokenShare: 0.5, // 50% of supply locked into the pool
        minInitialLiquidityTon: 1,
        minInitialLiquidityTokenShare: 0.1,
        curveSupplyShare: 0.80,
        initialVirtualTon: 30,
        minScreenshots: 4,
        maxScreenshots: 6,
        enabled: true,
    },
};
// ── Service class ────────────────────────────────────────────────────────────
class RuntimeConfigService {
    config = { ...DEFAULTS };
    constructor() {
        this.load();
    }
    load() {
        try {
            if (fs_1.default.existsSync(CONFIG_PATH)) {
                const raw = JSON.parse(fs_1.default.readFileSync(CONFIG_PATH, "utf-8"));
                // Migrate legacy bonus field
                if (raw && raw.firstTopupBonusUsd !== undefined && raw.firstTopupBonusPercent === undefined) {
                    raw.firstTopupBonusPercent = Number(raw.firstTopupBonusUsd) > 0 ? 100 : 0;
                    delete raw.firstTopupBonusUsd;
                }
                const agentSessions = this.mergeSessionConfigs(raw?.agentSessions);
                const agentPricing = normalizeAgentPricing(raw?.agentPricing);
                const appStore = { ...DEFAULTS.appStore, ...(raw?.appStore || {}) };
                this.config = {
                    ...DEFAULTS,
                    ...raw,
                    agentSessions,
                    agentPricing,
                    appStore,
                };
            }
        }
        catch {
            this.config = { ...DEFAULTS };
        }
    }
    mergeSessionConfigs(raw) {
        if (!raw || typeof raw !== "object")
            return { ...DEFAULT_AGENT_SESSIONS };
        const result = { ...DEFAULT_AGENT_SESSIONS };
        for (const key of Object.keys(DEFAULT_AGENT_SESSIONS)) {
            if (raw[key] && typeof raw[key] === "object") {
                result[key] = { ...DEFAULT_AGENT_SESSIONS[key], ...raw[key] };
            }
        }
        return result;
    }
    save() {
        const dir = path_1.default.dirname(CONFIG_PATH);
        fs_1.default.mkdirSync(dir, { recursive: true });
        fs_1.default.writeFileSync(CONFIG_PATH, JSON.stringify(this.config, null, 2), "utf-8");
    }
    get() {
        return { ...this.config };
    }
    update(partial) {
        const merged = { ...this.config, ...partial };
        if (partial.agentSessions) {
            merged.agentSessions = this.mergeSessionConfigs(partial.agentSessions);
        }
        // Floor the multiplier at 1.0 — sub-1 values would let a user pay LESS
        // than standard price by enabling MAX MODE, which defeats the toggle.
        if (typeof partial.maxModeMultiplier === "number") {
            merged.maxModeMultiplier = Math.max(1, Number(partial.maxModeMultiplier) || 1);
        }
        if (partial.agentPricing) {
            // Normalise (handles legacy flat shape sneaking back in) then deep-merge
            // by row so partial admin edits don't wipe other complexities.
            const incoming = normalizeAgentPricing(partial.agentPricing);
            merged.agentPricing = {
                build: { ...this.config.agentPricing.build, ...incoming.build },
                update: { ...this.config.agentPricing.update, ...incoming.update },
                "update-plan": { ...this.config.agentPricing["update-plan"], ...incoming["update-plan"] },
                "update-plan-per-item": { ...this.config.agentPricing["update-plan-per-item"], ...incoming["update-plan-per-item"] },
                "bug-fix": { ...this.config.agentPricing["bug-fix"], ...incoming["bug-fix"] },
            };
        }
        this.config = merged;
        this.save();
    }
    getMinTopup() { return this.config.minTopup; }
    getMaxAgentIterations() { return this.config.maxAgentIterations; }
    getOpenRouterApiKey() { return this.config.openrouterApiKey || ""; }
    /** DEDICATED key for the agent-feedback analysis pipeline (no fallback). */
    getTrainingApiKey() { return this.config.trainingOpenrouterApiKey || ""; }
    getTrainingModel() { return this.config.trainingModel || "anthropic/claude-sonnet-4-5"; }
    getTrainingProvider() { return this.config.trainingProvider || ""; }
    isServiceMode() { return !!this.config.serviceMode; }
    getCreditsPerDollar() { return this.config.creditsPerDollar || 50; }
    /** Returns the full AgentSessionConfig for the given session type. */
    getSessionConfig(type) {
        return this.config.agentSessions[type] ?? DEFAULT_AGENT_SESSIONS[type];
    }
    /**
     * Returns the credit cost for starting a session of this type and
     * complexity bucket. `complexity` defaults to "medium" if missing or
     * invalid, so callers in legacy code paths still get a price.
     *
     * For "update-plan" pass `planLength` to add the variable per-item cost.
     * Returns 0 for router / answer / suggestions / context.
     */
    getSessionCost(type, complexity, planLength) {
        const p = this.config.agentPricing;
        const c = complexity && exports.AGENT_COMPLEXITIES.includes(complexity) ? complexity : "medium";
        switch (type) {
            case "router":
            case "answer":
            case "suggestions":
            case "context":
            case "max-mode":
                return 0;
            case "build":
                return Math.max(0, p.build[c] | 0);
            case "update":
                return Math.max(0, p.update[c] | 0);
            case "bug-fix":
                return Math.max(0, p["bug-fix"][c] | 0);
            case "update-plan": {
                const base = Math.max(0, p["update-plan"][c] | 0);
                const perItem = Math.max(0, p["update-plan-per-item"][c] | 0);
                const items = Math.max(0, Math.min(50, planLength ?? 0)); // hard cap to prevent runaway prices
                return base + items * perItem;
            }
            default:
                return 0;
        }
    }
    /** Returns the full complexity matrix (read-only copy). */
    getAgentPricing() {
        return JSON.parse(JSON.stringify(this.config.agentPricing));
    }
    getAllSessionConfigs() {
        return { ...this.config.agentSessions };
    }
    /** Multiplier applied to the credit cost when MAX MODE is enabled. >= 1. */
    getMaxModeMultiplier() {
        const m = Number(this.config.maxModeMultiplier);
        return Number.isFinite(m) && m >= 1 ? m : 3;
    }
    /**
     * Resolve the effective session config for an agent run.
     *  - When `maxMode` is true we bypass the per-type config entirely and use
     *    the dedicated `max-mode` slot — admins set its model/tokens/iterations
     *    independent of the base type.
     *  - Without max mode this is identical to `getSessionConfig(type)`.
     */
    getEffectiveSessionConfig(type, maxMode) {
        if (maxMode)
            return this.getSessionConfig("max-mode");
        return this.getSessionConfig(type);
    }
}
exports.runtimeConfig = new RuntimeConfigService();
//# sourceMappingURL=runtime-config.service.js.map