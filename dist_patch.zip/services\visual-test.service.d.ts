export interface ConsoleEntry {
    type: "log" | "info" | "warn" | "error" | "debug";
    text: string;
    url?: string;
    line?: number;
}
export interface NetworkError {
    url: string;
    status?: number;
    statusText?: string;
    failure?: string;
}
/** A single step in a visual-test scenario. */
export type ScenarioStep = {
    target: string;
    type: "click";
} | {
    target: string;
    type: "input";
    value: string;
} | {
    delay: number;
};
export interface VisualTestResult {
    /** Base64-encoded PNG screenshot */
    screenshotBase64: string;
    /** All console entries captured during the test */
    consoleLogs: ConsoleEntry[];
    /** Only console.error() and unhandled JS errors */
    consoleErrors: ConsoleEntry[];
    /** Failed network requests */
    networkErrors: NetworkError[];
    /** Unhandled page-level JS errors */
    pageErrors: string[];
    /** Errors from scenario step execution (e.g. element not found) */
    scenarioErrors: string[];
    /** Page title at time of capture */
    pageTitle: string;
    /** Final URL (after any redirects) */
    finalUrl: string;
    /** Whether Playwright considered the page fully loaded */
    loadedSuccessfully: boolean;
    /** AI verdict from Claude */
    verdict: VisualVerdict;
    /** Raw ms taken for the browser session */
    durationMs: number;
}
export interface VisualVerdict {
    /** "pass" | "warn" | "fail" */
    status: "pass" | "warn" | "fail";
    /** 1-sentence headline */
    headline: string;
    /** Detailed multi-line analysis */
    analysis: string;
    /** Specific issues found */
    issues: string[];
    /** Suggestions for improvement */
    suggestions: string[];
}
export declare function runVisualTest(url: string, options?: {
    /** Viewport width. Default: 390 (iPhone 14) */
    viewportWidth?: number;
    /** Viewport height. Default: 844 */
    viewportHeight?: number;
    /** Max ms to wait for load. Default: 15000 */
    timeout?: number;
    /** Extra ms to let JS finish rendering after load (before scenario). Default: 2000 */
    settleMs?: number;
    /** Whether to emulate Telegram dark theme CSS vars. Default: true */
    emulateTelegram?: boolean;
    /** Optional sequence of interactions to run after page load. */
    scenario?: ScenarioStep[];
    /**
     * Raw initData string (query-string format, e.g. from buildSignedInitData).
     * When provided, it is appended to the URL as #tgWebAppData=... so the
     * AF SDK _parseMockHash() picks it up natively, fixing 401 errors.
     */
    initDataHash?: string;
}): Promise<VisualTestResult>;
export declare function formatVisualTestResult(result: VisualTestResult): string;
//# sourceMappingURL=visual-test.service.d.ts.map