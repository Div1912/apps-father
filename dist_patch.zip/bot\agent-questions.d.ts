interface PendingQuestion {
    resolve: (answer: string) => void;
    projectId: string;
    chatId: number;
    options: string[];
    createdAt: number;
}
export declare function setPending(projectId: string, chatId: number, options: string[], resolve: (answer: string) => void): void;
export declare function resolveByProject(projectId: string, answer: string): boolean;
export declare function resolveByChat(chatId: number, answer: string, messageDate?: number): boolean;
export declare function hasPendingForChat(chatId: number): boolean;
export declare function getPendingByProject(projectId: string): PendingQuestion | undefined;
export {};
//# sourceMappingURL=agent-questions.d.ts.map