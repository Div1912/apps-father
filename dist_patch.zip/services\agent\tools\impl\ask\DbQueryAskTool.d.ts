import type { AskTool } from "./AskTool";
import type { AskContext } from "./AskContext";
export declare class DbQueryAskTool implements AskTool {
    name: string;
    definition: {
        type: string;
        function: {
            name: string;
            description: string;
            parameters: {
                type: string;
                properties: {
                    action: {
                        type: string;
                        enum: string[];
                        description: string;
                    };
                    key: {
                        type: string;
                        description: string;
                    };
                    prefix: {
                        type: string;
                        description: string;
                    };
                    limit: {
                        type: string;
                        description: string;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
        };
    };
    execute(args: Record<string, any>, ctx: AskContext): Promise<string>;
}
//# sourceMappingURL=DbQueryAskTool.d.ts.map