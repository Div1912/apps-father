/**
 * Converts a raw markdown plan into HTML safe for Telegram,
 * stripping technical sections the user doesn't need to see.
 */
export declare function formatPlanForUser(raw: string): string;
//# sourceMappingURL=plan-formatter.d.ts.map