import { AgentMode } from "./types";
export interface TestRunFlags {
    telegram: boolean;
    api: boolean;
    ws: boolean;
}
export interface TestResult {
    tool: string;
    ok: boolean;
    detail: string;
}
export interface WsCoverage {
    types: Set<string>;
    scenarios: Set<string>;
}
export declare function dirHasFiles(dir: string): boolean;
export declare function extractRoutes(content: string): Array<{
    method: string;
    path: string;
}>;
export declare function plannedEndpoints(plan: any): Array<{
    method: string;
    path: string;
}>;
export declare function validatePlannedEndpoints(routesContent: string, plan: any): string | null;
export declare function plannedWsTypes(plan: any): string[];
export declare function plannedServerWsTypes(plan: any): string[];
export declare function validatePlannedWsTypes(allCode: string, plan: any): string | null;
export declare function plannedWsScenarioIds(plan: any): string[];
export declare function observedWsTypes(sim: any): Set<string>;
export declare function validateWsSimulation(sim: any, plan: any): string | null;
export declare function validateFrontendMarkup(frontendText: string, projectDir?: string): string[];
export declare function validateBackendRoutes(projectDir: string, projectId: string, technicalPlan?: any): string | null;
export declare function validateFinishReadiness(mode: AgentMode, technicalPlan: any, testsRun: TestRunFlags, deployed: boolean, testResults?: TestResult[], wsCoverage?: WsCoverage, hasBotToken?: boolean): string | null;
//# sourceMappingURL=validation.d.ts.map