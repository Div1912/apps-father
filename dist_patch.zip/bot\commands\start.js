"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getWelcomeCaption = getWelcomeCaption;
exports.buildMiniAppUrl = buildMiniAppUrl;
exports.buildWelcomeKeyboard = buildWelcomeKeyboard;
exports.getNavWelcomeText = getNavWelcomeText;
exports.startCommand = startCommand;
const grammy_1 = require("grammy");
const path_1 = __importDefault(require("path"));
const project_service_1 = require("../../services/project.service");
const emoji_1 = require("../emoji");
const db_1 = require("../../db");
const library_1 = require("@prisma/client/runtime/library");
const i18n_1 = require("../i18n");
const config_1 = require("../../config");
function getWelcomeCaption(lang) {
    return (`<b>${(0, emoji_1.ce)(emoji_1.EMOJI.logo)} ${(0, i18n_1.t)(lang, "welcome_caption_title")}</b> - ${(0, i18n_1.t)(lang, "welcome_caption_desc")}\n\n` +
        `<b>${(0, emoji_1.ce)(emoji_1.EMOJI.idea)} ${(0, i18n_1.t)(lang, "welcome_caption_idea")}</b>\n` +
        `${(0, i18n_1.t)(lang, "welcome_caption_body")}\n\n` +
        `<b>${(0, emoji_1.ce)(emoji_1.EMOJI.list)} ${(0, i18n_1.t)(lang, "welcome_caption_samples")}</b>\n` +
        `${(0, i18n_1.t)(lang, "welcome_caption_samples_body")} \n\n` +
        `${(0, emoji_1.ce)(emoji_1.EMOJI.indicator_none)} <a href="https://t.me/InstagramMysbot"><b>GramMini</b></a>   ${(0, emoji_1.ce)(emoji_1.EMOJI.indicator_none)} <a href="https://t.me/teleweatherabot"><b>TeleWeather</b></a>   ${(0, emoji_1.ce)(emoji_1.EMOJI.indicator_none)} <a href="https://t.me/pixelduel7bot"><b>Pixel Duel</b></a>   ${(0, emoji_1.ce)(emoji_1.EMOJI.indicator_none)} <a href="https://t.me/my_best_ton_walletbot"><b>TON Wallet</b></a>`);
}
function buildMiniAppUrl(startParam) {
    const base = `${config_1.config.baseUrl}/telegram-mini-app/`;
    return startParam ? `${base}?startapp=${encodeURIComponent(startParam)}` : base;
}
function buildWelcomeKeyboard(lang, startParam) {
    const keyboard = new grammy_1.InlineKeyboard().webApp((0, i18n_1.t)(lang, "btn_create_app"), buildMiniAppUrl(startParam));
    const btnRow = keyboard.inline_keyboard;
    if (btnRow?.[0]?.[0])
        btnRow[0][0].style = "primary";
    return keyboard;
}
function getNavWelcomeText(balance, lang = "en") {
    return `<b>${(0, emoji_1.ce)(emoji_1.EMOJI.logo)} Apps Father</b>\n\n` +
        `<blockquote><b>${(0, emoji_1.ce)(emoji_1.EMOJI.setting)}  ${(0, i18n_1.t)(lang, "nav_welcome_blockquote")}</b></blockquote>\n\n` +
        `${(0, emoji_1.ce)(emoji_1.EMOJI.dollar, "💲")} <b>${(0, i18n_1.t)(lang, "nav_welcome_balance", { balance: balance.toFixed(2) })}</b>\n` +
        `${(0, i18n_1.t)(lang, "nav_welcome_balance_desc")}\n\n` +
        `<b>${(0, i18n_1.t)(lang, "nav_welcome_cta")}</b>`;
}
async function startCommand(ctx) {
    const from = ctx.from;
    if (!from)
        return;
    ctx.session.awaitingInput = null;
    ctx.session.activeProjectId = undefined;
    ctx.session.pendingPlan = undefined;
    ctx.session.pendingDescription = undefined;
    ctx.session.conversationState = "idle";
    const startParam = ctx.match ? String(ctx.match) : undefined;
    let referredBy = startParam && /^\d+$/.test(startParam) ? parseInt(startParam, 10) : undefined;
    // Non-numeric, non-voucher start params are kept as a marketing source
    // tag (utm_source). For partner tags we additionally set referredBy
    // below; for plain campaign tags (e.g. "ga_direct_ww_0") we only set
    // utm_source. Numeric start params (legacy referrer-only links) and
    // voucher codes do NOT contribute to source.
    const utmSource = startParam && !referredBy && !startParam.startsWith("v_") ? startParam : null;
    // Resolve partner tag to referrer telegramId
    let partnerBonus = null;
    if (!referredBy && startParam && !startParam.startsWith("v_")) {
        try {
            const partner = await db_1.prisma.user.findUnique({ where: { partnerTag: startParam } });
            if (partner && partner.isPartner) {
                referredBy = Number(partner.telegramId);
                if (partner.partnerReferralBonus && Number(partner.partnerReferralBonus) > 0) {
                    partnerBonus = Number(partner.partnerReferralBonus);
                }
            }
        }
        catch (err) {
            console.error("[Start] Partner tag lookup error:", err);
        }
    }
    const { user } = await project_service_1.projectService.getOrCreateUser(from.id, from.username, from.first_name, referredBy, utmSource);
    // Credit partner referral bonus to new user
    if (partnerBonus && user.referredBy) {
        try {
            const alreadyHasBalance = Number(user.balance) > 0;
            if (!alreadyHasBalance) {
                await db_1.prisma.user.update({
                    where: { id: user.id },
                    data: { balance: { increment: new library_1.Decimal(partnerBonus.toFixed(4)) } },
                });
                console.log(`[Start] Partner referral bonus $${partnerBonus.toFixed(2)} credited to user ${user.id}`);
            }
        }
        catch (err) {
            console.error("[Start] Partner referral bonus error:", err);
        }
    }
    ctx.session.language = user.language || "en";
    const lang = ctx.session.language;
    let voucherMsg = null;
    if (startParam && startParam.startsWith("v_")) {
        try {
            const voucher = await db_1.prisma.voucher.findUnique({ where: { code: startParam } });
            if (voucher && voucher.active && voucher.usedCount < voucher.maxUses) {
                const alreadyUsed = await db_1.prisma.voucherRedemption.findUnique({
                    where: { voucherId_userId: { voucherId: voucher.id, userId: user.id } },
                });
                if (!alreadyUsed) {
                    const isCredits = voucher.credits > 0;
                    await db_1.prisma.$transaction(async (tx) => {
                        if (isCredits) {
                            await tx.user.update({
                                where: { id: user.id },
                                data: { credits: { increment: voucher.credits } },
                            });
                        }
                        else {
                            await tx.user.update({
                                where: { id: user.id },
                                data: { balance: { increment: new library_1.Decimal(Number(voucher.amountUsd).toFixed(4)) } },
                            });
                        }
                        await tx.voucher.update({
                            where: { id: voucher.id },
                            data: { usedCount: { increment: 1 } },
                        });
                        await tx.voucherRedemption.create({
                            data: { voucherId: voucher.id, userId: user.id },
                        });
                    });
                    voucherMsg = isCredits
                        ? `${(0, emoji_1.ce)(emoji_1.EMOJI.indicator_success, "✅")} <b>${(0, i18n_1.t)(lang, "voucher_redeemed")}</b>\n\n🪙 <b>+${voucher.credits.toLocaleString()} credits</b> added to your balance!`
                        : `${(0, emoji_1.ce)(emoji_1.EMOJI.indicator_success, "✅")} <b>${(0, i18n_1.t)(lang, "voucher_redeemed")}</b>\n\n` +
                            (0, i18n_1.t)(lang, "voucher_redeemed_detail", { amount: Number(voucher.amountUsd).toFixed(2) });
                }
                else {
                    voucherMsg = `${(0, emoji_1.ce)(emoji_1.EMOJI.indicator_warning, "⚠️")} ${(0, i18n_1.t)(lang, "voucher_already_used")}`;
                }
            }
            else if (voucher && (!voucher.active || voucher.usedCount >= voucher.maxUses)) {
                voucherMsg = `${(0, emoji_1.ce)(emoji_1.EMOJI.indicator_error, "❌")} ${(0, i18n_1.t)(lang, "voucher_expired")}`;
            }
        }
        catch (err) {
            console.error("[Start] Voucher redemption error:", err);
        }
    }
    const imagePath = path_1.default.join(__dirname, "..", "..", "..", "assets", "bot_images", "welcome.png");
    const chatId = ctx.chat.id;
    const hideMsg = await ctx.reply("⏳", { reply_markup: { remove_keyboard: true } });
    await ctx.api.deleteMessage(chatId, hideMsg.message_id);
    const keyboard = buildWelcomeKeyboard(lang, startParam);
    try {
        await ctx.replyWithPhoto(new grammy_1.InputFile(imagePath), {
            caption: getWelcomeCaption(lang),
            parse_mode: "HTML",
            reply_markup: keyboard,
        });
    }
    catch (err) {
        console.error("[Start] Failed to send photo, sending text:", err);
        await ctx.reply(getWelcomeCaption(lang), {
            parse_mode: "HTML",
            reply_markup: keyboard,
        });
    }
    if (voucherMsg) {
        setTimeout(async () => {
            try {
                await ctx.api.sendMessage(chatId, voucherMsg, { parse_mode: "HTML" });
            }
            catch (err) {
                console.error("[Start] Failed to send voucher message:", err);
            }
        }, 1500);
    }
}
//# sourceMappingURL=start.js.map