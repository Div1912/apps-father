"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.builderService = exports.BuilderService = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const PROJECTS_DIR = path_1.default.join(process.cwd(), "projects");
class BuilderService {
    getProjectDir(projectId) {
        return path_1.default.join(PROJECTS_DIR, projectId);
    }
    async scaffoldProject(projectId, app) {
        const projectDir = this.getProjectDir(projectId);
        const frontendDir = path_1.default.join(projectDir, "frontend");
        const backendDir = path_1.default.join(projectDir, "backend");
        const assetsDir = path_1.default.join(frontendDir, "assets");
        fs_1.default.mkdirSync(frontendDir, { recursive: true });
        fs_1.default.mkdirSync(backendDir, { recursive: true });
        fs_1.default.mkdirSync(assetsDir, { recursive: true });
        for (const file of app.frontend) {
            this.writeFile(frontendDir, file);
        }
        for (const file of app.backend) {
            this.writeFile(backendDir, file);
        }
        if (app.schema) {
            fs_1.default.writeFileSync(path_1.default.join(projectDir, "schema.sql"), app.schema, "utf-8");
        }
        const configData = {
            projectId,
            botDescription: app.botDescription,
            botCommands: app.botCommands,
            createdAt: new Date().toISOString(),
        };
        fs_1.default.writeFileSync(path_1.default.join(projectDir, "config.json"), JSON.stringify(configData, null, 2), "utf-8");
        console.log(`[Builder] Project ${projectId} scaffolded at ${projectDir}`);
    }
    async updateProject(projectId, app) {
        const projectDir = this.getProjectDir(projectId);
        const frontendDir = path_1.default.join(projectDir, "frontend");
        const backendDir = path_1.default.join(projectDir, "backend");
        for (const file of app.frontend) {
            this.writeFile(frontendDir, file);
        }
        for (const file of app.backend) {
            this.writeFile(backendDir, file);
        }
        if (app.schema) {
            fs_1.default.writeFileSync(path_1.default.join(projectDir, "schema.sql"), app.schema, "utf-8");
        }
        console.log(`[Builder] Project ${projectId} updated`);
    }
    getProjectCode(projectId) {
        const projectDir = this.getProjectDir(projectId);
        if (!fs_1.default.existsSync(projectDir))
            return null;
        const result = {};
        const readDir = (dir, prefix) => {
            if (!fs_1.default.existsSync(dir))
                return;
            const entries = fs_1.default.readdirSync(dir, { withFileTypes: true });
            for (const entry of entries) {
                if (entry.isFile()) {
                    const filePath = path_1.default.join(dir, entry.name);
                    result[`${prefix}/${entry.name}`] = fs_1.default.readFileSync(filePath, "utf-8");
                }
            }
        };
        readDir(path_1.default.join(projectDir, "frontend"), "frontend");
        readDir(path_1.default.join(projectDir, "backend"), "backend");
        const schemaPath = path_1.default.join(projectDir, "schema.sql");
        if (fs_1.default.existsSync(schemaPath)) {
            result["schema.sql"] = fs_1.default.readFileSync(schemaPath, "utf-8");
        }
        return JSON.stringify(result, null, 2);
    }
    projectExists(projectId) {
        return fs_1.default.existsSync(this.getProjectDir(projectId));
    }
    writeFile(baseDir, file) {
        const filePath = path_1.default.join(baseDir, file.path);
        const dir = path_1.default.dirname(filePath);
        fs_1.default.mkdirSync(dir, { recursive: true });
        fs_1.default.writeFileSync(filePath, file.content, "utf-8");
    }
}
exports.BuilderService = BuilderService;
exports.builderService = new BuilderService();
//# sourceMappingURL=builder.service.js.map