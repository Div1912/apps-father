import { BotContext } from "../../types";
export declare function helpCommand(ctx: BotContext): Promise<void>;
//# sourceMappingURL=help.d.ts.map