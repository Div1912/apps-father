import type { AskTool } from "./AskTool";
import type { AskContext } from "./AskContext";
export declare class ProjectInfoAskTool implements AskTool {
    name: string;
    definition: {
        type: string;
        function: {
            name: string;
            description: string;
            parameters: {
                type: string;
                properties: {};
                additionalProperties: boolean;
            };
        };
    };
    execute(_args: Record<string, any>, ctx: AskContext): Promise<string>;
}
//# sourceMappingURL=ProjectInfoAskTool.d.ts.map