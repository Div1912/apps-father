"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GrepTool = void 0;
const child_process_1 = require("child_process");
const util_1 = require("util");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const execAsync = (0, util_1.promisify)(child_process_1.exec);
class GrepTool {
    renderDefinition() {
        return {
            type: "function",
            function: {
                name: "grep",
                description: "Search for a pattern in project files. Returns matching lines with file:line format. Supports regex.",
                parameters: {
                    type: "object",
                    properties: {
                        pattern: { type: "string", description: "Search pattern (regex supported)" },
                        path: { type: "string", description: "Relative path to search in (default: entire project)" },
                        include: { type: "string", description: "Glob pattern for file names to include (e.g. '*.js')" },
                    },
                    required: ["pattern"],
                },
            },
        };
    }
    async execute(args, ctx) {
        await ctx.progress({ action: "🔍 Searching", detail: args.pattern, percent: ctx.currentPercent });
        const resolvedPath = args.path ? this._safePath(ctx.projectDir, args.path) : null;
        if (args.path && !resolvedPath)
            return "Error: Invalid path";
        let cwd = ctx.projectDir;
        let target = ".";
        if (resolvedPath) {
            if (fs_1.default.existsSync(resolvedPath) && fs_1.default.statSync(resolvedPath).isFile()) {
                cwd = path_1.default.dirname(resolvedPath);
                target = path_1.default.basename(resolvedPath);
            }
            else {
                cwd = resolvedPath;
            }
        }
        const escapedPattern = args.pattern.replace(/"/g, '\\"');
        const cmd = args.include
            ? `grep -rEn --include="${args.include}" "${escapedPattern}" ${target}`
            : `grep -rEn "${escapedPattern}" ${target}`;
        try {
            const { stdout } = await execAsync(cmd, { cwd, timeout: 10000, maxBuffer: 512 * 1024 });
            const lines = stdout.split("\n").filter(l => l.trim()).slice(0, 50);
            return lines.length > 0 ? lines.join("\n") : "No matches found";
        }
        catch (err) {
            if (err.code === 1)
                return "No matches found";
            return `Error: ${(err.stderr || err.message || "grep failed").substring(0, 1000)}`;
        }
    }
    _safePath(projectDir, relativePath) {
        if (!relativePath || relativePath.includes(".."))
            return null;
        const full = path_1.default.join(projectDir, relativePath);
        if (!full.startsWith(projectDir))
            return null;
        return full;
    }
}
exports.GrepTool = GrepTool;
//# sourceMappingURL=GrepTool.js.map