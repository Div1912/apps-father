export declare const EMOJI: {
    readonly logo: "5377800565038291987";
    readonly add: "5377849514780565387";
    readonly list: "5377847332937176471";
    readonly help: "5375600227522747250";
    readonly idea: "5375431280689195655";
    readonly indicator_none: "5377349430263454459";
    readonly indicator_warning: "5377739043926742111";
    readonly indicator_error: "5377728267853796087";
    readonly indicator_success: "5377544696656599429";
    readonly update: "5377794122587351169";
    readonly setting: "5377796922906024957";
    readonly dollar: "5377851954321989517";
    readonly mark_empty: "5386836201271501633";
    readonly mark_done: "5386312984060534078";
    readonly progress_start_empty: "5386652488340379423";
    readonly progress_empty: "5386436812262644830";
    readonly progress_end_empty: "5386828891237158955";
    readonly progress_start_full: "5386340802563709741";
    readonly progress_full: "5386681015513157928";
    readonly progress_end_full: "5386625885312949408";
    readonly loading: "5309893756244206277";
    readonly crypto_bot: "5361914370068613491";
    readonly usdt: "5406841020769936275";
    readonly stars: "5406812184359507637";
};
export declare function ce(id: string, fallback?: string): string;
export declare function statusIndicator(status: string): string;
//# sourceMappingURL=emoji.d.ts.map