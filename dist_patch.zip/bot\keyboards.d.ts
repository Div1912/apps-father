import { Lang } from "./i18n";
export declare function createAppKeyboard(lang: Lang | undefined, miniAppUrl: string): {
    text: string;
    web_app: {
        url: string;
    };
    style: string;
};
export declare function replyKeyboard(lang?: Lang): {
    keyboard: {
        text: string;
        icon_custom_emoji_id: "5377847332937176471";
    }[][];
    resize_keyboard: boolean;
};
export declare function welcomeKeyboard(lang?: Lang): {
    inline_keyboard: (({
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5377849514780565387";
    } | {
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5377847332937176471";
    })[] | ({
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5377851954321989517";
    } | {
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5375431280689195655";
    })[] | ({
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5377796922906024957";
    } | {
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5375600227522747250";
    })[])[];
};
export declare function languageKeyboard(currentLang: Lang): {
    inline_keyboard: any[][];
};
export declare function createBotKeyboard(suggestedName?: string): {
    keyboard: {
        text: string;
        icon_custom_emoji_id: "5377849514780565387";
        request_managed_bot: {
            suggested_name?: string | undefined;
            request_id: number;
        };
    }[][];
    resize_keyboard: boolean;
    one_time_keyboard: boolean;
};
export declare function projectListKeyboard(projects: {
    id: string;
    name: string;
    status: string;
}[], slotsAvailable?: boolean, lang?: Lang): {
    inline_keyboard: any[][];
};
export declare function projectActionsKeyboard(projectId: string, status: string, features?: string[], botUsername?: string, lang?: Lang): {
    inline_keyboard: any[][];
};
export declare function settingsKeyboard(projectId: string, lang?: Lang): {
    inline_keyboard: ({
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5375600227522747250";
    }[] | {
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5377794122587351169";
    }[] | {
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5377739043926742111";
    }[] | ({
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5377728267853796087";
    } | {
        text: string;
        callback_data: string;
        icon_custom_emoji_id?: undefined;
    })[])[];
};
export declare function featuresKeyboard(projectId: string, unlockedFeatures: string[], lang?: Lang): {
    inline_keyboard: any[][];
};
export declare function confirmBuyKeyboard(projectId: string, featureId: string, lang?: Lang): {
    inline_keyboard: ({
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5377544696656599429";
    }[] | {
        text: string;
        callback_data: string;
    }[])[];
};
export declare function removeConfirmKeyboard(projectId: string, lang?: Lang): {
    inline_keyboard: ({
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5377728267853796087";
    }[] | {
        text: string;
        callback_data: string;
    }[])[];
};
export declare function planActionKeyboard(projectId: string, lang?: Lang): {
    inline_keyboard: ({
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5377544696656599429";
    }[] | ({
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5377794122587351169";
    } | {
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5377728267853796087";
    })[])[];
};
export declare function suggestionsKeyboard(projectId: string, suggestions: string[], lang?: Lang): {
    inline_keyboard: any[][];
};
export declare function versionsKeyboard(projectId: string, commits: {
    version: string;
    changelog: string | null;
    createdAt: Date;
}[], releaseCommit: number | null, lang?: Lang): {
    inline_keyboard: any[][];
};
export declare function revertConfirmKeyboard(projectId: string, commitNum: string, lang?: Lang): {
    inline_keyboard: ({
        text: string;
        callback_data: string;
        icon_custom_emoji_id: "5377739043926742111";
    }[] | {
        text: string;
        callback_data: string;
    }[])[];
};
export declare function helpKeyboard(lang?: Lang): {
    inline_keyboard: ({
        text: string;
        url: string;
    }[] | {
        text: string;
        callback_data: string;
    }[])[];
};
export declare function backToProjectKeyboard(projectId: string, lang?: Lang): {
    inline_keyboard: {
        text: string;
        callback_data: string;
    }[][];
};
//# sourceMappingURL=keyboards.d.ts.map