declare const router: import("express-serve-static-core").Router;
export declare function getOutLog(): string;
export declare function getErrLog(): string;
/** Read the tail (last N lines) of a log file. Caps the read at 512 KB so
 *  enormous log files still respond quickly. Returns an array of trimmed
 *  lines from oldest → newest. */
export declare function readTailLines(filePath: string, lines: number): string[];
export default router;
//# sourceMappingURL=logs.routes.d.ts.map