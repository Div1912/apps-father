import type { AskTool } from "./tools/impl/ask/AskTool";
import type { AskContext } from "./tools/impl/ask/AskContext";
export interface AskRunnerOpts {
    modelCfg: any;
    systemPrompt: string;
    messages: any[];
    tools: AskTool[];
    ctx: AskContext;
    onChunk: (delta: string, full: string) => void;
    telegramId?: string;
    sessionId?: string;
}
export interface AskRunnerResult {
    text: string;
    inputTokens: number;
    outputTokens: number;
    /** Sum of `usage.cost` across iterations. 0 if OR didn't return cost. */
    costUsd: number;
    costUsdInput: number;
    costUsdOutput: number;
}
/**
 * Simplified runner for the answerQuestionStream tool-use loop.
 * Mirrors AgentRunner's fluent pattern but with the lighter ask-tool context.
 */
export declare class AskRunner {
    run(opts: AskRunnerOpts): Promise<AskRunnerResult>;
    private _getProviderRouting;
    private _streamCall;
}
//# sourceMappingURL=AskRunner.d.ts.map