"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAppKeyboard = createAppKeyboard;
exports.replyKeyboard = replyKeyboard;
exports.welcomeKeyboard = welcomeKeyboard;
exports.languageKeyboard = languageKeyboard;
exports.createBotKeyboard = createBotKeyboard;
exports.projectListKeyboard = projectListKeyboard;
exports.projectActionsKeyboard = projectActionsKeyboard;
exports.settingsKeyboard = settingsKeyboard;
exports.featuresKeyboard = featuresKeyboard;
exports.confirmBuyKeyboard = confirmBuyKeyboard;
exports.removeConfirmKeyboard = removeConfirmKeyboard;
exports.planActionKeyboard = planActionKeyboard;
exports.suggestionsKeyboard = suggestionsKeyboard;
exports.versionsKeyboard = versionsKeyboard;
exports.revertConfirmKeyboard = revertConfirmKeyboard;
exports.helpKeyboard = helpKeyboard;
exports.backToProjectKeyboard = backToProjectKeyboard;
const emoji_1 = require("./emoji");
const features_service_1 = require("../services/features.service");
const config_1 = require("../config");
const i18n_1 = require("./i18n");
function createAppKeyboard(lang = "en", miniAppUrl) {
    return {
        text: `${(0, i18n_1.t)(lang, "btn_create_app")}`,
        web_app: { url: miniAppUrl },
        style: "primary",
    };
}
function replyKeyboard(lang = "en") {
    return {
        keyboard: [
            [
                {
                    text: (0, i18n_1.t)(lang, "main_menu"),
                    icon_custom_emoji_id: emoji_1.EMOJI.list
                },
            ],
        ],
        resize_keyboard: true,
    };
}
function welcomeKeyboard(lang = "en") {
    return {
        inline_keyboard: [
            [
                { text: (0, i18n_1.t)(lang, "btn_create_app"), callback_data: "new_project", icon_custom_emoji_id: emoji_1.EMOJI.add },
                { text: (0, i18n_1.t)(lang, "btn_app_list"), callback_data: "my_projects", icon_custom_emoji_id: emoji_1.EMOJI.list },
            ],
            [
                { text: (0, i18n_1.t)(lang, "btn_topup"), callback_data: "topup", icon_custom_emoji_id: emoji_1.EMOJI.dollar },
                { text: (0, i18n_1.t)(lang, "btn_referral"), callback_data: "referral", icon_custom_emoji_id: emoji_1.EMOJI.idea },
            ],
            [
                { text: (0, i18n_1.t)(lang, "btn_language"), callback_data: "language", icon_custom_emoji_id: emoji_1.EMOJI.setting },
                { text: (0, i18n_1.t)(lang, "btn_help"), callback_data: "help", icon_custom_emoji_id: emoji_1.EMOJI.help },
            ],
        ],
    };
}
function languageKeyboard(currentLang) {
    const langs = ["en", "ru", "ua"];
    const rows = langs.map(l => [{
            text: `${l === currentLang ? "✅ " : ""}${i18n_1.LANG_NAMES[l]}`,
            callback_data: `lang:${l}`,
            icon_custom_emoji_id: l === currentLang ? emoji_1.EMOJI.indicator_success : emoji_1.EMOJI.indicator_none,
        }]);
    rows.push([{ text: (0, i18n_1.t)(currentLang, "btn_back"), callback_data: "nav_welcome" }]);
    return { inline_keyboard: rows };
}
function createBotKeyboard(suggestedName) {
    return {
        keyboard: [
            [
                {
                    text: "Create App & Bot",
                    icon_custom_emoji_id: emoji_1.EMOJI.add,
                    request_managed_bot: {
                        request_id: 1,
                        ...(suggestedName ? { suggested_name: suggestedName } : {}),
                    },
                },
            ],
        ],
        resize_keyboard: true,
        one_time_keyboard: true,
    };
}
function projectListKeyboard(projects, slotsAvailable = true, lang = "en") {
    const rows = projects.map((p) => [
        { text: p.name, callback_data: `project:${p.id}`, icon_custom_emoji_id: statusEmojiId(p.status) },
    ]);
    if (!slotsAvailable) {
        rows.push([{ text: (0, i18n_1.t)(lang, "buy_slot_btn"), callback_data: "buy_slot", icon_custom_emoji_id: emoji_1.EMOJI.add }]);
    }
    rows.push([{ text: (0, i18n_1.t)(lang, "btn_back"), callback_data: "nav_welcome" }]);
    return { inline_keyboard: rows };
}
function projectActionsKeyboard(projectId, status, features = [], botUsername, lang = "en") {
    const rows = [];
    if (status === "deployed" || status === "released") {
        const devUrl = `${config_1.config.baseUrl}/dev/${projectId}/`;
        rows.push([
            { text: (0, i18n_1.t)(lang, "btn_open_app"), web_app: { url: devUrl } },
            { text: (0, i18n_1.t)(lang, "btn_release_version"), callback_data: `release:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.indicator_success },
        ]);
        rows.push([
            { text: (0, i18n_1.t)(lang, "btn_update_app"), callback_data: `update_app:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.update },
            { text: (0, i18n_1.t)(lang, "btn_versions"), callback_data: `versions:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.list },
        ]);
        const extraRow = [];
        if (features.includes("admin_panel")) {
            extraRow.push({ text: (0, i18n_1.t)(lang, "btn_admin_panel"), callback_data: `admin:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.setting });
        }
        if (features.includes("get_code")) {
            extraRow.push({ text: (0, i18n_1.t)(lang, "btn_edit_code"), callback_data: `edit_code:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.setting });
        }
        if (extraRow.length > 0)
            rows.push(extraRow);
        rows.push([
            { text: (0, i18n_1.t)(lang, "btn_suggestions"), callback_data: `suggest:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.idea },
        ]);
    }
    else if (status === "planning" || status === "created") {
        rows.push([
            { text: (0, i18n_1.t)(lang, "btn_describe_app"), callback_data: `describe:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.idea },
        ]);
    }
    const featuresRow = [
        { text: (0, i18n_1.t)(lang, "btn_features"), callback_data: `features:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.dollar },
    ];
    if (features.includes("ton_payment")) {
        featuresRow.push({ text: (0, i18n_1.t)(lang, "btn_wallet"), callback_data: `wallet:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.dollar });
    }
    rows.push(featuresRow);
    rows.push([
        { text: (0, i18n_1.t)(lang, "btn_settings"), callback_data: `settings:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.setting },
        { text: (0, i18n_1.t)(lang, "btn_back"), callback_data: "nav_list" },
    ]);
    return { inline_keyboard: rows };
}
function settingsKeyboard(projectId, lang = "en") {
    return {
        inline_keyboard: [
            [
                { text: (0, i18n_1.t)(lang, "btn_get_info"), callback_data: `info:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.help },
            ],
            [
                { text: (0, i18n_1.t)(lang, "btn_regen_context"), callback_data: `regen_context:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.update },
            ],
            [
                { text: (0, i18n_1.t)(lang, "btn_transfer"), callback_data: `transfer:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.indicator_warning },
            ],
            [
                { text: (0, i18n_1.t)(lang, "btn_remove"), callback_data: `remove_project:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.indicator_error },
                { text: (0, i18n_1.t)(lang, "btn_back"), callback_data: `project:${projectId}` },
            ],
        ],
    };
}
function featuresKeyboard(projectId, unlockedFeatures, lang = "en") {
    const rows = features_service_1.PAID_FEATURES.map(f => {
        const owned = unlockedFeatures.includes(f.id);
        const label = (0, i18n_1.translateFeatureLabel)(lang, f.id) || f.label;
        return [{
                text: owned ? `✅ ${label}` : `🔒 ${label} — $${f.price}`,
                callback_data: owned ? `fo:${projectId}:${f.id}` : `bf:${projectId}:${f.id}`,
            }];
    });
    rows.push([{ text: (0, i18n_1.t)(lang, "btn_back"), callback_data: `project:${projectId}` }]);
    return { inline_keyboard: rows };
}
function confirmBuyKeyboard(projectId, featureId, lang = "en") {
    return {
        inline_keyboard: [
            [{ text: (0, i18n_1.t)(lang, "btn_confirm_purchase"), callback_data: `cb:${projectId}:${featureId}`, icon_custom_emoji_id: emoji_1.EMOJI.indicator_success }],
            [{ text: (0, i18n_1.t)(lang, "btn_cancel"), callback_data: `features:${projectId}` }],
        ],
    };
}
function removeConfirmKeyboard(projectId, lang = "en") {
    return {
        inline_keyboard: [
            [
                { text: (0, i18n_1.t)(lang, "btn_yes_delete"), callback_data: `confirm_remove:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.indicator_error },
            ],
            [
                { text: (0, i18n_1.t)(lang, "btn_cancel"), callback_data: `project:${projectId}` },
            ],
        ],
    };
}
function planActionKeyboard(projectId, lang = "en") {
    return {
        inline_keyboard: [
            [
                { text: (0, i18n_1.t)(lang, "btn_approve_build"), callback_data: `approve_plan:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.indicator_success },
            ],
            [
                { text: (0, i18n_1.t)(lang, "btn_modify"), callback_data: `modify_plan:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.update },
                { text: (0, i18n_1.t)(lang, "btn_decline"), callback_data: `decline_plan:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.indicator_error },
            ],
        ],
    };
}
function suggestionsKeyboard(projectId, suggestions, lang = "en") {
    const rows = suggestions.map((_, i) => [
        { text: (0, i18n_1.t)(lang, "btn_apply", { n: String(i + 1) }), callback_data: `apply_suggestion:${projectId}:${i}`, icon_custom_emoji_id: emoji_1.EMOJI.indicator_success },
    ]);
    rows.push([
        { text: (0, i18n_1.t)(lang, "btn_skip_all"), callback_data: `skip_suggestions:${projectId}`, icon_custom_emoji_id: emoji_1.EMOJI.indicator_error },
    ]);
    return { inline_keyboard: rows };
}
function versionsKeyboard(projectId, commits, releaseCommit, lang = "en") {
    const rows = commits.slice(0, 10).map(c => {
        const num = parseInt(c.version, 10);
        const isReleased = releaseCommit !== null && num === releaseCommit;
        const label = `${isReleased ? "✅ " : ""}#${c.version} — ${(c.changelog || "").substring(0, 30)}`;
        return [{ text: label, callback_data: `rv:${projectId}:${c.version}` }];
    });
    rows.push([{ text: (0, i18n_1.t)(lang, "btn_back"), callback_data: `project:${projectId}` }]);
    return { inline_keyboard: rows };
}
function revertConfirmKeyboard(projectId, commitNum, lang = "en") {
    return {
        inline_keyboard: [
            [{ text: (0, i18n_1.t)(lang, "btn_yes_revert"), callback_data: `rvc:${projectId}:${commitNum}`, icon_custom_emoji_id: emoji_1.EMOJI.indicator_warning }],
            [{ text: (0, i18n_1.t)(lang, "btn_cancel"), callback_data: `versions:${projectId}` }],
        ],
    };
}
function helpKeyboard(lang = "en") {
    return {
        inline_keyboard: [
            [
                { text: (0, i18n_1.t)(lang, "btn_guide"), url: "https://cooperative-postbox-f64.notion.site/Apps-Father-User-Guide-33bb63eb0f25800688fde83c353b5891?source=copy_link" },
                { text: (0, i18n_1.t)(lang, "btn_promo"), url: "https://cooperative-postbox-f64.notion.site/Apps-Father-Promo-33bb63eb0f258090bff4e63cffd8e1ae?source=copy_link" },
            ],
            [
                { text: (0, i18n_1.t)(lang, "btn_channel"), url: "https://t.me/apps_father" },
                { text: (0, i18n_1.t)(lang, "btn_community"), url: "https://t.me/+of-sS1zbZHBmMDJi" },
            ],
            [{ text: (0, i18n_1.t)(lang, "btn_back"), callback_data: "nav_welcome" }],
        ],
    };
}
function backToProjectKeyboard(projectId, lang = "en") {
    return {
        inline_keyboard: [
            [{ text: (0, i18n_1.t)(lang, "btn_back"), callback_data: `project:${projectId}` }],
        ],
    };
}
function statusEmojiId(status) {
    switch (status) {
        case "deployed":
        case "released":
            return emoji_1.EMOJI.indicator_success;
        case "building":
        case "planning":
            return emoji_1.EMOJI.indicator_warning;
        case "error":
            return emoji_1.EMOJI.indicator_error;
        default:
            return emoji_1.EMOJI.indicator_none;
    }
}
//# sourceMappingURL=keyboards.js.map