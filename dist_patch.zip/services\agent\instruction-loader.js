"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildTemplateVars = buildTemplateVars;
exports.renderTemplate = renderTemplate;
exports.buildSystemPrompt = buildSystemPrompt;
exports.loadSkill = loadSkill;
exports.getAvailableSkills = getAvailableSkills;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const config_1 = require("../../config");
const agent_lessons_service_1 = require("../agent-lessons.service");
const paths_1 = require("./paths");
// What the agent knows depends on the build mode. Most instruction files are
// loaded for every run; only workflow-* files are mode-specific. Order matters.
const INSTRUCTION_MANIFEST = [
    { file: "identity.md" },
    { file: "architecture.md" },
    { file: "frontend-rules.md" },
    { file: "backend-rules.md" },
    { file: "database-design.md" },
    { file: "routes-hot-reload.md" },
    { file: "bot-webhook.md" },
    { file: "technology-choice.md" },
    { file: "best-practices.md" },
    { file: "efficiency.md" },
    { file: "workflow-new.md", modes: ["new"] },
    { file: "workflow-update.md", modes: ["update"] },
    { file: "finish-tool.md" },
    { file: "telegram-api.md" },
    { file: "bot-side-updates.md" },
    { file: "after-writing.md" },
    { file: "ask-user.md" },
    { file: "skills-index.md" },
    { file: "frontend-design.md" },
    { file: "server-tools.md" },
];
const instructionCache = new Map();
const TEMPLATE_KEYS = ["domain", "baseUrl", "wsBaseUrl", "wsScheme"];
const TEMPLATE_KEY_RE = new RegExp(`\\{(${TEMPLATE_KEYS.join("|")})\\}`, "g");
function buildTemplateVars() {
    const baseUrl = config_1.config.baseUrl;
    const wsScheme = baseUrl.startsWith("https://") ? "wss" : "ws";
    const wsBaseUrl = baseUrl.replace(/^https?:\/\//, `${wsScheme}://`);
    return {
        domain: config_1.config.domain,
        baseUrl,
        wsBaseUrl,
        wsScheme,
    };
}
function renderTemplate(text, vars) {
    if (!text)
        return text;
    return text.replace(TEMPLATE_KEY_RE, (_, k) => vars[k] ?? `{${k}}`);
}
function loadInstruction(file) {
    if (instructionCache.has(file))
        return instructionCache.get(file);
    try {
        const filePath = path_1.default.join(paths_1.INSTRUCTIONS_DIR, file);
        if (!filePath.startsWith(paths_1.INSTRUCTIONS_DIR))
            return "";
        const content = fs_1.default.readFileSync(filePath, "utf-8").trim();
        instructionCache.set(file, content);
        return content;
    }
    catch (err) {
        console.warn(`[Agent] missing instruction file: ${file} — ${err.message}`);
        instructionCache.set(file, "");
        return "";
    }
}
async function buildSystemPrompt(mode) {
    const parts = [];
    const missing = [];
    const vars = buildTemplateVars();
    for (const entry of INSTRUCTION_MANIFEST) {
        if (entry.modes && !entry.modes.includes(mode))
            continue;
        const content = loadInstruction(entry.file);
        if (content)
            parts.push(renderTemplate(content, vars));
        else
            missing.push(entry.file);
    }
    try {
        const lessonsBlock = await (0, agent_lessons_service_1.getEnabledLessonsBlock)();
        if (lessonsBlock)
            parts.push(lessonsBlock);
    }
    catch (err) {
        console.warn(`[Agent] failed to load learned lessons: ${err?.message || err}`);
    }
    const prompt = parts.join("\n----------------------\n");
    if (!prompt.trim()) {
        throw new Error(`[Agent] system prompt is empty — agent_knowledge/instructions/ missing or unreadable at ${paths_1.INSTRUCTIONS_DIR}. ` +
            `Missing files: ${missing.join(", ")}. ` +
            `Run deploy-full.ps1 (or copy agent_knowledge/ to the server) and restart the process.`);
    }
    if (missing.length > 0) {
        console.warn(`[Agent] buildSystemPrompt(${mode}): ${missing.length} instruction file(s) missing: ${missing.join(", ")}`);
    }
    return prompt;
}
function loadSkill(name) {
    try {
        const filePath = path_1.default.join(paths_1.SKILLS_DIR, name.endsWith(".md") ? name : name + ".md");
        if (!filePath.startsWith(paths_1.SKILLS_DIR))
            return "";
        const raw = fs_1.default.readFileSync(filePath, "utf-8");
        return renderTemplate(raw, buildTemplateVars());
    }
    catch {
        return "";
    }
}
function getAvailableSkills() {
    try {
        return fs_1.default.readdirSync(paths_1.SKILLS_DIR).filter(f => f.endsWith(".md")).map(f => f.replace(".md", ""));
    }
    catch {
        return [];
    }
}
//# sourceMappingURL=instruction-loader.js.map