export interface ChatMessage {
    id: string;
    role: "user" | "assistant" | "system";
    type: "text" | "update_request" | "devtools_request" | "question" | "answer" | "result" | "progress" | "error" | "plan" | "balance_error";
    content: string;
    attachments?: {
        name: string;
        path: string;
        type: string;
    }[];
    checklist?: {
        id: number;
        text: string;
        done: boolean;
    }[];
    percent?: number;
    costUsd?: number;
    balance?: number;
    /** Credits actually deducted for this run (mirrors UsageLog.creditsCharged).
     *  Used by the mini app to render the "Get cashback & rate agent" button on
     *  result bubbles, including after page reload. */
    creditsCharged?: number;
    /** Commit number produced by this run, for linking the cashback feedback
     *  back to the agent log on disk (commits/{commitNum}/agent.log). */
    commitNum?: number;
    /** Whether the cashback/rating button should be shown for this result.
     *  Absent (or false) = never show the button even if cashbackEnabled later. */
    cashbackAvailable?: boolean;
    /** Set to true (and the button replaced with a "Rated ✓" pill) once the
     *  user has submitted a rating for this run. Persisted so reload is correct. */
    cashbackClaimed?: boolean;
    timestamp: number;
    /** ISO 8601 UTC string (e.g. "2026-04-14T09:33:00.123Z"). Used by the
     *  frontend to drive the dynamic progress curve y = 1 - e^(-Δsec/100). */
    createdAtUtc?: string;
    metadata?: Record<string, any>;
}
export declare const chatService: {
    getHistory(projectId: string, before?: number, limit?: number): ChatMessage[];
    addMessage(projectId: string, msg: Omit<ChatMessage, "id" | "timestamp">): ChatMessage;
    updateMessage(projectId: string, msgId: string, partial: Partial<ChatMessage>): ChatMessage | null;
    removeMessage(projectId: string, msgId: string): boolean;
    removeMessages(projectId: string, msgIds: string[]): number;
    clearHistory(projectId: string): void;
    /**
     * Recover dangling in-flight messages after a crash/restart.
     *
     * Heals EVERY `progress` (percent < 100) or `question` message anywhere in
     * the history — not just the last one. After a restart no agent can be
     * running, so any open progress/question is by definition orphaned. The old
     * "last message only" rule missed cases where the agent had appended a
     * follow-up question/answer/auto-fix progress on top of an in-flight build,
     * leaving the UI permanently showing "Working…".
     *
     * Returns the project IDs that had at least one message healed.
     */
    recoverDanglingProgress(reason: string): string[];
    /**
     * Convert every dangling `progress` (percent < 100) or `question` message in
     * the given project to an `error`. Returns the number of messages healed.
     * Safe to call at any time; returns 0 if nothing needed healing.
     */
    healProject(projectId: string, reason: string): number;
};
//# sourceMappingURL=chat.service.d.ts.map