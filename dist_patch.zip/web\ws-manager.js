"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.forceReloadProjectWs = forceReloadProjectWs;
exports.setupWebSocket = setupWebSocket;
const ws_1 = require("ws");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const dotenv_1 = __importDefault(require("dotenv"));
const better_sqlite3_1 = __importDefault(require("better-sqlite3"));
const project_service_1 = require("../services/project.service");
const crypto_service_1 = require("../services/crypto.service");
const console_tagger_service_1 = require("../services/console-tagger.service");
const PROJECTS_DIR = path_1.default.join(process.cwd(), "projects");
const projectStates = new Map();
const projectInitPromises = new Map();
function createProjectDb(projectDir, botToken, botUsername, projectId) {
    const dataDir = path_1.default.join(projectDir, "data");
    fs_1.default.mkdirSync(dataDir, { recursive: true });
    const sqlite = new better_sqlite3_1.default(path_1.default.join(dataDir, "app.db"));
    sqlite.pragma("journal_mode = WAL");
    sqlite.exec("CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT)");
    let closed = false;
    return {
        get open() { return !closed; },
        get(key) {
            if (closed)
                return null;
            const row = sqlite.prepare("SELECT value FROM kv WHERE key = ?").get(key);
            return row ? JSON.parse(row.value) : null;
        },
        set(key, value) {
            if (closed)
                return;
            sqlite.prepare("INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)").run(key, JSON.stringify(value));
        },
        getAll() {
            if (closed)
                return {};
            const rows = sqlite.prepare("SELECT key, value FROM kv").all();
            const result = {};
            for (const row of rows)
                result[row.key] = JSON.parse(row.value);
            return result;
        },
        delete(key) {
            if (closed)
                return;
            sqlite.prepare("DELETE FROM kv WHERE key = ?").run(key);
        },
        keys() {
            if (closed)
                return [];
            return sqlite.prepare("SELECT key FROM kv").all().map((r) => r.key);
        },
        close() {
            if (closed)
                return;
            closed = true;
            sqlite.close();
        },
        botToken,
        botUsername,
        projectId,
    };
}
async function initProjectWs(projectId, isDev) {
    const projectDir = path_1.default.join(PROJECTS_DIR, projectId);
    const releaseBackend = path_1.default.join(projectDir, "release", "backend", "routes.js");
    const devBackend = path_1.default.join(projectDir, "development", "backend", "routes.js");
    const routesFile = isDev ? devBackend : releaseBackend;
    if (!fs_1.default.existsSync(routesFile))
        return null;
    try {
        delete require.cache[require.resolve(routesFile)];
    }
    catch { }
    const routeModule = require(routesFile);
    if (typeof routeModule.ws !== "function")
        return null;
    const project = await project_service_1.projectService.getProject(projectId);
    let botToken = "";
    let botUsername = "";
    if (project?.botTokenEncrypted) {
        botToken = (0, crypto_service_1.decryptToken)(project.botTokenEncrypted);
    }
    if (project?.botUsername) {
        botUsername = project.botUsername;
    }
    const envDir = isDev ? path_1.default.join(projectDir, "development") : path_1.default.join(projectDir, "release");
    const db = createProjectDb(envDir, botToken, botUsername, projectId);
    const backendDir = isDev
        ? path_1.default.join(projectDir, "development", "backend")
        : path_1.default.join(projectDir, "release", "backend");
    const envFilePath = path_1.default.join(backendDir, ".env");
    const envVars = fs_1.default.existsSync(envFilePath)
        ? dotenv_1.default.parse(fs_1.default.readFileSync(envFilePath))
        : {};
    const state = {
        clients: new Set(),
        connectionHandler: null,
        db,
        timers: new Set(),
    };
    const wss = {
        clients: state.clients,
        broadcast(data) {
            const msg = typeof data === "string" ? data : JSON.stringify(data);
            for (const client of state.clients) {
                if (client.readyState === ws_1.WebSocket.OPEN) {
                    client.send(msg);
                }
            }
        },
        broadcastExcept(sender, data) {
            const msg = typeof data === "string" ? data : JSON.stringify(data);
            for (const client of state.clients) {
                if (client !== sender && client.readyState === ws_1.WebSocket.OPEN) {
                    client.send(msg);
                }
            }
        },
        onConnection(handler) {
            state.connectionHandler = handler;
        },
    };
    const origSetInterval = global.setInterval;
    const origSetTimeout = global.setTimeout;
    const trackedTimers = state.timers;
    global.setInterval = function (...args) {
        const id = origSetInterval.apply(global, args);
        trackedTimers.add(id);
        return id;
    };
    global.setTimeout = function (...args) {
        const id = origSetTimeout.apply(global, args);
        trackedTimers.add(id);
        return id;
    };
    try {
        // Run inside the project's tagging context so any timers/listeners
        // registered by routeModule.ws() inherit the AsyncLocalStorage and their
        // console output is tagged automatically.
        (0, console_tagger_service_1.runWithProject)(projectId, () => {
            routeModule.ws(wss, db, projectId, envVars);
        });
    }
    finally {
        global.setInterval = origSetInterval;
        global.setTimeout = origSetTimeout;
    }
    console.log(`[WS] Project ${projectId.substring(0, 8)} ws() initialized, tracking ${trackedTimers.size} timer(s)`);
    return state;
}
function cleanupProject(stateKey) {
    const state = projectStates.get(stateKey);
    if (!state)
        return;
    for (const timer of state.timers) {
        clearInterval(timer);
        clearTimeout(timer);
    }
    if (state.timers.size > 0) {
        console.log(`[WS] Cleared ${state.timers.size} timer(s) for ${stateKey.substring(0, 12)}`);
    }
    state.timers.clear();
    if (state.db) {
        try {
            state.db.close();
        }
        catch { }
        state.db = null;
    }
    state.connectionHandler = null;
    projectStates.delete(stateKey);
    projectInitPromises.delete(stateKey);
}
/**
 * Force-reload a project's WebSocket handler.
 * Closes all connected clients (they will auto-reconnect), clears timers,
 * closes the DB, and removes the cached state so the next connection
 * re-initializes from the latest routes.js on disk.
 */
function forceReloadProjectWs(projectId, isDev) {
    const stateKey = (isDev ? "dev:" : "rel:") + projectId;
    const state = projectStates.get(stateKey);
    if (!state)
        return; // nothing running — no-op
    const clientCount = state.clients.size;
    // Tell clients to reconnect (graceful close with code 1012 = Service Restart)
    for (const client of state.clients) {
        try {
            client.close(1012, "Server reload");
        }
        catch { }
    }
    state.clients.clear();
    cleanupProject(stateKey);
    console.log(`[WS] Force-reloaded ${isDev ? "dev" : "release"} WS for project ${projectId.substring(0, 8)} (${clientCount} client(s) disconnected)`);
}
function setupWebSocket(server, miniAppWss) {
    const wss = new ws_1.WebSocketServer({ noServer: true });
    server.on("upgrade", async (request, socket, head) => {
        const url = request.url || "";
        if (url.startsWith("/telegram-mini-app/ws") && miniAppWss) {
            miniAppWss.handleUpgrade(request, socket, head, (ws) => {
                miniAppWss.emit("connection", ws, request);
            });
            return;
        }
        const devMatch = url.match(/^\/devws\/([a-f0-9-]+)/);
        const releaseMatch = url.match(/^\/ws\/([a-f0-9-]+)/);
        const match = devMatch || releaseMatch;
        const isDev = !!devMatch;
        if (!match) {
            socket.destroy();
            return;
        }
        const projectId = match[1];
        const stateKey = (isDev ? "dev:" : "rel:") + projectId;
        try {
            let state = projectStates.get(stateKey);
            if (!state) {
                // Deduplicate concurrent init calls — only one initProjectWs per stateKey at a time
                let initPromise = projectInitPromises.get(stateKey);
                if (!initPromise) {
                    initPromise = initProjectWs(projectId, isDev).finally(() => {
                        projectInitPromises.delete(stateKey);
                    });
                    projectInitPromises.set(stateKey, initPromise);
                }
                const newState = await initPromise;
                if (!newState) {
                    console.error(`[WS] No ws handler in routes.js for project ${projectId.substring(0, 8)}`);
                    socket.destroy();
                    return;
                }
                // Another concurrent connection may have already stored the state
                state = projectStates.get(stateKey) || newState;
                if (!projectStates.has(stateKey)) {
                    projectStates.set(stateKey, state);
                    console.log(`[WS] Initialized ${isDev ? "dev" : "release"} WS for project ${projectId.substring(0, 8)}`);
                }
            }
            const finalState = state;
            wss.handleUpgrade(request, socket, head, (ws) => {
                finalState.clients.add(ws);
                ws.on("close", () => {
                    finalState.clients.delete(ws);
                    if (finalState.clients.size === 0) {
                        console.log(`[WS] All clients disconnected from ${stateKey.substring(0, 12)}, cleaning up`);
                        cleanupProject(stateKey);
                    }
                });
                if (finalState.connectionHandler) {
                    try {
                        // Run the user's onConnection callback inside the project's tagging
                        // context so any ws.on(...) listeners it registers inherit the
                        // AsyncLocalStorage and emit logs tagged with [app:<projectId>].
                        (0, console_tagger_service_1.runWithProject)(projectId, () => {
                            finalState.connectionHandler(ws, request);
                        });
                    }
                    catch (err) {
                        console.error(`[WS] onConnection error for ${projectId.substring(0, 8)}:`, err);
                    }
                }
            });
        }
        catch (err) {
            console.error(`[WS] Upgrade error for ${projectId.substring(0, 8)}:`, err);
            socket.destroy();
        }
    });
    console.log("[WS] WebSocket manager ready (paths: /ws/{projectId}, /devws/{projectId})");
    return wss;
}
//# sourceMappingURL=ws-manager.js.map