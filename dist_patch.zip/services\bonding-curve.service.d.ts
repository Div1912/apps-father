/**
 * Custodial bonding-curve service.
 *
 * Pump.fun-style virtual constant-product market maker. Reserves and supply
 * live in our DB; trades are settled by our backend (TonConnect TON in/out
 * + jetton mint/burn from the platform hot wallet).
 *
 * Curve formula:  x * y = k  with virtual reserves
 *   x = virtualTonReserve + realTonReserve  (TON, in nanoTON)
 *   y = virtualTokenReserve - soldSupply     (tokens, in atomic units)
 *   k = virtualTonReserve₀ * virtualTokenReserve₀  (constant from launch)
 *
 * Buy `Δx` TON in (after fee subtracted):
 *   Δy = y - k / (x + Δx)         ← tokens minted
 *
 * Sell `Δy` tokens in:
 *   Δx_gross = x - k / (y + Δy)   ← TON the curve gives back
 *   user receives Δx_gross × (1 - fee%)
 *   fee is taken from the gross amount, NOT added on top of reserves.
 *
 * All math here is BigInt (nanoTON / atomic token units). Public quote APIs
 * also expose floating numbers for the UI but the source of truth is BigInt.
 */
export declare const NANO = 1000000000n;
export declare const TOKEN_DECIMALS = 9;
export declare function tonToNano(ton: number | string): bigint;
export declare function nanoToTon(nano: bigint): number;
export declare function tokensToAtomic(tokens: number | string): bigint;
export declare function atomicToTokens(atomic: bigint): number;
export interface CurveState {
    virtualTonReserve: bigint;
    virtualTokenReserve: bigint;
    realTonReserve: bigint;
    soldSupply: bigint;
    curveSupplyCap: bigint;
}
/**
 * Quote a buy: how many tokens does the user get for `tonIn` (gross,
 * including fee)? Returns { tokensOut, feeNano, netTonNano }.
 */
export declare function quoteBuy(state: CurveState, tonInNano: bigint, feePercent: number): {
    tokensOut: bigint;
    feeNano: bigint;
    netTonNano: bigint;
};
/**
 * Quote a sell: how much TON does the user get for `tokensIn`?
 * Returns { tonOutNet, tonOutGross, feeNano }.
 */
export declare function quoteSell(state: CurveState, tokensIn: bigint, feePercent: number): {
    tonOutNet: bigint;
    tonOutGross: bigint;
    feeNano: bigint;
};
/** Current spot price of one whole token in nanoTON. */
export declare function spotPriceNano(state: CurveState): bigint;
/** Total fully-diluted market cap in nanoTON. */
export declare function marketCapNano(state: CurveState, totalSupply: bigint): bigint;
/**
 * Build the initial reserves for a brand-new token. `totalSupply` and
 * `curveSupplyCap` are in whole tokens (will be scaled to atomic units).
 */
export declare function makeInitialReserves(opts?: {
    initialVirtualTon?: number;
    totalSupply?: number;
    curveSupplyShare?: number;
}): {
    virtualTonReserve: bigint;
    virtualTokenReserve: bigint;
    totalSupply: bigint;
    curveSupplyCap: bigint;
};
export interface ExecuteBuyResult {
    tokenId: string;
    userId: number;
    tokensOut: bigint;
    feeNano: bigint;
    priceNano: bigint;
    newSoldSupply: bigint;
    newRealTonReserve: bigint;
}
/**
 * Apply a confirmed buy to the DB inside a transaction:
 *   - re-quote with the latest reserves (snapshot from this tx)
 *   - update reserves + soldSupply on the token row
 *   - upsert the user's holding (balance + new avg buy price)
 *   - update fee balances
 *
 * NB: The trade row itself is created by the routes layer (status flips
 * pending_payment → received) and passed in for status updates.
 */
export declare function executeBuy(opts: {
    tokenId: string;
    userId: number;
    tonInNano: bigint;
    tradeId: string;
    txHashIn?: string;
}): Promise<ExecuteBuyResult>;
export interface ExecuteSellResult {
    tokenId: string;
    userId: number;
    tonOutNet: bigint;
    feeNano: bigint;
    priceNano: bigint;
    newSoldSupply: bigint;
    newRealTonReserve: bigint;
}
/**
 * Apply a confirmed sell to the DB. The user has already sent jettons to
 * the platform wallet; the backend will then send TON back.
 */
export declare function executeSell(opts: {
    tokenId: string;
    userId: number;
    tokensIn: bigint;
    tradeId: string;
    txHashIn?: string;
}): Promise<ExecuteSellResult>;
/** Mark a trade as `settled` (outgoing tx hash is known). */
export declare function markTradeSettled(tradeId: string, txHashOut?: string): Promise<void>;
//# sourceMappingURL=bonding-curve.service.d.ts.map