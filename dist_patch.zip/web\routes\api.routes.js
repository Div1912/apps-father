"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.invalidateProjectDbCache = invalidateProjectDbCache;
const express_1 = require("express");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const dotenv_1 = __importDefault(require("dotenv"));
const better_sqlite3_1 = __importDefault(require("better-sqlite3"));
const initdata_1 = require("../middleware/initdata");
const project_service_1 = require("../../services/project.service");
const crypto_service_1 = require("../../services/crypto.service");
const console_tagger_service_1 = require("../../services/console-tagger.service");
const config_1 = require("../../config");
const router = (0, express_1.Router)();
const PROJECTS_DIR = path_1.default.join(process.cwd(), "projects");
const projectCache = new Map();
function createProjectDb(projectDir, botToken, botUsername, projectId) {
    const dataDir = path_1.default.join(projectDir, "data");
    fs_1.default.mkdirSync(dataDir, { recursive: true });
    const sqlite = new better_sqlite3_1.default(path_1.default.join(dataDir, "app.db"));
    sqlite.pragma("journal_mode = WAL");
    sqlite.exec("CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT)");
    return {
        get(key) {
            const row = sqlite.prepare("SELECT value FROM kv WHERE key = ?").get(key);
            return row ? JSON.parse(row.value) : null;
        },
        set(key, value) {
            sqlite.prepare("INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)").run(key, JSON.stringify(value));
        },
        getAll() {
            const rows = sqlite.prepare("SELECT key, value FROM kv").all();
            const result = {};
            for (const row of rows)
                result[row.key] = JSON.parse(row.value);
            return result;
        },
        delete(key) {
            sqlite.prepare("DELETE FROM kv WHERE key = ?").run(key);
        },
        keys() {
            return sqlite.prepare("SELECT key FROM kv").all().map(r => r.key);
        },
        close() {
            sqlite.close();
        },
        botToken,
        botUsername,
        projectId,
    };
}
function evictProject(projectId) {
    const entry = projectCache.get(projectId);
    if (entry) {
        try {
            entry.db.close();
        }
        catch { }
        projectCache.delete(projectId);
    }
    // Always purge require.cache so the next require() reads the new file from
    // disk — must run even when projectCache had no entry (e.g. invalidateProjectDbCache
    // was called before any request ever hit this project).
    const backendDir = path_1.default.join(PROJECTS_DIR, projectId, "release", "backend");
    for (const key of Object.keys(require.cache)) {
        if (key.startsWith(backendDir) && !key.includes("node_modules")) {
            delete require.cache[key];
        }
    }
}
async function loadProjectEntry(projectId, projectDir, backendDir, routesFile) {
    const mtime = fs_1.default.statSync(routesFile).mtimeMs;
    const existing = projectCache.get(projectId);
    // Return cached entry if the file hasn't changed.
    if (existing && existing.mtime === mtime) {
        return existing;
    }
    // File changed (new release deployed) or first load — evict stale entry.
    // evictProject also purges require.cache for this project's backendDir.
    if (existing) {
        evictProject(projectId);
    }
    const routeFactory = require(routesFile);
    const project = await project_service_1.projectService.getProject(projectId);
    let botToken = "";
    let botUsername = "";
    if (project?.botTokenEncrypted)
        botToken = (0, crypto_service_1.decryptToken)(project.botTokenEncrypted);
    if (project?.botUsername)
        botUsername = project.botUsername;
    const releaseDir = path_1.default.join(projectDir, "release");
    const db = createProjectDb(releaseDir, botToken, botUsername, projectId);
    const envPath = path_1.default.join(backendDir, ".env");
    const envVars = fs_1.default.existsSync(envPath) ? dotenv_1.default.parse(fs_1.default.readFileSync(envPath)) : {};
    // Inject platform vars so routes.js can use the AF Bucket API
    envVars.AF_INTERNAL_SECRET = process.env.AF_INTERNAL_SECRET || "";
    envVars.BASE_URL = config_1.config.baseUrl;
    envVars.PROJECT_ID = projectId;
    // INTERNAL_BASE_URL bypasses nginx/Cloudflare — use this for server-side bucket calls
    envVars.INTERNAL_BASE_URL = `http://localhost:${config_1.config.port}`;
    const entry = { mtime, routeFactory, db, envVars };
    projectCache.set(projectId, entry);
    console.log(`[API] Loaded routes.js for project ${projectId.substring(0, 8)} (mtime=${mtime})`);
    return entry;
}
// ── Request handler ───────────────────────────────────────────────────────────
router.use("/:projectId/{*routePath}", initdata_1.verifyInitData);
router.all("/:projectId/{*routePath}", async (req, res) => {
    const projectId = String(req.params.projectId);
    const rawRoute = req.params.routePath;
    const routePath = Array.isArray(rawRoute) ? rawRoute.join("/") : String(rawRoute || "");
    const projectDir = path_1.default.join(PROJECTS_DIR, projectId);
    const backendDir = path_1.default.join(projectDir, "release", "backend");
    const routesFile = path_1.default.join(backendDir, "routes.js");
    if (!fs_1.default.existsSync(routesFile)) {
        res.status(404).json({ error: "No backend routes configured for this project" });
        return;
    }
    await (0, console_tagger_service_1.runWithProject)(projectId, async () => {
        try {
            const entry = await loadProjectEntry(projectId, projectDir, backendDir, routesFile);
            const { routeFactory, db, envVars } = entry;
            const projectRouter = (0, express_1.Router)();
            if (typeof routeFactory === "function") {
                try {
                    routeFactory(projectRouter, db, projectId, envVars);
                }
                catch (regErr) {
                    console.error(`[API] Route registration error for ${projectId}:`, regErr);
                }
            }
            const registeredRoutes = [];
            if (projectRouter.stack) {
                for (const layer of projectRouter.stack) {
                    if (layer.route) {
                        const methods = Object.keys(layer.route.methods).join(",").toUpperCase();
                        registeredRoutes.push(`${methods} ${layer.route.path}`);
                    }
                }
            }
            // Preserve the original query string when rewriting the URL
            const qs = req.originalUrl.includes("?") ? req.originalUrl.slice(req.originalUrl.indexOf("?")) : "";
            req.url = "/" + routePath + qs;
            projectRouter(req, res, () => {
                console.error(`[API] 404 for /${routePath} in project ${projectId.substring(0, 8)} | Registered: [${registeredRoutes.join(", ")}]`);
                res.status(404).json({ error: "Endpoint not found" });
            });
        }
        catch (err) {
            console.error(`[API] Error loading routes for ${projectId}:`, err);
            res.status(500).json({ error: "Internal server error" });
        }
    });
});
/** Evict a project's cached module+DB so the next request picks up the new routes.js. */
function invalidateProjectDbCache(projectId) {
    evictProject(projectId);
    console.log(`[API] Evicted cache for project ${projectId.substring(0, 8)}`);
}
exports.default = router;
//# sourceMappingURL=api.routes.js.map