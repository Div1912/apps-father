export type UserFilter = "all" | "paying" | "free" | "partner" | "has_apps" | "no_apps" | "inactive_30d";
export type UserSort = "newest" | "balance_desc" | "apps_desc" | "spent_desc" | "oldest";
export interface UsersListParams {
    q?: string;
    filter?: UserFilter;
    sort?: UserSort;
    page?: number;
    pageSize?: number;
}
export declare function listUsers(params?: UsersListParams): Promise<{
    users: {
        id: number;
        telegramId: string;
        username: string | null;
        firstName: string | null;
        balance: number;
        credits: any;
        appSlots: number;
        isPartner: boolean;
        projectCount: number;
        totalSpent: number;
        adminTags: string[];
        createdAt: Date;
    }[];
    page: number;
    pageSize: number;
    total: number;
    pageCount: number;
}>;
export declare function getUserDetail(userId: number): Promise<{
    id: number;
    telegramId: string;
    username: string | null;
    firstName: string | null;
    language: string;
    balance: number;
    credits: any;
    appSlots: number;
    referredBy: string | null;
    utmSource: string | null;
    totalSpent: number;
    totalCreditsSpent: number;
    createdAt: Date;
    isPartner: boolean;
    partnerPercent: number | null;
    partnerTag: string | null;
    partnerReferralBonus: number | null;
    partnerBalance: number;
    adminTags: string[];
    projects: {
        id: string;
        name: string;
        status: string;
        botUsername: string | null;
        totalCost: number;
        createdAt: Date;
        updatedAt: Date;
    }[];
    payments: {
        id: number;
        amount: number;
        status: string;
        createdAt: Date;
        confirmedAt: Date | null;
    }[];
    usageLogs: {
        id: number;
        project: string;
        operation: string;
        inputTokens: number;
        outputTokens: number;
        cost: number;
        creditsCharged: any;
        createdAt: Date;
    }[];
} | null>;
export declare function setUserBalance(userId: number, action: "set" | "add", amount: number): Promise<{
    balance: number;
}>;
/** Set or add credits directly (admin action). Credits are integers. */
export declare function setUserCredits(userId: number, action: "set" | "add", credits: number): Promise<{
    credits: any;
}>;
export declare function updateUserPartner(userId: number, body: {
    isPartner?: boolean;
    partnerPercent?: number | null;
    partnerTag?: string | null;
    partnerReferralBonus?: number | null;
}): Promise<{
    isPartner: boolean;
    partnerPercent: number | null;
    partnerTag: string | null;
    partnerReferralBonus: number | null;
    partnerBalance: number;
}>;
/**
 * Patch arbitrary editable user fields. Only whitelisted keys are accepted
 * to avoid accidentally letting an admin set telegramId etc. from the UI.
 */
export declare function patchUser(userId: number, body: {
    firstName?: string | null;
    username?: string | null;
    language?: string;
    appSlots?: number;
    referredBy?: string | null;
}): Promise<{
    id: number;
    firstName: string | null;
    username: string | null;
    language: string;
    appSlots: number;
    referredBy: string | null;
}>;
export declare function setUserTags(userId: number, tags: string[]): Promise<{
    adminTags: string[];
}>;
export declare function listUserNotes(userId: number): Promise<any>;
export declare function addUserNote(userId: number, body: string, authorTag?: string): Promise<{
    id: any;
    body: any;
    authorTag: any;
    createdAt: any;
}>;
export declare function deleteUserNote(userId: number, noteId: number): Promise<{
    ok: boolean;
}>;
export type ProjectFilter = "all" | "deployed" | "released" | "building" | "planning" | "created" | "error";
export type ProjectSort = "updated_desc" | "created_desc" | "budget_desc" | "budget_asc" | "name_asc";
export interface ProjectsListParams {
    q?: string;
    filter?: ProjectFilter;
    sort?: ProjectSort;
    page?: number;
    pageSize?: number;
}
export declare function listProjects(params?: ProjectsListParams): Promise<{
    projects: {
        id: string;
        name: string;
        status: string;
        botUsername: string | null;
        totalCost: number;
        description: string | null;
        createdAt: Date;
        updatedAt: Date;
        ownerId: number;
        owner: string;
    }[];
    page: number;
    pageSize: number;
    total: number;
    pageCount: number;
    statusCounts: {
        [k: string]: number;
    };
}>;
export declare function getProjectDetail(projectId: string): Promise<{
    id: string;
    name: string;
    status: string;
    description: string | null;
    plan: string | null;
    projectSummary: string | null;
    botUsername: string | null;
    botUserId: string | null;
    features: string | null;
    totalCost: number;
    createdAt: Date;
    updatedAt: Date;
    releaseCommit: number | null;
    ownerId: number;
    ownerTelegramId: string;
    owner: string;
} | null>;
export declare function patchProject(projectId: string, body: {
    name?: string;
    description?: string | null;
    status?: string;
    features?: string | null;
    totalCost?: number;
}): Promise<{
    id: string;
    name: string;
    status: string;
    description: string | null;
    plan: string | null;
    projectSummary: string | null;
    botUsername: string | null;
    botUserId: string | null;
    features: string | null;
    totalCost: number;
    createdAt: Date;
    updatedAt: Date;
    releaseCommit: number | null;
    ownerId: number;
    ownerTelegramId: string;
    owner: string;
} | null>;
export interface OpBreakdownRow {
    operation: string;
    costUsd: number;
    inputTokens: number;
    outputTokens: number;
    count: number;
}
export declare function getOperationBreakdown(params: {
    from?: Date | null;
    to?: Date | null;
}): Promise<OpBreakdownRow[]>;
export type TimeseriesMetric = "new_users" | "paying_users" | "conversion" | "new_projects" | "revenue" | "service_costs" | "dau";
export type TimeseriesInterval = "hour" | "day" | "week" | "month";
interface TimeseriesParams {
    metric: TimeseriesMetric;
    from?: Date | null;
    to?: Date | null;
    interval?: TimeseriesInterval;
}
export declare function getTimeseries(params: TimeseriesParams): Promise<{
    metric: TimeseriesMetric;
    interval: TimeseriesInterval;
    from: string;
    to: string;
    buckets: {
        ts: string;
        value: number;
    }[];
}>;
interface SourcesParams {
    from?: Date | null;
    to?: Date | null;
    /** Optional async resolver. If provided, called for partner/referrer
     *  telegramIds and the returned URL is attached as `avatarUrl`. */
    resolveAvatar?: (telegramId: string) => Promise<string | null>;
}
export interface SourceMetrics {
    users: number;
    createdApp: number;
    createdPlan: number;
    builtApp: number;
    payingUsers: number;
    revenue: number;
    conversion: number;
    arpu: number;
    arppu: number;
}
export declare function getSourcesStats(params?: SourcesParams): Promise<{
    range: {
        from: string | null;
        to: string | null;
    };
    all: {
        users: number;
        createdApp: number;
        createdPlan: number;
        builtApp: number;
        payingUsers: number;
        revenue: number;
        conversion: number;
        arpu: number;
        arppu: number;
        source: string;
    };
    organic: {
        users: number;
        createdApp: number;
        createdPlan: number;
        builtApp: number;
        payingUsers: number;
        revenue: number;
        conversion: number;
        arpu: number;
        arppu: number;
        source: string;
    };
    sources: {
        users: number;
        createdApp: number;
        createdPlan: number;
        builtApp: number;
        payingUsers: number;
        revenue: number;
        conversion: number;
        arpu: number;
        arppu: number;
        source: string;
    }[];
    partners: any[];
    referrers: any[];
}>;
export type SourceUsersKind = "all" | "organic" | "source" | "partner" | "referrer";
export declare function listSourceUsers(params: {
    from?: Date | null;
    to?: Date | null;
    kind: SourceUsersKind;
    key?: string;
}): Promise<{
    range: {
        from: string | null;
        to: string | null;
    };
    kind: SourceUsersKind;
    key: string;
    count: number;
    users: {
        id: number;
        telegramId: string;
        username: string | null;
        firstName: string | null;
        balance: number;
        projectCount: number;
        createdAt: Date;
        utmSource: string | null;
        referredBy: string | null;
        hasApp: boolean;
        hasPlan: boolean;
        hasBuilt: boolean;
        revenue: number;
    }[];
}>;
export declare function wipeUserData(userId: number): Promise<{
    payments: number;
    conversations: number;
    usageLogs: number;
    withdrawals: number;
    voucherRedemptions: number;
    notes: any;
}>;
export declare function fullResetUser(userId: number): Promise<{
    assets: number;
    versions: number;
    payments: number;
    conversations: number;
    usageLogs: number;
    withdrawals: number;
    voucherRedemptions: number;
    notes: any;
    projects: number;
}>;
export {};
//# sourceMappingURL=admin-queries.service.d.ts.map