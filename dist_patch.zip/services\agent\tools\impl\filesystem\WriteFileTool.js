"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WriteFileTool = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
class WriteFileTool {
    renderDefinition() {
        return {
            type: "function",
            function: {
                name: "write_file",
                description: "Create or overwrite a file with complete content. Use for new files or full rewrites. For small changes, prefer edit_file. WARNING: do NOT use for files longer than ~300 lines — the content will be cut off by max_tokens mid-generation, corrupting the file. For large files use the shell tool with a heredoc, or write a short skeleton and fill sections with edit_file.",
                parameters: {
                    type: "object",
                    properties: {
                        path: { type: "string", description: "File path relative to project root" },
                        content: { type: "string", description: "Complete file content" },
                    },
                    required: ["path", "content"],
                },
            },
        };
    }
    async execute(args, ctx) {
        if (ctx.deployLocked) {
            return "Error: Deploy limit has been reached. Further file edits cannot be deployed or verified in this run. Call finish to produce a blocked build report instead of editing.";
        }
        if (ctx.mode === "new" && !ctx.technicalPlanSubmitted) {
            return "Error: technical_plan must be called before writing code in a new build.";
        }
        // Guard: args may be empty/undefined if the JSON was truncated by max_tokens
        if (!args.path || typeof args.path !== "string") {
            return `Error: write_file args were truncated by max_tokens — 'path' is missing. The file content was too large to fit in one tool call.

DO NOT retry write_file with the full file. Split the work:

OPTION 1 — shell heredoc (best for files >300 lines):
  shell("cat > frontend/yourfile.js << 'EOF'\\n...content in chunks...\\nEOF")

OPTION 2 — skeleton + edit_file:
  write_file(path, "// skeleton with // TODO: sectionA markers")
  edit_file(path, "// TODO: sectionA", "...actual code...")

OPTION 3 — split into multiple smaller files.

Pick one and proceed immediately.`;
        }
        if (this._isProtectedPath(args.path)) {
            return "Error: You can only write to frontend/ and backend/ directories.";
        }
        const filePath = this._safePath(ctx.projectDir, args.path);
        if (!filePath)
            return "Error: Invalid path";
        if (typeof args.content !== "string" || args.content.length === 0) {
            return `Error: write_file received empty content for '${args.path}' — the model hit max_tokens while generating the file body. This will happen again if you retry the same way.

DO NOT retry write_file with the full file. Split the work:

OPTION 1 — shell heredoc (best for files >300 lines):
  shell("cat > ${args.path} << 'HEREDOC_EOF'\\n...content...\\nHEREDOC_EOF")

OPTION 2 — skeleton + edit_file:
  write_file("${args.path}", "// skeleton ~50 lines with // TODO: sectionA markers")
  edit_file("${args.path}", "// TODO: sectionA", "...actual code...")

OPTION 3 — split into multiple smaller files.

Pick one and proceed immediately.`;
        }
        fs_1.default.mkdirSync(path_1.default.dirname(filePath), { recursive: true });
        fs_1.default.writeFileSync(filePath, args.content, "utf-8");
        const lineCount = args.content.split("\n").length;
        // Diagnostic — log every write so we can correlate with validator failures
        const hasOpenWS = /AF\.openWS\s*\(/.test(args.content);
        console.log(`[WriteFileTool] wrote ${args.path} → ${lineCount} lines, ${Buffer.byteLength(args.content, "utf-8")} bytes, contains AF.openWS=${hasOpenWS}, fullPath=${filePath}`);
        ctx.wroteFiles = true;
        await ctx.progress({ action: "✏️ Writing", detail: args.path, percent: ctx.currentPercent });
        // Early-warning: if writing frontend/app.js and the plan has WS but the file lacks AF.openWS
        const normalizedWritePath = args.path.replace(/\\/g, "/").replace(/^\/+/, "");
        const planHasWs = Array.isArray(ctx.technicalPlan?.wsMessages) && ctx.technicalPlan.wsMessages.length > 0;
        if (normalizedWritePath === "frontend/app.js" && planHasWs) {
            const hasWsCall = /AF\.openWS\s*\(|new\s+WebSocket\s*\(/.test(args.content);
            if (!hasWsCall) {
                return `OK: Written ${lineCount} lines to ${args.path}. ` +
                    `WARNING: Your technical plan includes WebSocket messages, but this app.js does not contain AF.openWS(). ` +
                    `deploy_to_dev WILL FAIL with a validator error. ` +
                    `You MUST add WebSocket connection code before deploying. ` +
                    `Add a connectWS() function that calls: ws = AF.openWS({ onOpen: () => { ws.send(JSON.stringify({type:'auth',initData:AF.tg.initData||''})); }, onMessage: (data) => { handleWSMessage(data); }, onClose: () => { setTimeout(connectWS, 3000); } });`;
            }
        }
        return `OK: Written ${lineCount} lines to ${args.path}`;
    }
    getStepMeta(args) {
        const meta = {};
        if (typeof args?.content === "string") {
            meta.lines = args.content.split("\n").length;
            meta.bytes = Buffer.byteLength(args.content, "utf-8");
        }
        return meta;
    }
    _isProtectedPath(relativePath) {
        const normalized = relativePath.replace(/\\/g, "/").replace(/^\/+/, "");
        return !/^(frontend|backend)(\/|$)/i.test(normalized);
    }
    _safePath(projectDir, relativePath) {
        if (!relativePath || relativePath.includes(".."))
            return null;
        const full = path_1.default.join(projectDir, relativePath);
        if (!full.startsWith(projectDir))
            return null;
        return full;
    }
}
exports.WriteFileTool = WriteFileTool;
//# sourceMappingURL=WriteFileTool.js.map