import OpenAI from "openai";
import type { AgentResult } from "../agent.service";
import type { AgentTool } from "./AgentTool";
import { RunContext } from "./RunContext";
export declare class AgentRunner {
    private _ctx;
    private _systemPrompt;
    private _tools;
    private _rawToolDefs;
    private _messages;
    setContext(ctx: RunContext): this;
    setSystemPrompt(p: string): this;
    setTools(tools: AgentTool[]): this;
    setMessages(msgs: OpenAI.Chat.Completions.ChatCompletionMessageParam[]): this;
    /** Extra OpenAI-format tool definitions to append (e.g. SERVER_TOOLS). */
    setRawToolDefs(defs: any[]): this;
    run(): Promise<AgentResult>;
    private _getProviderRouting;
    private _isClaudeModel;
    private _isEmptyResponse;
    private _invalidResponseReason;
    private _callWithRetry;
    private _streamAgentCall;
    private _attachCacheControlToContent;
    private _applyCacheBreakpoint;
    private _defaultStepMeta;
    private _cloneSafe;
}
//# sourceMappingURL=AgentRunner.d.ts.map