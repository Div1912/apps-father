import { OpenPanel } from "@openpanel/sdk";
declare const op: OpenPanel;
/**
 * Reserved start_param values that are used by Apps Father itself for
 * intra-bot navigation (e.g. the user-bot's /start "back to Apps Father"
 * button). They must NEVER be persisted as utm_source / referrer because
 * they don't represent an external acquisition channel — they're internal
 * deep links our own UI emits. Add new sentinels here as we introduce them.
 */
export declare const RESERVED_START_PARAMS: Set<string>;
/**
 * Parses the Telegram start/startapp parameter.
 * Formats supported:
 *   "source|123456789"  → { source: "source", referrerId: "123456789" }
 *   "campaign_name"     → { source: "campaign_name", referrerId: null }
 *   "123456789"         → { source: null, referrerId: "123456789" }
 *
 * Reserved sentinels (see RESERVED_START_PARAMS) always return null/null
 * so they don't pollute attribution.
 */
export declare function parseStartParam(param: string | null | undefined): {
    source: string | null;
    referrerId: string | null;
};
/**
 * Track a server-side event.
 * Note: identify is intentionally NOT done server-side — it runs on the
 * frontend so OpenPanel captures the user's real device, IP and location
 * (server identify would attribute every user to the server's location).
 */
export declare function trackEvent(telegramId: number | string, event: string, properties?: Record<string, any>): Promise<void>;
export { op as openPanel };
//# sourceMappingURL=analytics.service.d.ts.map