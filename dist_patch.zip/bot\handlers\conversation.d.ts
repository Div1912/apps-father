import { Bot } from "grammy";
import { BotContext } from "../../types";
export declare function registerConversationHandlers(_bot: Bot<BotContext>): void;
//# sourceMappingURL=conversation.d.ts.map