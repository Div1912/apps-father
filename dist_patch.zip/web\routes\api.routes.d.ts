declare const router: import("express-serve-static-core").Router;
/** Evict a project's cached module+DB so the next request picks up the new routes.js. */
export declare function invalidateProjectDbCache(projectId: string): void;
export default router;
//# sourceMappingURL=api.routes.d.ts.map