export type Lang = "en" | "ru" | "ua";
export declare function t(lang: Lang, key: string, params?: Record<string, string | number>): string;
export declare const LANG_NAMES: Record<Lang, string>;
export declare function langName(lang: Lang): string;
export declare function translateStatus(lang: Lang, status: string): string;
export declare function translateFeatureLabel(lang: Lang, featureId: string): string | null;
export declare function translateFeatureDesc(lang: Lang, featureId: string): string | null;
//# sourceMappingURL=i18n.d.ts.map