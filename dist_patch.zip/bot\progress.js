"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mdToTgHtml = mdToTgHtml;
exports.processMessage = processMessage;
exports.doneMessage = doneMessage;
exports.errorMessage = errorMessage;
exports.costLine = costLine;
exports.truncSummary = truncSummary;
exports.checklistMessage = checklistMessage;
const emoji_1 = require("./emoji");
const i18n_1 = require("./i18n");
function progressBar(percent) {
    const clamped = Math.max(0, Math.min(100, percent));
    const filled = Math.round(clamped / 10);
    const start = filled >= 1
        ? (0, emoji_1.ce)(emoji_1.EMOJI.progress_start_full)
        : (0, emoji_1.ce)(emoji_1.EMOJI.progress_start_empty);
    let middle = "";
    for (let i = 2; i <= 9; i++) {
        middle += i <= filled
            ? (0, emoji_1.ce)(emoji_1.EMOJI.progress_full)
            : (0, emoji_1.ce)(emoji_1.EMOJI.progress_empty);
    }
    const end = filled >= 10
        ? (0, emoji_1.ce)(emoji_1.EMOJI.progress_end_full)
        : (0, emoji_1.ce)(emoji_1.EMOJI.progress_end_empty);
    return `${start}${middle}${end}`;
}
function mdToTgHtml(md) {
    let s = md.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    const codeBlocks = [];
    s = s.replace(/`([^`]+)`/g, (_m, code) => {
        codeBlocks.push(code);
        return `\x00CB${codeBlocks.length - 1}\x00`;
    });
    s = s.replace(/^### (.+)$/gm, "<b>$1</b>");
    s = s.replace(/^## (.+)$/gm, "<b>$1</b>");
    s = s.replace(/^# (.+)$/gm, "<b>$1</b>");
    s = s.replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");
    s = s.replace(/(?<!\w)__(.+?)__(?!\w)/g, "<b>$1</b>");
    s = s.replace(/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/g, "<i>$1</i>");
    s = s.replace(/(?<!_)_(?!_)(.+?)(?<!_)_(?!_)/g, "<i>$1</i>");
    s = s.replace(/\x00CB(\d+)\x00/g, (_m, idx) => `<code>${codeBlocks[Number(idx)]}</code>`);
    s = s.replace(/^[-*] /gm, "• ");
    s = s.replace(/^\d+\.\s/gm, (m) => m);
    return s;
}
function processMessage(status, percent, lang = "en", costUsd, balance) {
    const bar = typeof percent === "number" ? `\n${(0, i18n_1.t)(lang, "progress_label")} <b>${Math.max(0, Math.min(100, percent))}%</b>\n${progressBar(percent)}` : "";
    const costInfo = typeof costUsd === "number" && costUsd > 0
        ? `\n<blockquote>${(0, emoji_1.ce)(emoji_1.EMOJI.dollar, "💲")} ${(0, i18n_1.t)(lang, "cost_label")} <b>$${costUsd.toFixed(4)}</b>${typeof balance === "number" ? ` | ${(0, i18n_1.t)(lang, "balance_label")} <b>$${balance.toFixed(2)}</b>` : ""}</blockquote>`
        : "";
    return `<b>${(0, emoji_1.ce)(emoji_1.EMOJI.loading, "⏳")} ${(0, i18n_1.t)(lang, "process_going")}</b>${bar}${costInfo}\n<blockquote>${status}</blockquote>`;
}
function doneMessage(title, detail) {
    return `<b>${(0, emoji_1.ce)(emoji_1.EMOJI.indicator_success, "✅")} ${title}</b>\n${detail}`;
}
function errorMessage(detail, lang = "en") {
    return `<b>${(0, emoji_1.ce)(emoji_1.EMOJI.indicator_error, "❌")} ${(0, i18n_1.t)(lang, "something_wrong")}</b>\n${detail}`;
}
function costLine(costUsd, newBalance, lang = "en") {
    return `<blockquote>${(0, emoji_1.ce)(emoji_1.EMOJI.dollar, "💲")} ${(0, i18n_1.t)(lang, "cost_label")} <b>$${costUsd.toFixed(4)}</b> | ${(0, i18n_1.t)(lang, "balance_label")} <b>$${newBalance.toFixed(2)}</b></blockquote>`;
}
function truncSummary(text, maxLen = 2000, lang = "en") {
    if (text.length <= maxLen)
        return text;
    return text.substring(0, maxLen) + `\n…<i>${(0, i18n_1.t)(lang, "truncated")}</i>`;
}
function esc(text) {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function checklistMessage(title, items, status, lang = "en", costUsd, balance, percent) {
    const lines = items.map(item => {
        const emoji = item.done
            ? (0, emoji_1.ce)(emoji_1.EMOJI.mark_done, "✅")
            : (0, emoji_1.ce)(emoji_1.EMOJI.mark_empty, "⬜");
        return `${emoji} ${esc(item.text)}`;
    });
    const pct = typeof percent === "number" ? Math.max(0, Math.min(100, percent)) : 0;
    const bar = `${(0, i18n_1.t)(lang, "progress_label")} <b>${pct}%</b>\n${progressBar(pct)}`;
    const statusLine = status ? `\n<blockquote>${status}</blockquote>` : "";
    const costInfo = typeof costUsd === "number" && costUsd > 0
        ? `\n<blockquote>${(0, emoji_1.ce)(emoji_1.EMOJI.dollar, "💲")} ${(0, i18n_1.t)(lang, "cost_label")} <b>$${costUsd.toFixed(4)}</b>${typeof balance === "number" ? ` | ${(0, i18n_1.t)(lang, "balance_label")} <b>$${balance.toFixed(2)}</b>` : ""}</blockquote>`
        : "";
    return `<b>${(0, emoji_1.ce)(emoji_1.EMOJI.loading, "⏳")} ${title}</b>\n\n${lines.join("\n")}\n\n${bar}${costInfo}${statusLine}`;
}
//# sourceMappingURL=progress.js.map