export declare const PROJECTS_DIR: string;
export declare const KNOWLEDGE_DIR: string;
export declare const INSTRUCTIONS_DIR: string;
export declare const SKILLS_DIR: string;
//# sourceMappingURL=paths.d.ts.map