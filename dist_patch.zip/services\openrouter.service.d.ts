export interface OpenRouterClient {
    chat: {
        completions: {
            create(params: any): Promise<any>;
        };
    };
}
/**
 * Returns a fresh OpenRouter client.
 * The API key is read from runtimeConfig at call time so admin changes
 * take effect immediately without restart.
 */
export declare function getOpenRouterClient(): OpenRouterClient;
/**
 * Thin model-pricing cache so we don't hit the OR catalog on every token
 * calculation. Refreshed lazily at most once per hour.
 */
interface ORModelPricing {
    promptPerToken: number;
    completionPerToken: number;
    cacheReadPerToken: number;
    cacheWritePerToken: number;
}
export declare function fetchOpenRouterPricing(): Promise<Map<string, ORModelPricing>>;
/**
 * Get the USD-per-token pricing for a specific OpenRouter model ID.
 * Falls back to 0 if pricing is unavailable.
 */
export declare function getModelPricing(modelId: string): Promise<ORModelPricing | null>;
/**
 * Convert an Anthropic-style tool definition to the OpenAI function-calling format
 * that OpenRouter expects.
 */
export declare function toOpenAITool(tool: {
    name: string;
    description: string;
    input_schema: Record<string, any>;
}): any;
export {};
//# sourceMappingURL=openrouter.service.d.ts.map