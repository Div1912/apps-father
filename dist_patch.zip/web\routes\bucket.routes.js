"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MIME_TO_EXT = exports.BUCKET_ROOT = void 0;
exports.listProjectFiles = listProjectFiles;
exports.deleteProjectFile = deleteProjectFile;
exports.uploadProjectFile = uploadProjectFile;
exports.uploadProjectFileFromBuffer = uploadProjectFileFromBuffer;
/**
 * Apps Father Bucket — per-project file storage.
 *
 * Upload (project owner via mini-app, OR server-side routes.js):
 *   POST /bucket/:projectId/upload
 *   Body: { data: "data:<mime>;base64,<b64>", name?: string }
 *   Auth: x-telegram-init-data (owner) OR x-af-internal (server-side)
 *   Returns: { file_id, direct_link, filename, size, mime }
 *
 * Serve (public — anyone with the link):
 *   GET /bucket/:projectId/:filename
 *
 * List files (owner only — via mini-app API):
 *   GET /telegram-mini-app/api/bucket/:projectId       (in server.ts)
 *
 * Delete (owner only — via mini-app API):
 *   DELETE /telegram-mini-app/api/bucket/:projectId/:filename  (in server.ts)
 *
 * Files are stored in {cwd}/bucket/{projectId}/ and survive deployments.
 */
const express_1 = __importStar(require("express"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const crypto_1 = __importDefault(require("crypto"));
const router = (0, express_1.Router)();
exports.BUCKET_ROOT = path_1.default.join(process.cwd(), "bucket");
// Ensure root bucket dir exists
if (!fs_1.default.existsSync(exports.BUCKET_ROOT)) {
    fs_1.default.mkdirSync(exports.BUCKET_ROOT, { recursive: true });
}
// ── MIME type → extension map (images, audio, video, docs) ─────────────────
exports.MIME_TO_EXT = {
    // Images
    "image/jpeg": "jpg",
    "image/jpg": "jpg",
    "image/png": "png",
    "image/gif": "gif",
    "image/webp": "webp",
    "image/svg+xml": "svg",
    "image/avif": "avif",
    "image/bmp": "bmp",
    // Audio
    "audio/mpeg": "mp3",
    "audio/mp3": "mp3",
    "audio/ogg": "ogg",
    "audio/wav": "wav",
    "audio/webm": "weba",
    "audio/aac": "aac",
    "audio/flac": "flac",
    "audio/x-m4a": "m4a",
    "audio/mp4": "m4a",
    // Video
    "video/mp4": "mp4",
    "video/webm": "webm",
    "video/ogg": "ogv",
    "video/quicktime": "mov",
    // Docs
    "application/pdf": "pdf",
    "application/json": "json",
    "text/plain": "txt",
    "text/csv": "csv",
};
function getProjectDir(projectId) {
    // sanitise projectId — only allow uuid-safe chars
    const safe = projectId.replace(/[^a-zA-Z0-9_-]/g, "");
    if (!safe || safe !== projectId)
        throw new Error("Invalid projectId");
    return path_1.default.join(exports.BUCKET_ROOT, safe);
}
function ensureProjectDir(projectId) {
    const dir = getProjectDir(projectId);
    if (!fs_1.default.existsSync(dir))
        fs_1.default.mkdirSync(dir, { recursive: true });
    return dir;
}
/** Parse a base64 data URL: data:<mime>;base64,<data> */
function parseDataUrl(data) {
    const m = data.match(/^data:([a-zA-Z0-9\/+.-]+);base64,(.+)$/s);
    if (!m)
        return null;
    return { mime: m[1], buf: Buffer.from(m[2], "base64") };
}
// ── POST /bucket/:projectId/upload ──────────────────────────────────────────
// Two upload modes:
//   1. JSON  — Content-Type: application/json  → { data: "data:<mime>;base64,..." }
//   2. Binary — Content-Type: <mime>           → raw bytes in body (for large files)
// Auth: x-af-internal header (from routes.js server-side code)
//       OR project ownership validated in server.ts before calling this handler.
router.post("/:projectId/upload", express_1.default.raw({ type: (req) => (req.headers["content-type"] || "").split(";")[0].trim() !== "application/json", limit: "500mb" }), (req, res) => {
    try {
        const isInternal = req.headers["x-af-internal"] === process.env.AF_INTERNAL_SECRET;
        if (!isInternal) {
            res.status(403).json({ error: "Use /telegram-mini-app/api/bucket/:projectId/upload for owner uploads" });
            return;
        }
        const projectId = String(req.params.projectId);
        let buf;
        let mime;
        if (Buffer.isBuffer(req.body)) {
            // Binary upload path
            mime = ((req.headers["content-type"] || "application/octet-stream").split(";")[0]).trim();
            buf = req.body;
        }
        else {
            // JSON / base64 path
            const { data } = req.body || {};
            if (!data || typeof data !== "string") {
                res.status(400).json({ error: "Body must be raw binary (Content-Type: <mime>) or JSON { data: 'data:<mime>;base64,...' }" });
                return;
            }
            const parsed = parseDataUrl(data);
            if (!parsed) {
                res.status(400).json({ error: "Invalid data URL — must be data:<mime>;base64,<data>" });
                return;
            }
            buf = parsed.buf;
            mime = parsed.mime;
        }
        const ext = exports.MIME_TO_EXT[mime] || "bin";
        const fileId = crypto_1.default.randomUUID();
        const filename = fileId + "." + ext;
        const dir = ensureProjectDir(projectId);
        fs_1.default.writeFileSync(path_1.default.join(dir, filename), buf);
        const directLink = `/bucket/${projectId}/${filename}`;
        console.log(`[Bucket] Saved ${projectId}/${filename} ${Math.round(buf.length / 1024)}KB`);
        res.json({ file_id: fileId, direct_link: directLink, filename, size: buf.length, mime });
    }
    catch (err) {
        console.error("[Bucket] Upload error:", err);
        res.status(500).json({ error: err.message || "Upload failed" });
    }
});
// ── GET /bucket/:projectId/:filename — public file serving ──────────────────
router.get("/:projectId/:filename", (req, res) => {
    try {
        const rawProject = String(req.params.projectId);
        const rawFilename = String(req.params.filename);
        // Sanitise both segments
        const projectId = rawProject.replace(/[^a-zA-Z0-9_-]/g, "");
        const filename = rawFilename.replace(/[^a-zA-Z0-9._-]/g, "");
        if (!projectId || !filename || projectId !== rawProject || filename !== rawFilename) {
            res.status(400).send("Bad request");
            return;
        }
        const dir = path_1.default.join(exports.BUCKET_ROOT, projectId);
        const filePath = path_1.default.join(dir, filename);
        // Path traversal guard
        if (!filePath.startsWith(dir + path_1.default.sep) || !fs_1.default.existsSync(filePath)) {
            res.status(404).send("Not found");
            return;
        }
        // Determine Content-Type from extension
        const ext = path_1.default.extname(filename).slice(1).toLowerCase();
        const extToMime = {
            jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png",
            gif: "image/gif", webp: "image/webp", svg: "image/svg+xml",
            avif: "image/avif", bmp: "image/bmp",
            mp3: "audio/mpeg", ogg: "audio/ogg", wav: "audio/wav",
            weba: "audio/webm", aac: "audio/aac", flac: "audio/flac", m4a: "audio/mp4",
            mp4: "video/mp4", webm: "video/webm", ogv: "video/ogg", mov: "video/quicktime",
            pdf: "application/pdf", json: "application/json", txt: "text/plain", csv: "text/csv",
        };
        const ct = extToMime[ext] || "application/octet-stream";
        res.setHeader("Content-Type", ct);
        res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
        res.sendFile(filePath);
    }
    catch (err) {
        console.error("[Bucket] Serve error:", err);
        res.status(500).send("Server error");
    }
});
// ── Legacy: GET /bucket/:filename (backward-compat for old flat uploads) ────
router.get("/:filename", (req, res) => {
    const raw = String(req.params.filename);
    const filename = raw.replace(/[^a-zA-Z0-9._-]/g, "");
    if (!filename || filename !== raw) {
        res.status(400).send("Bad filename");
        return;
    }
    const filePath = path_1.default.join(exports.BUCKET_ROOT, filename);
    if (!filePath.startsWith(exports.BUCKET_ROOT + path_1.default.sep) || !fs_1.default.existsSync(filePath)) {
        res.status(404).send("Not found");
        return;
    }
    res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
    res.sendFile(filePath);
});
function listProjectFiles(projectId) {
    let dir;
    try {
        dir = getProjectDir(projectId);
    }
    catch {
        return [];
    }
    if (!fs_1.default.existsSync(dir))
        return [];
    return fs_1.default.readdirSync(dir)
        .filter(f => !f.startsWith("."))
        .filter(f => !fs_1.default.statSync(path_1.default.join(dir, f)).isDirectory())
        .map(filename => {
        const stat = fs_1.default.statSync(path_1.default.join(dir, filename));
        const ext = path_1.default.extname(filename).slice(1);
        const file_id = filename.replace(/\.[^.]+$/, "");
        return {
            filename,
            file_id,
            ext,
            size: stat.size,
            direct_link: `/bucket/${projectId}/${filename}`,
            uploaded_at: stat.mtime.toISOString(),
        };
    })
        .sort((a, b) => b.uploaded_at.localeCompare(a.uploaded_at));
}
function deleteProjectFile(projectId, filename) {
    let dir;
    try {
        dir = getProjectDir(projectId);
    }
    catch {
        return false;
    }
    const safe = filename.replace(/[^a-zA-Z0-9._-]/g, "");
    if (!safe || safe !== filename)
        return false;
    const filePath = path_1.default.join(dir, safe);
    if (!filePath.startsWith(dir + path_1.default.sep) || !fs_1.default.existsSync(filePath))
        return false;
    fs_1.default.unlinkSync(filePath);
    return true;
}
function uploadProjectFile(projectId, data, name) {
    const parsed = parseDataUrl(data);
    if (!parsed)
        throw new Error("Invalid data URL");
    return uploadProjectFileFromBuffer(projectId, parsed.buf, parsed.mime);
}
function uploadProjectFileFromBuffer(projectId, buf, mime) {
    const ext = exports.MIME_TO_EXT[mime] || "bin";
    const fileId = crypto_1.default.randomUUID();
    const filename = fileId + "." + ext;
    const dir = ensureProjectDir(projectId);
    fs_1.default.writeFileSync(path_1.default.join(dir, filename), buf);
    console.log(`[Bucket] Saved ${projectId}/${filename} ${Math.round(buf.length / 1024)}KB`);
    return {
        file_id: fileId,
        direct_link: `/bucket/${projectId}/${filename}`,
        filename,
        size: buf.length,
        mime,
    };
}
exports.default = router;
//# sourceMappingURL=bucket.routes.js.map