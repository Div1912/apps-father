export declare class DatabaseService {
    createProjectSchema(projectId: string, schemaSql: string): Promise<void>;
    private syncColumns;
    executeQuery(projectId: string, query: string, params?: any[]): Promise<{
        rows: any[];
        rowCount: number;
    }>;
    getSchemaName(projectId: string): string;
    dropProjectSchema(projectId: string): Promise<void>;
}
export declare const databaseService: DatabaseService;
//# sourceMappingURL=database.service.d.ts.map