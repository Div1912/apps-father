"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBot = createBot;
const grammy_1 = require("grammy");
const config_1 = require("../config");
const start_1 = require("./commands/start");
const billing_service_1 = require("../services/billing.service");
const managed_bot_1 = require("./handlers/managed-bot");
const callback_1 = require("./handlers/callback");
function createBot() {
    const bot = new grammy_1.Bot(config_1.config.botToken);
    bot.use((0, grammy_1.session)({
        initial: () => ({
            activeProjectId: undefined,
            conversationState: "idle",
            pendingPlan: undefined,
            pendingDescription: undefined,
            awaitingInput: null,
        }),
    }));
    bot.command("start", (ctx) => {
        if (ctx.chat.type !== "private")
            return;
        return (0, start_1.startCommand)(ctx);
    });
    // IMPORTANT: payment-related handlers must be registered BEFORE the generic
    // `bot.on("message")` catch-all, otherwise grammy will short-circuit at the
    // first matching handler that doesn't call next() and Stars payments will
    // never reach handleStarsPayment.
    bot.on("pre_checkout_query", async (ctx) => {
        try {
            console.log(`[Bot] pre_checkout_query: user=${ctx.from?.id}, payload=${ctx.preCheckoutQuery?.invoice_payload}`);
            await ctx.answerPreCheckoutQuery(true);
        }
        catch (err) {
            console.error("[Bot] pre_checkout_query error:", err);
            try {
                await ctx.answerPreCheckoutQuery(false, { error_message: "Payment error" });
            }
            catch { }
        }
    });
    bot.on("message:successful_payment", async (ctx) => {
        try {
            const payment = ctx.message.successful_payment;
            console.log(`[Bot] Stars payment received: user=${ctx.from.id}, amount=${payment.total_amount} ${payment.currency}, payload=${payment.invoice_payload}`);
            const payload = JSON.parse(payment.invoice_payload);
            if (payload.type === "topup" && payload.paymentId) {
                await billing_service_1.billingService.handleStarsPayment(payload.paymentId);
            }
            else {
                console.warn(`[Bot] Stars payment with unknown payload:`, payload);
            }
        }
        catch (err) {
            console.error("[Bot] successful_payment error:", err);
        }
    });
    (0, callback_1.registerCallbackHandlers)(bot);
    (0, managed_bot_1.registerManagedBotHandlers)(bot);
    bot.on("message", (ctx) => {
        if (ctx.chat.type !== "private")
            return;
        // Don't treat service messages (like successful_payment) as a /start trigger
        if (ctx.message.successful_payment)
            return;
        return (0, start_1.startCommand)(ctx);
    });
    bot.catch((err) => {
        const msg = err?.message || err?.error?.description || "";
        if (msg.includes("message is not modified"))
            return;
        console.error("[Bot] Error:", err);
    });
    return bot;
}
//# sourceMappingURL=index.js.map