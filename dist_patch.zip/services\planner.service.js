"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.plannerService = exports.PlannerService = void 0;
exports.formatPlanMarkdown = formatPlanMarkdown;
const sdk_1 = __importDefault(require("@anthropic-ai/sdk"));
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const config_1 = require("../config");
const SONNET = "claude-sonnet-4-6";
const HAIKU = "claude-haiku-4-5-20251001";
// ─────────────────────────────────────────────────────────────────────────────
//  System prompts
// ─────────────────────────────────────────────────────────────────────────────
const PLAN_SYSTEM = `You are Apps Father — a senior product designer for Telegram Mini Apps.

Your job: turn a user's one-paragraph idea (and optional reference images) into a SHORT, BUILDABLE plan for a Telegram Mini App. You do NOT write code, schemas, or API endpoints — the plan is what the USER reads to approve scope before code generation.

WRITING RULES (these decide quality):
1. Concrete, not generic. "Track 3 daily habits with a streak counter and a weekly heatmap" beats "habit tracker app".
2. Telegram-native. Prefer Telegram Stars (XTR), share-link invites, bot push notifications, openInvoice — over web-style email/password auth.
3. Tight scope. v1 must be buildable in one shot: 4–8 features, 2–4 screens. Cut anything that does not serve the core loop.
4. Mobile-first. Single-thumb UX. No multi-pane layouts, no hover states.
5. Every screen earns its place — describe its purpose in 1 line and 2–4 user actions. No "Settings" filler unless it does real work.
6. Pick exactly ONE monetization model (or "none"). Don't mix.
7. If the idea is ambiguous, make sane opinionated choices and surface them in "assumptions" — do NOT ask the user clarifying questions.
8. If reference images are provided, match their visual mood (color, density, vibe) when describing screens.
9. Use everyday product language, NOT engineering jargon. The user is non-technical.

OUTPUT FORMAT:
You MUST call the submit_plan tool with the structured plan. Do not write any free-form text.`;
const CRITIQUE_SYSTEM = `You are a strict reviewer of Telegram Mini App plans.

Score the plan from 1 (bad) to 5 (great) on each axis:
- clarity:             is every feature & screen unambiguous and concrete?
- scope_fit:           can this be built in one shot (4–8 features, 2–4 screens)?
- telegram_fit:        does it use Telegram-native patterns (Stars / bot / share) where natural?
- mobile_ux:           is each screen single-thumb friendly?
- monetization_sense:  is the monetization choice coherent (or correctly "none")?

Then list 0–3 SPECIFIC fixes (each ≤ 25 words). Skip nitpicks. Each fix must be actionable on the JSON ("rename screen X to Y", "drop feature Z", "change monetization to stars with details: ...").

Call submit_review now. No free-form text.`;
// ─────────────────────────────────────────────────────────────────────────────
//  Tool / schema definitions
// ─────────────────────────────────────────────────────────────────────────────
const PLAN_TOOL = {
    name: "submit_plan",
    description: "Submit the structured Telegram Mini App plan.",
    input_schema: {
        type: "object",
        required: ["appName", "tagline", "category", "audience", "coreLoop", "features", "screens", "monetization"],
        properties: {
            appName: { type: "string", description: "2–4 words, no emojis." },
            tagline: { type: "string", description: "One sentence, ≤ 100 chars: what + for whom." },
            category: { type: "string", enum: ["game", "tool", "social", "store", "content", "utility", "tracker", "other"] },
            audience: { type: "string", description: "1 sentence: who this is for." },
            coreLoop: { type: "string", description: "1–2 sentences: the main repeated user action that creates value." },
            features: {
                type: "array", minItems: 4, maxItems: 8,
                items: { type: "string", description: "Concrete feature, one short verb-led line." },
            },
            screens: {
                type: "array", minItems: 2, maxItems: 4,
                items: {
                    type: "object",
                    required: ["name", "purpose", "actions"],
                    properties: {
                        name: { type: "string" },
                        purpose: { type: "string", description: "1 line: why this screen exists." },
                        actions: {
                            type: "array", minItems: 1, maxItems: 4,
                            items: { type: "string", description: "Verb-led user action: 'Tap a habit to log it'." },
                        },
                    },
                },
            },
            monetization: {
                type: "object",
                required: ["model", "details"],
                properties: {
                    model: { type: "string", enum: ["telegram_stars", "ads", "subscription", "ton", "none"] },
                    details: { type: "string", description: "1 line. If stars: WHAT is sold for HOW MANY stars. If none: WHY (e.g. portfolio / community)." },
                },
            },
            assumptions: {
                type: "array", maxItems: 3,
                items: { type: "string" },
                description: "Opinionated choices made to fill gaps in the user's idea.",
            },
            outOfScope: {
                type: "array", maxItems: 3,
                items: { type: "string" },
                description: "Things deliberately deferred to keep v1 buildable.",
            },
        },
    },
};
const CRITIQUE_TOOL = {
    name: "submit_review",
    description: "Submit a structured plan critique.",
    input_schema: {
        type: "object",
        required: ["scores", "fixes"],
        properties: {
            scores: {
                type: "object",
                required: ["clarity", "scope_fit", "telegram_fit", "mobile_ux", "monetization_sense"],
                properties: {
                    clarity: { type: "integer", minimum: 1, maximum: 5 },
                    scope_fit: { type: "integer", minimum: 1, maximum: 5 },
                    telegram_fit: { type: "integer", minimum: 1, maximum: 5 },
                    mobile_ux: { type: "integer", minimum: 1, maximum: 5 },
                    monetization_sense: { type: "integer", minimum: 1, maximum: 5 },
                },
            },
            fixes: { type: "array", maxItems: 3, items: { type: "string" } },
        },
    },
};
// ─────────────────────────────────────────────────────────────────────────────
//  Helpers
// ─────────────────────────────────────────────────────────────────────────────
const IMG_EXT_TO_MIME = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
    ".gif": "image/gif",
};
const MAX_IMAGES = 4;
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
// Critique runs only when we expect a meaningful uplift; below this score everything is already great.
const CRITIQUE_FIXUP_THRESHOLD = 4;
function langName(lang) {
    if (!lang || lang === "en")
        return "English";
    if (lang === "ru")
        return "Russian";
    if (lang === "ua")
        return "Ukrainian";
    return lang;
}
function buildImageBlocks(paths) {
    if (!paths?.length)
        return [];
    const blocks = [];
    for (const p of paths.slice(0, MAX_IMAGES)) {
        try {
            const ext = path.extname(p).toLowerCase();
            const mime = IMG_EXT_TO_MIME[ext];
            if (!mime)
                continue;
            const stat = fs.statSync(p);
            if (stat.size > MAX_IMAGE_BYTES)
                continue;
            const data = fs.readFileSync(p).toString("base64");
            blocks.push({
                type: "image",
                source: { type: "base64", media_type: mime, data },
            });
        }
        catch {
            // Skip unreadable files — we still want the plan even if one image is broken.
        }
    }
    return blocks;
}
function pickToolUseBlock(message, name) {
    for (const block of message.content || []) {
        if (block.type === "tool_use" && block.name === name)
            return block.input;
    }
    return null;
}
function toUsage(model, raw, phase) {
    return {
        model,
        inputTokens: raw?.input_tokens ?? 0,
        outputTokens: raw?.output_tokens ?? 0,
        cacheReadTokens: raw?.cache_read_input_tokens ?? 0,
        cacheWriteTokens: raw?.cache_creation_input_tokens ?? 0,
        phase,
    };
}
// ─────────────────────────────────────────────────────────────────────────────
//  Markdown rendering
// ─────────────────────────────────────────────────────────────────────────────
const HEADERS_BY_LANG = {
    en: { features: "Features", screens: "Screens", monetization: "Monetization", assumptions: "Assumptions", outOfScope: "Out of scope (v2+)" },
    ru: { features: "Функции", screens: "Экраны", monetization: "Монетизация", assumptions: "Допущения", outOfScope: "Не в этом релизе (v2+)" },
    ua: { features: "Функції", screens: "Екрани", monetization: "Монетизація", assumptions: "Припущення", outOfScope: "Не в цьому релізі (v2+)" },
};
const MONET_LABELS = {
    en: { telegram_stars: "Telegram Stars", ads: "Ads", subscription: "Subscription", ton: "TON", none: "Free / no monetization" },
    ru: { telegram_stars: "Telegram Stars", ads: "Реклама", subscription: "Подписка", ton: "TON", none: "Бесплатно / без монетизации" },
    ua: { telegram_stars: "Telegram Stars", ads: "Реклама", subscription: "Підписка", ton: "TON", none: "Безкоштовно / без монетизації" },
};
function formatPlanMarkdown(p, lang) {
    const L = HEADERS_BY_LANG[lang || "en"] || HEADERS_BY_LANG.en;
    const M = MONET_LABELS[lang || "en"] || MONET_LABELS.en;
    const out = [];
    out.push(`# ${p.appName}`);
    out.push("");
    if (p.tagline) {
        out.push(`_${p.tagline}_`);
        out.push("");
    }
    out.push(`**${p.audience}** — ${p.coreLoop}`);
    out.push("");
    out.push(`## ${L.features}`);
    for (const f of p.features)
        out.push(`- ${f}`);
    out.push("");
    out.push(`## ${L.screens}`);
    for (const s of p.screens) {
        out.push(`### ${s.name}`);
        out.push(s.purpose);
        for (const a of s.actions)
            out.push(`- ${a}`);
        out.push("");
    }
    const monLabel = M[p.monetization?.model || "none"] || p.monetization?.model;
    out.push(`## ${L.monetization}`);
    out.push(`**${monLabel}** — ${p.monetization?.details || ""}`);
    if (p.assumptions?.length) {
        out.push("");
        out.push(`## ${L.assumptions}`);
        for (const a of p.assumptions)
            out.push(`- ${a}`);
    }
    if (p.outOfScope?.length) {
        out.push("");
        out.push(`## ${L.outOfScope}`);
        for (const a of p.outOfScope)
            out.push(`- ${a}`);
    }
    return out.join("\n").trim();
}
// ─────────────────────────────────────────────────────────────────────────────
//  Service
// ─────────────────────────────────────────────────────────────────────────────
class PlannerService {
    client;
    constructor() {
        this.client = new sdk_1.default({ apiKey: config_1.config.anthropicApiKey });
    }
    async generatePlan(opts) {
        const enableCritique = opts.enableCritique !== false;
        const usages = [];
        const draft = await this.runDraft(opts);
        usages.push(draft.usage);
        let plan = draft.plan;
        let critique;
        if (enableCritique) {
            try {
                const c = await this.runCritique(plan, opts.lang);
                usages.push(c.usage);
                critique = c.critique;
                const minScore = Math.min(...Object.values(critique.scores));
                if (minScore < CRITIQUE_FIXUP_THRESHOLD && critique.fixes.length > 0) {
                    const fixed = await this.runFixup(plan, critique, opts);
                    usages.push(fixed.usage);
                    plan = fixed.plan;
                }
            }
            catch (err) {
                // Critique is a quality nice-to-have, never let it break plan delivery.
                console.warn("[Planner] Critique pass skipped:", err.message);
            }
        }
        const md = formatPlanMarkdown(plan, opts.lang);
        const inputTokens = usages.reduce((s, u) => s + u.inputTokens + u.cacheReadTokens + u.cacheWriteTokens, 0);
        const outputTokens = usages.reduce((s, u) => s + u.outputTokens, 0);
        return { plan: md, planJson: plan, critique, usages, inputTokens, outputTokens };
    }
    async runDraft(opts) {
        const userBlocks = [];
        userBlocks.push(...buildImageBlocks(opts.assetPaths));
        userBlocks.push({
            type: "text",
            text: `IDEA:\n${opts.description.trim()}\n\n` +
                (opts.assetPaths?.length
                    ? `The user attached ${opts.assetPaths.length} reference image(s) above. Match the visual mood (colors, density, vibe) when describing the screens.\n\n`
                    : "") +
                `Write the plan in ${langName(opts.lang)}.\n` +
                `Call submit_plan now.`,
        });
        const msg = await this.client.messages.create({
            model: SONNET,
            max_tokens: 1500,
            system: [
                // The system prompt is identical across all plan generations → ephemeral cache hits the SECOND call onwards.
                { type: "text", text: PLAN_SYSTEM, cache_control: { type: "ephemeral" } },
            ],
            tools: [PLAN_TOOL],
            tool_choice: { type: "tool", name: "submit_plan" },
            messages: [{ role: "user", content: userBlocks }],
        });
        const input = pickToolUseBlock(msg, "submit_plan");
        if (!input)
            throw new Error("Planner did not call submit_plan");
        return { plan: input, usage: toUsage(SONNET, msg.usage, "draft") };
    }
    async runCritique(plan, lang) {
        const msg = await this.client.messages.create({
            model: HAIKU,
            max_tokens: 600,
            system: [
                { type: "text", text: CRITIQUE_SYSTEM, cache_control: { type: "ephemeral" } },
            ],
            tools: [CRITIQUE_TOOL],
            tool_choice: { type: "tool", name: "submit_review" },
            messages: [{
                    role: "user",
                    content: [{
                            type: "text",
                            text: `Plan to review (written in ${langName(lang)}):\n` +
                                "```json\n" + JSON.stringify(plan, null, 2) + "\n```\n" +
                                "Call submit_review now.",
                        }],
                }],
        });
        const input = pickToolUseBlock(msg, "submit_review");
        if (!input)
            throw new Error("Critique did not call submit_review");
        return { critique: input, usage: toUsage(HAIKU, msg.usage, "critique") };
    }
    async runFixup(plan, critique, opts) {
        const msg = await this.client.messages.create({
            model: SONNET,
            max_tokens: 1500,
            system: [
                { type: "text", text: PLAN_SYSTEM, cache_control: { type: "ephemeral" } },
            ],
            tools: [PLAN_TOOL],
            tool_choice: { type: "tool", name: "submit_plan" },
            messages: [{
                    role: "user",
                    content: [{
                            type: "text",
                            text: `Original idea:\n${opts.description.trim()}\n\n` +
                                "Current plan:\n```json\n" + JSON.stringify(plan, null, 2) + "\n```\n\n" +
                                `Reviewer feedback to address (apply minimally — keep everything else):\n- ${critique.fixes.join("\n- ")}\n\n` +
                                `Write in ${langName(opts.lang)}. Call submit_plan now.`,
                        }],
                }],
        });
        const input = pickToolUseBlock(msg, "submit_plan");
        if (!input)
            throw new Error("Fixup did not call submit_plan");
        return { plan: input, usage: toUsage(SONNET, msg.usage, "fixup") };
    }
}
exports.PlannerService = PlannerService;
exports.plannerService = new PlannerService();
//# sourceMappingURL=planner.service.js.map