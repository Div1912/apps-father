export declare const config: {
    botToken: string;
    anthropicApiKey: string;
    openrouterApiKey: string;
    databaseUrl: string;
    domain: string;
    port: number;
    nodeEnv: string;
    webhookSecret: string;
    encryptionKey: string;
    nowpaymentsApiKey: string;
    nowpaymentsIpnSecret: string;
    adminPassword: string;
    cryptoBotToken: string;
    walletMnemonic: string;
    toncenterApiKey: string;
    withdrawGroupId: string;
    openPanelClientId: string;
    openPanelClientSecret: string;
    elevenLabsApiKey: string;
    apiPassKey: string;
    readonly baseUrl: string;
    readonly webhookUrl: string;
};
//# sourceMappingURL=config.d.ts.map