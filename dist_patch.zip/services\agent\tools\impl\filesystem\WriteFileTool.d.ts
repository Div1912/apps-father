import type OpenAI from "openai";
import type { AgentTool } from "../../../AgentTool";
import type { RunContext } from "../../../RunContext";
export declare class WriteFileTool implements AgentTool {
    renderDefinition(): OpenAI.Chat.Completions.ChatCompletionTool;
    execute(args: Record<string, any>, ctx: RunContext): Promise<string>;
    getStepMeta(args: Record<string, any>): Record<string, any>;
    private _isProtectedPath;
    private _safePath;
}
//# sourceMappingURL=WriteFileTool.d.ts.map