import { Lang } from "./i18n";
export declare function mdToTgHtml(md: string): string;
export declare function processMessage(status: string, percent?: number, lang?: Lang, costUsd?: number, balance?: number): string;
export declare function doneMessage(title: string, detail: string): string;
export declare function errorMessage(detail: string, lang?: Lang): string;
export declare function costLine(costUsd: number, newBalance: number, lang?: Lang): string;
export declare function truncSummary(text: string, maxLen?: number, lang?: Lang): string;
export interface ChecklistItem {
    text: string;
    done: boolean;
}
export declare function checklistMessage(title: string, items: ChecklistItem[], status?: string, lang?: Lang, costUsd?: number, balance?: number, percent?: number): string;
//# sourceMappingURL=progress.d.ts.map