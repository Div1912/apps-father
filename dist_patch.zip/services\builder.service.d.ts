import { GeneratedApp } from "../types";
export declare class BuilderService {
    getProjectDir(projectId: string): string;
    scaffoldProject(projectId: string, app: GeneratedApp): Promise<void>;
    updateProject(projectId: string, app: GeneratedApp): Promise<void>;
    getProjectCode(projectId: string): string | null;
    projectExists(projectId: string): boolean;
    private writeFile;
}
export declare const builderService: BuilderService;
//# sourceMappingURL=builder.service.d.ts.map