declare const router: import("express-serve-static-core").Router;
export declare function evictDevApiCache(projectId: string): void;
export default router;
//# sourceMappingURL=devapi.routes.d.ts.map